# Forms Editor Feedback Batch — UI Polish Pass

## Context

The user left 11 page-feedback annotations on `/forms/{id}/edit`. Items 2 and 11 duplicate the same `AllowOtherToggle` concern, so the work collapses to **10 distinct units**. The feedback centers on three themes:

1. **Toggles and sub-editors are visually cramped** (MiniToggle, SignersEditor, AddressComponentsEditor, AccountLinkingMetaEditor, FullNameComponentsEditor, AllowOtherToggle).
2. **Preview cards don't match the product's liquid-glass/orb theme** from `DESIGN.md` (InfoCard, LinkCard).
3. **Two specific product behaviors are wrong** — the `LogicEditor` popover z-index sits below the AI chat panel, and the date question needs a real calendar picker instead of the native HTML5 `<input type="date">`.

Intended outcome: each annotation becomes a small, reviewable PR with before/after parity on the form editor, matching the design system already codified in `DESIGN.md`.

## Research summary

**QuestionCard.jsx** (`src/components/forms/editor/QuestionCard.jsx`) hosts every meta-editor referenced:
- `Toggle` (54-80) — full custom slid-knob toggle already matches theme.
- `MiniToggle` (368-382) — tiny checkbox-in-a-box, used by SignatureMetaEditor and AccountLinkingMetaEditor. This is what the user keeps calling "too small".
- `AllowOtherToggle` (441-456) — bare `<input type="checkbox">` today; today's UX is a separate free-text field at render time. Google Forms instead appends an "Other: ____" row inline with the options list.
- `AccountLinkingMetaEditor` (536-558) — number input + 1× MiniToggle.
- `FullNameComponentsEditor` (774-786) and `AddressComponentsEditor` (799-811) — both lean on a shared `ComponentsEditor` with `{enabled, required}` per subfield in a 2-col grid. User wants: all subfields default **on**, per-row toggles for `off` and `required`.
- `SignersEditor` (891-966) / `SignatureMetaEditor` (968-1011) — signer rows + five MiniToggles.
- Date question renders `DateInput` (HTML5 input).

**Preview components:**
- `InfoCard.jsx` (`src/components/forms/renderer/inputs/InfoCard.jsx`) — bespoke gradient with per-variant tints (warning=amber, success=green, disclaimer=slate). Doesn't use the liquid-glass recipe from `DESIGN.md §4.2`.
- `LinkCard.jsx` — teal-only, large gradient CTA, feels out-of-scale with the rest of the editor preview.

**Z-index conflict:**
- `LogicEditor.jsx:446` Popover.Panel = `z-40`.
- `AIChatSidePanel.jsx:5760` = `z-[9999]`.
- Fix: bump the popover above the chat panel.

**Design tokens** (from `DESIGN.md`):
- Anchor teal `#0F2D26`, mid `#3f7267`, highlight `#b8d4ce`, ambient RGB `15, 45, 38`.
- Liquid Glass Surface (§4.2): `bg-white/70 border-white/60 backdrop-blur-xl` + inset highlight + ambient shadow.
- Motion: `cubic-bezier(0.2, 0.8, 0.2, 1)` / 220ms.

**No existing date picker library.** `date-fns@^4.1.0` is installed; `react-day-picker` is not. Unit 8 will add `react-day-picker` (small, battle-tested, `date-fns` integration).

**No Storybook / Playwright.** Only verification path is `npm run dev` (Vite on port 5173) + real login + navigate to `/forms/flow_1776721109774_g6sz4y/edit`.

## Work units (10)

Each unit is independently implementable in a worktree and mergeable on its own. Units 4-10 all touch `src/components/forms/editor/QuestionCard.jsx`; they're sliced by distinct line ranges/components so rebasing conflicts are local and mechanical.

| # | Title | Files | One-line change |
|---|---|---|---|
| 1 | Raise LogicEditor popover above AI chat | `src/components/forms/editor/LogicEditor.jsx` | Change `z-40` → `z-[10000]` on `Popover.Panel` (line ~446) so it sits above `AIChatSidePanel` (`z-[9999]`). |
| 2 | Re-skin InfoCard to liquid-glass theme | `src/components/forms/renderer/inputs/InfoCard.jsx` | Replace bespoke gradient + per-variant tints with the `bg-white/70 border-white/60 backdrop-blur-xl` surface + teal-anchored accent orb; keep variant semantics via the left accent bar color only. |
| 3 | Re-skin LinkCard to liquid-glass theme | `src/components/forms/renderer/inputs/LinkCard.jsx` | Same surface recipe as InfoCard; shrink CTA to standard button scale; remove the oversized teal gradient block that currently pops out. |
| 4 | Upgrade `MiniToggle` → full `Toggle` (labeled row) | `src/components/forms/editor/QuestionCard.jsx` (368-382 + all call sites) | Remove `MiniToggle`; replace each call site in `SignatureMetaEditor`, `AccountLinkingMetaEditor`, `ComponentsEditor` with the existing `Toggle` component laid out as a labeled row (icon/label left, toggle right, `py-2.5` min height). |
| 5 | SignersEditor — bigger, clearer rows | `src/components/forms/editor/QuestionCard.jsx` (891-966) | Bump signer rows to `py-3`/`gap-3`, grow index badge (`h-8 w-8`), move role input to full row width, inline "Required" as proper toggle (not raw checkbox), larger delete hit target. |
| 6 | AddressComponentsEditor — default-on + per-row controls | `src/components/forms/editor/QuestionCard.jsx` (799-811 + shared `ComponentsEditor`) | Default all 6 address subfields to `enabled:true`. Replace 2-col grid with one row per subfield; each row: label · "Required" toggle · "Include" toggle. |
| 7 | FullNameComponentsEditor — conventional (first/last default, optional middle) | `src/components/forms/editor/QuestionCard.jsx` (774-786) | Drop `prefix` and `suffix` from default ordering. Default `first` and `last` on & required; `middle` off by default but toggleable. Reuse the new single-column layout from Unit 6. |
| 8 | Google-Forms-style "Other" option | `src/components/forms/editor/QuestionCard.jsx` (441-456 + options list 300-360 area) + `src/components/forms/renderer/inputs/ChoiceInput.jsx` (or equivalent renderer) | Remove the standalone `AllowOtherToggle` checkbox. Append an inline "Other…" row at the end of the options editor with an "× Remove"/"+ Add Other" affordance. At render time, selecting the Other row reveals an inline free-text field on the same line (Google Forms UX). |
| 9 | Custom calendar date picker | `package.json`, new `src/components/forms/renderer/inputs/DatePickerInput.jsx`, `src/components/forms/renderer/inputs/DateInput.jsx`, `src/components/forms/editor/QuestionCard.jsx` (~1203) | Add `react-day-picker`. Wrap it in a popover-style calendar that opens from a glass-styled trigger button, uses `#0F2D26` accents, month/year nav, today highlight. Swap the date preview + renderer over. |
| 10 | AccountLinkingMetaEditor — refresh to labeled toggle rows | `src/components/forms/editor/QuestionCard.jsx` (536-558) | Apply Unit 4's labeled-row pattern; make the `minAccounts` number input larger (`h-10`) to match. (Kept separate from Unit 4 because it also restyles the number input.) |

### Conflict note

Units 4, 5, 6, 7, 8, 10 all touch `QuestionCard.jsx`, but each operates on a disjoint line range / component boundary. Rebasing in order 4 → 10 → 5 → 6 → 7 → 8 gives clean merges in my experience with this file. Units 1, 2, 3, 9 are fully independent.

## E2E verification recipe (for every unit)

There is no Storybook/Playwright in this repo — the only real verification is the dev server + a live form.

Each worker must:

1. **Start the dev server** in the worktree: `npm install` (required for Unit 9 only, to pick up `react-day-picker`; everyone else can skip) then `npm run dev`. Vite serves on `http://localhost:5173`.
2. **Load the authenticated editor** using Claude's chrome extension tools (`mcp__claude-in-chrome__*`). The user is already logged in in their Chrome — the worker should:
   - `tabs_context_mcp` to list open tabs,
   - `tabs_create_mcp` a new tab on `http://localhost:5173/forms/flow_1776721109774_g6sz4y/edit`,
   - `screenshot` the editor to confirm it loaded (no auth screen).
3. **Exercise the change.** Open the question(s) that this unit affects (e.g., add/open the signature question for Units 4/5, a multiple-choice question for Unit 8, a date question for Unit 9). Screenshot before/after interaction; click through the new UI; verify no layout breakage.
4. **Attach the screenshot(s)** to the PR body.
5. **If auth is a blocker** (the user's Chrome isn't authenticated to localhost:5173 with a valid form ID), note it and fall back to a static screenshot of just the component section by loading the editor empty + using `/forms/new` flow. If that also fails, report `e2e: skipped — auth blocker` and attach a unit-test/build-pass screenshot instead.

Type-check and lint still run locally: `npm run lint` (must pass with `--max-warnings 0`) before pushing.

## Worker instruction template (copied verbatim into each agent's prompt)

```
After you finish implementing the change:
1. Simplify — Invoke the `Skill` tool with `skill: "simplify"` to review and clean up your changes.
2. Run unit tests — `npm run lint` at minimum (must pass with 0 warnings). If the change touches date utilities, run `npm run test:date-utils`. Fix any failures.
3. Test end-to-end — follow the recipe in the coordinator prompt. Attach a screenshot to the PR body.
4. Commit and push — commit all changes with a clear message, push the branch, and `gh pr create` with a descriptive title. If `gh` is unavailable, note it.
5. Report — end with a single line: `PR: <url>` (or `PR: none — <reason>`).
```
