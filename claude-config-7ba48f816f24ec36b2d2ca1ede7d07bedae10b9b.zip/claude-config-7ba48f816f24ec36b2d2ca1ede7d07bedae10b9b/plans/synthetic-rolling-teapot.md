# Plan: Chart Skeleton Loading State

## Context
When the user asks for a chart, the agent calls `generate_chart` which appears as a ToolCard in the timeline. The user sees the tool call chip (collapsed) but no visual hint that a chart is coming. After the tool completes, the chart pops in abruptly. We can't stream the chart incrementally (Recharts needs complete data), but we **can** show a skeleton placeholder the moment `generate_chart` starts, then crossfade to the real chart when it arrives.

## Approach
When a `generate_chart` tool execution appears in the timeline, render a chart skeleton placeholder instead of the normal ToolCard. When the matching A2UI surface arrives (same turn), the skeleton is naturally replaced by the real chart in the timeline.

### How it works today
1. `tool_start` for `generate_chart` → ToolExecution added to store with `status: "running"`
2. ToolCard renders in timeline (collapsible chip: "Generate Chart >")
3. `tool_end` → ToolExecution status becomes `"completed"` 
4. `a2ui_render` → A2UISurfaceEntry added to store
5. `buildTimeline()` sorts both tool + surface items chronologically → surface renders as real chart

The skeleton should show during steps 1-4, then disappear once the real surface takes over.

### Implementation

**File: `src/components/A2UISurface.tsx`** — Add a `ChartSkeleton` export (~25 lines)

```tsx
export function ChartSkeleton() {
  return (
    <div className="bg-card border border-border rounded-lg p-4">
      <div className="animate-pulse space-y-4">
        {/* Title bar */}
        <div className="h-4 w-1/3 rounded bg-muted" />
        {/* Chart area */}
        <div className="flex items-end gap-2 h-[200px] pt-4">
          {[0.4, 0.7, 0.5, 0.9, 0.6, 0.8, 0.3, 0.65].map((h, i) => (
            <div
              key={i}
              className="flex-1 rounded-t bg-muted"
              style={{ height: `${h * 100}%` }}
            />
          ))}
        </div>
        {/* X-axis labels */}
        <div className="flex gap-2">
          {Array.from({ length: 8 }).map((_, i) => (
            <div key={i} className="flex-1 h-2.5 rounded bg-muted" />
          ))}
        </div>
      </div>
    </div>
  );
}
```

This matches the existing chart container style (`bg-card border border-border rounded-lg p-4`) and uses `animate-pulse` — a standard skeleton pattern. The fake bar heights give the visual shape of a chart.

**File: `src/components/AgentMain.tsx`** — In `TimelineItemView`, case `"tool"`:

Currently, all tool timeline items render as `<ToolCard>`. Add a check: if the tool is `generate_chart` and status is `"running"`, render `<ChartSkeleton />` instead. If status is `"completed"`, render nothing (the real A2UI surface handles it).

```tsx
case "tool":
  // Chart tool: show skeleton while running, hide when done (surface takes over)
  if (item.tool === "generate_chart") {
    if (item.status === "running") {
      return (
        <div className="my-3" style={{ animation: "fadeIn 300ms ease-out" }}>
          <ChartSkeleton />
        </div>
      );
    }
    return null; // completed chart tool — the A2UI surface renders the real chart
  }
  return <ToolCard ... />;
```

### Files to modify
1. **`src/components/A2UISurface.tsx`** — Add and export `ChartSkeleton` component
2. **`src/components/AgentMain.tsx`** — Import `ChartSkeleton`, add branch in `TimelineItemView` tool case

### What NOT to change
- `taskStore.ts` — timeline building and event handling stay the same
- `generate_chart.rs` — Rust tool unchanged
- `tool_executor.rs` — event emission unchanged

## Verification
1. `npx tsc --noEmit` — zero errors
2. Ask the agent to generate a chart. Observe:
   - Skeleton placeholder appears immediately when tool starts
   - Skeleton shows pulsing bar shapes matching chart container dimensions
   - Real chart replaces skeleton smoothly when data arrives
   - Completed `generate_chart` tool entries don't show a redundant ToolCard
