# Blocked Apps Card Grid Redesign — Spec & Implementation Plan

## Context

The current `BlockedAppsView.swift` (1252 lines) uses a list-based layout with `AppBudgetCard` components. The UI feels cramped and utilitarian. This redesign replaces it with a 2-column card grid where each card is a blocked app — portrait-oriented, with an app icon, name, daily opens budget stepper, and a bottom progress bar that fills as opens are consumed. The goal is a visually polished, tactile screen that matches Mojo's playful design language.

---

## Spec

### Card Layout (Portrait, ~3:4 aspect ratio)

```
┌─────────────────────┐  ← 1px border (onSurface @ 10% opacity)
│                     │     corner radius: 24px (radiusMD)
│      [App Icon]     │  ← Label(token).labelStyle(.iconOnly), 44×44
│                     │
│      App Name       │  ← Figtree SemiBold 14px, center-aligned
│                     │     single line, truncated if needed
│    -    3    +      │  ← budget stepper: 1–10 range
│                     │     haptic feedback (light impact) on tap
│█████████░░░░░░░░░░░│  ← progress bar: full-width, clipped by radius
└─────────────────────┘     height: ~6px, hugs bottom edge
```

**Card Background:** `surfaceContainerLowest`
**Border:** 1px `onSurface` at ~10% opacity
**Corner Radius:** 24px (`radiusMD`)
**Card fills available width** in a 2-column `LazyVGrid` with `MojoSpacing.md` (12px) spacing.

### Progress Bar (Bottom Lip)

- **Track:** full-width bar at bottom edge, `surfaceContainerHighest` (gray), ~6px height
- **Fill:** `primaryFixed` green, fills **left-to-right** based on `opensUsed / budget`
  - 0/3 used → 0% fill (empty gray track visible)
  - 2/3 used → 66% fill
  - 3/3 used → 100% fill (fully green)
- **Clipping:** bar spans edge-to-edge; card's `clipShape(RoundedRectangle)` naturally clips corners
- **Exhausted state:** 100% green fill only. No color shift, no dimming, no overlay.

### Shimmer Effect

- **Trigger:** only when fill level changes (open consumed)
- **Animation:** single shimmer sweep (white highlight at 40% opacity, 25° rotation, slides left→right over ~0.8s)
- **Idle:** no shimmer, static green fill

### Budget Stepper (+/− Buttons)

- Range: **1–10**
- `−` disabled (dimmed) when budget = 1
- `+` disabled (dimmed) when budget = 10
- **Haptic:** `UIImpactFeedbackGenerator(style: .light)` on each tap
- Number displayed: Figtree Bold, centered between buttons
- Buttons: SF Symbol `minus` and `plus`, 12pt bold

### App Icon

- Uses existing `Label(token).labelStyle(.iconOnly)` from FamilyControls
- Displayed in a 44×44 rounded rectangle with `surfaceContainerHighest` at 50% opacity background
- Centered horizontally in card

### Add App Card ("+" Button)

- **Same card dimensions** as app cards (not a floating FAB)
- Positioned as the **last item** in the grid
- **Appearance:** outlined card (same border style), dashed or solid border, large `+` SF Symbol centered
- **Action:** opens system `FamilyActivityPicker` sheet
- **Free tier limit:** when user has hit their 1-app limit, the `+` card shows a **lock icon** or "Pro" badge. Tapping opens the paywall instead of the picker.

### Interactions

| Gesture | Target | Action |
|---------|--------|--------|
| Tap +/− | Stepper buttons | Adjust budget (1–10), haptic feedback |
| Tap card body | Anywhere else on card | **No action** |
| Long press | Any app card | Context menu: "Remove" → triggers `RemovalChatView` |
| Tap | "+" card | Opens `FamilyActivityPicker` (or paywall if at free limit) |

### Grid Layout

- **Columns:** 2 fixed columns via `LazyVGrid`
  ```swift
  let columns = [
      GridItem(.flexible(), spacing: MojoSpacing.md),
      GridItem(.flexible(), spacing: MojoSpacing.md)
  ]
  ```
- **Spacing:** `MojoSpacing.md` (12px) horizontal and vertical
- **Padding:** `MojoSpacing.lg` (16px) horizontal from screen edges
- **Scroll:** `ScrollView(.vertical)` wrapping the grid. No maximum app count (Pro tier = unlimited).
- **Entrance animation:** None. Cards appear instantly.

### Header

- Minimal title: **"Blocked Apps"** at top
- Font: `Font.Mojo.figtree(.bold, size: 28)` (headlineMedium)
- Left-aligned with horizontal padding

### Empty State

When zero apps are blocked:
- Friendly illustration (can reuse existing empty state asset or SF Symbol placeholder)
- Short copy: e.g., "Block distracting apps and Argo will guard them"
- Font: `Font.Mojo.figtree(.medium, size: 15)` body, `textSecondary` color
- The "+" card still appears in the grid below the illustration

### Categories

- **Not supported.** Remove all category-related UI (collapsible sections, category tokens). Individual apps only.

### App Naming

- Keep existing `AppNameEntrySheet` flow for apps whose names can't be resolved from `TokenNameCache`

### Navigation

- **Same location:** inside `ShieldView` → "Apps" segment
- Replace the current list-based content with the new card grid
- The `ShieldView` segmented control (Apps/Rules) remains unchanged

---

## Files to Modify

| File | Changes |
|------|---------|
| `MojoiOS/UI/Settings/BlockedAppsView.swift` | **Major rewrite.** Replace list layout with `LazyVGrid`. Replace `AppBudgetCard` with new `BlockedAppCard`. Remove category sections. Keep `FamilyActivityPicker`, `AppNameEntrySheet`, `RemovalChatView` sheet logic. |
| `MojoiOS/UI/Shield/ShieldView.swift` | Minor — verify the "Apps" tab still references the updated `BlockedAppsView` correctly. |

### Components to Create (inside BlockedAppsView.swift)

1. **`BlockedAppCard`** — individual app card (icon, name, stepper, progress bar)
2. **`AddAppCard`** — the "+" card with free-tier lock state
3. **`ShimmerModifier`** — ViewModifier for the one-shot shimmer effect on progress bar change

### Components to Reuse

- `Label(token).labelStyle(.iconOnly)` — FamilyControls app icon (existing)
- `RemovalChatView` — Argo removal negotiation (existing, presented via sheet)
- `AppNameEntrySheet` — naming unresolvable tokens (existing)
- `FamilyActivityPicker` — system app picker (existing)
- `screenTimeManager.opensBudget(forApp:)` / `setOpensBudget(_:forApp:)` — budget read/write (existing)
- `screenTimeManager.opensToday(forApp:)` — opens consumed today (existing)
- `entitlementManager.canBlockMoreApps(currentCount)` — free tier gate (existing)
- Design tokens: `Color.Mojo.*`, `Font.Mojo.*`, `MojoSpacing.*` from `DesignSystem.swift`
- Haptic: `UIImpactFeedbackGenerator(style: .light)` pattern from `DuoComponents.swift`

---

## Verification Plan

1. **Build:** `xcodebuild -scheme MojoiOS -configuration Debug -destination 'platform=iOS Simulator,name=iPhone 16' build`
2. **Visual check:** Use XcodeBuildMCP to screenshot the Shield → Apps tab with:
   - 0 apps (empty state)
   - 1 app (single card + "+" card)
   - 5+ apps (scrolling grid)
3. **Interaction check:**
   - Tap +/− on a card → budget changes, haptic fires
   - Long-press a card → context menu appears with "Remove"
   - Tap "+" card → FamilyActivityPicker opens
4. **Progress bar:** verify fill ratio matches `opensUsed / budget` visually
5. **Free tier:** confirm "+" card shows lock when at limit
