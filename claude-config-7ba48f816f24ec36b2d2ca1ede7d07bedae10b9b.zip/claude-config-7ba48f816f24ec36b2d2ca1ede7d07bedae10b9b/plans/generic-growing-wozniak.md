# Activity Feed + Challenge Polish

## Context

The Friends-tab Activity feed is empty for almost every user. Investigation revealed that `ActivityEventType` defines 8 cases, but only `goalMet` and `goalExceeded` are ever written to Firestore (in `StatsSyncService.emitGoalEventIfNeeded`). The other six — `friendAdded`, `challengeCreated`, `challengeAccepted`, `challengeDeclined`, `challengeCompleted`, `dailyProgress` — have no callers.

The plumbing for emitting them is already in place:
- `ActivityFeedService.postEvent(...)` is a complete fire-and-forget API that supports cross-actor dedup via an optional deterministic `documentId` (`MojoiOS/Core/Social/ActivityFeedService.swift:119-148`).
- `DependencyContainer.swift:93-94` already calls `attachActivityFeed` on both `ChallengeService` and `SocialService` at startup. Each holds a wired `weak var activityFeedService` they never use.

The fix is N call-site additions, not architectural work.

While I'm in there, two adjacent bits of dead/orphan code show up: behavioral challenges are scaffolded but uncreatable and unmeasurable, and `PushNotificationService.scheduleChallengeEndingReminder()` exists with no caller. Cleaning these up rounds the surface into something that actually behaves like a finished feature.

Out of scope: remote push notifications (require Cloud Functions); block/unblock; handle uniqueness validation; leaderboard staleness indicator. The user explicitly chose the smaller "activity feed + challenge polish" tier.

User decisions captured:
- **Self-events visible**: feed includes the current user's own actions (mirrors `goalMet`).
- **Visibility**: each participant emits their own event with their own friend graph as `visibleTo` — so creator's friends see the creation, opponent's friends see the acceptance, both friend graphs see completion. Avoids needing to merge two friend lists across writes.

## Final Scope

### A. Wire activity-feed events at the 6 missing call sites

Mirror the existing `StatsSyncService` pattern verbatim:

```swift
let actorName = authService.displayName ?? "Friend"
let friendIds = (socialService?.friends ?? []).map(\.firebaseUserId)
let visibleTo = [userId] + friendIds
Task {
    await feed.postEvent(type: ..., actorUserId: userId, actorDisplayName: actorName,
                         visibleTo: visibleTo, challengeId: ..., metadata: ...)
}
```

`ChallengeService` doesn't currently hold a `SocialService` reference — it needs one to read the friend list. Mirror `StatsSyncService.attach(activityFeedService:, socialService:)` (`StatsSyncService.swift:50`) by adding `attachSocialService(_:)` to `ChallengeService` and wiring it in `DependencyContainer.swift` next to the existing `attachActivityFeed` call.

| # | Where | Event | `visibleTo` |
|---|-------|-------|-------------|
| 1 | `ChallengeService.createChallenge` end (after `challenges.append`, line ~511) | `.challengeCreated` | `[creator, opponent] + creator's friends` |
| 2 | `ChallengeService.acceptChallenge` end (after Firestore update, line ~559) | `.challengeAccepted` | `[creator, opponent] + opponent's friends` |
| 3 | `ChallengeService.declineChallenge` end (line ~584) | `.challengeDeclined` | `[creator, opponent]` only — declines are private, not broadcast |
| 4 | `ChallengeService.handleCompletionSnapshot` (after `pendingCompletion = cached`, line ~219) | `.challengeCompleted` | `[creator, opponent] + viewer's friends`. Use deterministic `documentId: "challenge_completed_{firestoreId}"` so when both participants write, second write overwrites cleanly. |
| 5 | `SocialService.acceptFriendRequest` end (line ~684) | `.friendAdded` | `[acceptor, requester] + acceptor's friends` |
| 6 | `SocialService.acceptFriendInvite` end (after the transactional friendship write, line ~614) | `.friendAdded` | `[acceptor, inviter] + acceptor's friends`. Same event type as #5; covers the referral-link path. |

Metadata to include where useful:
- `challengeCreated`: `["title": challenge.title, "type": challenge.type.rawValue]`
- `challengeAccepted`: `["creatorDisplayName": ..., "opponentDisplayName": ...]` — referenced by the existing `displayText` switch in `ActivityEvent.swift:67-72`
- `challengeCompleted`: `["winnerId": challenge.winnerId, "winnerDisplayName": ..., "challengeTitle": ...]`

`dailyProgress` is **not** wired (the user opted into "challenge polish," not daily-progress noise — these would also fire frequently and clutter the feed).

### B. Real-time activity-feed listener

Currently `ActivityFeedService.fetchFeed()` is manual-only — the feed only updates when the Friends tab appears or the user pulls to refresh. Add a Firestore snapshot listener so the feed live-updates when a friend triggers an event while the user is on the tab.

- Add `private var feedListener: ListenerRegistration?`
- Add `func startListening()` that wires `db.collection("activityEvents").whereField("visibleTo", arrayContains: userId).order(by: "timestamp", descending: true).limit(to: 50).addSnapshotListener { ... }`
- Add `func stopListening()` to detach (idempotent).
- Reuse the existing `data → ActivityEvent` decoding logic from `performFetchFeed` — extract it into a shared `private func makeEvent(from doc:)` helper to avoid duplication.
- Call `startListening()` from `FriendsTabView.task` after `fetchFriends()`. Call `stopListening()` on view disappearance via `.onDisappear`.

The existing `fetchFeed()` stays for first-load cache hydration; the listener takes over for live updates. Listener writes go through the same SwiftData cache invalidation path, so first-launch behavior is unchanged.

### C. Behavioral challenge cleanup (dead-code removal)

Behavioral challenges are scaffolded but unreachable:
- `CreateChallengeSheet.presentablePresets` excludes `.behavioral` (only `[.timeTarget, .appDetox]`)
- `CreateChallengeSheet.configurationIsValid` returns `false` for `.behavioral`
- `CreateChallengeSheet`'s behavioral config section is `EmptyView()`
- `ChallengeService.computeProgress(.behavioral)` returns `0` — hardcoded placeholder

Two options. Pick the conservative one to preserve forward optionality:

**Remove the case from the enum** would force a SwiftData migration. Risky.

**Mark unreachable** instead:
- Leave the `ActivityEventType`-equivalent `ChallengeType.behavioral` case in place (no schema migration).
- Add a comment to `ChallengeType.behavioral` explaining "not yet implemented; present in the enum so existing rows decode, but uncreatable in UI."
- Leave the `EmptyView()` placeholder — it's already correctly silent.
- No further action needed; the runtime gate already prevents users from reaching the dead code path.

### D. Wire `scheduleChallengeEndingReminder` on accept

`PushNotificationService.scheduleChallengeEndingReminder(challenge:)` (`MojoiOS/Core/Social/PushNotificationService.swift:82-101`) exists but has no callers. The natural call site is `ChallengeService.acceptChallenge` after the Firestore write succeeds (line ~554).

`ChallengeService` doesn't currently hold a reference to `PushNotificationService`. Same pattern: add `attachPushNotifications(_:)` and wire it in `DependencyContainer`. Or — given that the existing `attachActivityFeed` and the new `attachSocialService` calls are growing — collapse to a single `attach(activityFeed:social:push:)` method on `ChallengeService` and update the one DI call site. I'll go with the consolidated method since it scales better.

After accept, schedule the local reminder. The function already gates on `endDate > now` and uses `UNUserNotificationCenter`, so no further checks needed.

### E. Local notification when one of *my* outgoing challenges flips to .accepted or .declined

Since there's no remote push backend, the creator only learns the verdict when they next foreground the app. The existing `ChallengeService` real-time listener (which surfaces `.completed` via `handleCompletionSnapshot`) gives us the hook for free — extend it to detect `.pending → .active` and `.pending → .declined` transitions on challenges where `creatorUserId == currentUserId`, and post a `UNNotificationRequest` for each.

- Compare incoming Firestore status against the locally cached `Challenge.statusRaw` to detect the transition (the cache is the prior state of record).
- Only fire for the *creator* on accept/decline (the opponent already saw the action they themselves took).
- Notification copy: `"{opponentName} accepted your challenge"` / `"{opponentName} passed on your challenge"`.
- Use `UNUserNotificationCenter.current().add(request)` directly — no scheduling needed since the transition itself is the trigger event.

The activity-feed event from step A is the in-app surface; this local notification is the at-a-glance surface for users whose app is in the background.

## Files to modify

- `MojoiOS/Core/Social/ChallengeService.swift` — add `attachSocialService`/consolidated `attach`; emit events at create/accept/decline/complete; fire `scheduleChallengeEndingReminder` on accept; emit local notifications on `.pending → .active` / `.declined` for creator.
- `MojoiOS/Core/Social/SocialService.swift` — emit `.friendAdded` in `acceptFriendRequest` (line ~684) and `acceptFriendInvite` (line ~614).
- `MojoiOS/Core/Social/ActivityFeedService.swift` — add `startListening` / `stopListening` + snapshot listener; extract `makeEvent(from:)` helper.
- `MojoiOS/Core/DependencyContainer.swift:93-94` — replace `attachActivityFeed` with the consolidated `attach(...)` call.
- `MojoiOS/UI/Friends/FriendsTabView.swift` — call `activityFeedService.startListening()` in `.task` after `fetchFriends`; `stopListening()` in `.onDisappear`.
- `MojoiOS/Models/Challenge.swift` — one-line documentation comment on `ChallengeType.behavioral` clarifying it's reserved/unreachable.

No SwiftData schema changes. No new files.

## Reused utilities (do not duplicate)

- `ActivityFeedService.postEvent` (`ActivityFeedService.swift:119`) — fire-and-forget event poster.
- `StatsSyncService.emitGoalEventIfNeeded` (`StatsSyncService.swift:258`) — pattern reference for `visibleTo` construction (`[userId] + friendIds`) and `actorName` resolution (`authService.displayName ?? "Friend"`).
- `ActivityEvent.displayText` (`ActivityEvent.swift:59`) — already handles all 8 cases; no UI work needed.
- `PushNotificationService.scheduleChallengeEndingReminder` (`PushNotificationService.swift:82`) — already complete; just needs a caller.
- `UNUserNotificationCenter.current()` — used elsewhere in `PushNotificationService`; reuse for the accept/decline local notifications.

## Verification

End-to-end test on a build with two test accounts (A and B, mutual friends):

1. **Friend added**
   - From B's device: tap the invite link from A. B's feed should show "Bob added Alice" within 3 seconds. A's feed should show the same event (live, via the new listener).

2. **Challenge created**
   - From A's device: create a `timeTarget` challenge against B. A's feed and any of A's other friends should see "Alice sent {title}". B's feed should see it too (B is in `visibleTo`).

3. **Challenge accepted**
   - From B's device: tap Accept. Both feeds should show "Alice and Bob started a challenge". A should also receive a local notification "Bob accepted your challenge". A's `scheduleChallengeEndingReminder` fires N days before `endDate`.

4. **Challenge declined**
   - Repeat #2, then on B's device tap Pass. Only A and B see "Bob declined a challenge" — friends of A and B do NOT see it (`visibleTo = [A, B]` only).

5. **Challenge completed**
   - Force a completion (or wait for the natural end). Both feeds — and friends of both — see "{winner} completed a challenge". The deterministic `documentId` ensures only one row appears even though both clients write.

6. **Real-time listener**
   - With A's app open on the Friends tab and B's app foregrounded, perform any of the above on B's device. A's feed should update without a manual pull-to-refresh, within ~1 second.

7. **Behavioral challenge unreachable**
   - Open the Create sheet — only `Time Target` and `App Detox` presets visible. No regression.

8. **Build green**
   - `xcodebuild -scheme MojoiOS -destination 'platform=iOS Simulator,name=iPhone 17 Pro' -configuration Debug build`

9. **Smoke test on simulator**
   - Sign in, sign out, sign back in. The cached feed (SwiftData) should hydrate immediately, then the snapshot listener should reconcile within ~1 second.
