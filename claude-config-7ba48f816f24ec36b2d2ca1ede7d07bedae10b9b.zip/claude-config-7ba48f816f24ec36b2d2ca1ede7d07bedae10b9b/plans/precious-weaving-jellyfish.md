# Rename: Kuse Cowork → Local Cowork (with minimal logo)

## Context

The project is being rebranded from **Kuse Cowork** to **Local Cowork**. The fork already lives at `github.com/23jmo/local-cowork` and `package.json` is partially updated, but ~60+ references remain across TypeScript, Rust, JSON config, GitHub workflows, and docs. We also need to drop the existing `public/logo.png` (a non-minimal raster mark) and replace it with a low-key square logo that fits the locked Kiln-F design language (terracotta `#C2410C` on warm cream).

This rename is treated as a **clean break** — no migration shim for existing user data. If real users with existing `~/Library/Application Support/kuse-cowork/` data exist, they will start fresh after the rename.

## Defaults chosen (flip any of these on review)

| Decision | Default |
|---|---|
| Logo style | Solid terracotta square SVG, slightly rounded corners, no glyph |
| Data migration | Clean break — old `kuse-cowork` data dir orphaned |
| Bundle ID | `ai.local.cowork` (mirror of current `ai.kuse.cowork` shape) |
| npm/Cargo crate | `local-cowork` |
| Rust lib name | `local_cowork_lib` |
| Repo dir on disk | Leave as `kuse_cowork` — internal rename only |

## Naming map

| Old | New |
|---|---|
| `Kuse Cowork` (display) | `Local Cowork` |
| `kuse-cowork` (npm/crate) | `local-cowork` |
| `kuse_cowork_lib` (Rust lib) | `local_cowork_lib` |
| `ai.kuse.cowork` (bundle ID) | `ai.local.cowork` |
| `kuse-cowork-*` (localStorage keys) | `local-cowork-*` |
| `kuse-cowork` (data dir name) | `local-cowork` |
| `~/.kuse-cowork` (legacy skills path) | `~/.local-cowork` |

## Files to modify

### 1. Tauri / app metadata
- **`src-tauri/tauri.conf.json`** — `productName`, `identifier`, window `title`
- **`src-tauri/Cargo.toml`** — `[package].name`, `[lib].name`, `repository` URL
- **`src-tauri/src/main.rs:7`** — `kuse_cowork_lib::run()` → `local_cowork_lib::run()`
- **`package.json`** — `"name"` field (repo URL is already `23jmo/local-cowork`, leave it)
- **`package-lock.json`** — `"name"` (lines 2 & 8). Will also auto-regenerate on `npm install`.
- **`index.html:7`** — `<title>` tag

### 2. UI strings (display name)
- **`src/App.tsx:320`** — loading screen `<h1>`
- **`src/components/Sidebar.tsx:24-25`** — `alt` text + `<h1 class="logo-text">`
- **`src/components/TaskSidebar.tsx:50-51`** — `alt` text + `<h1 class="app-title">`

### 3. Agent persona / system prompts
- **`src-tauri/src/agent/types.rs:122`** — `DEFAULT_SYSTEM_PROMPT` `"You are Kuse Cowork…"` → `"You are Local Cowork…"`
- **`src-tauri/src/commands.rs:649`** — `system_prompt` formatted string

### 4. MCP client identification
- **`src-tauri/src/mcp/http_client.rs:54-55`** — client `name` and `title` fields sent on MCP init

### 5. Storage paths & identifiers (clean break — no migration)
- **`src/lib/tauri-api.ts`** (13 sites: 124, 151, 194, 210, 226, 237, 238, 247, 255, 397, 430, 440, 473) — replace `kuse-cowork` prefix on every localStorage key with `local-cowork`
- **`src-tauri/src/database.rs:183`** — `data_dir.join("kuse-cowork").join("kuse-cowork.db")` → `data_dir.join("local-cowork").join("local-cowork.db")`
- **`src-tauri/src/skills/mod.rs:16`** (and references at 123, 183) — `app_data.join("kuse-cowork").join("skills")` → `local-cowork`
- **`src-tauri/src/tools/docker.rs:139`** — container name prefix `kuse-cowork-{uuid}` → `local-cowork-{uuid}`
- **`src-tauri/src/tools/file_read.rs:124,129`** — test path `~/.kuse-cowork/test` and assertion

### 6. UI text mentioning data paths
- **`src/components/SkillsList.tsx:46,102,103,104`** — user-facing macOS / Windows / Linux skill paths (`~/Library/Application Support/kuse-cowork/skills/`, etc.)

### 7. CI / release
- **`.github/workflows/dev-build.yml`** (lines 120, 128, 136) — artifact name template
- **`.github/workflows/release.yml:68,89`** — `releaseName: 'Kuse Cowork v__VERSION__'` and `/Applications/Kuse Cowork.app` path

### 8. Documentation
- **`README.md`** — title, intro, every "Kuse Cowork" / "Kuse_cowork" / "Kuse" mention (lines 4, 17, 18, 26, 54, 55, 129, 130, 145, 227–255), and the logo `<img>` tag (point at the new file)
- **`DESIGN.md:3`** — `Kuse Cowork "Kiln F" design language` → `Local Cowork "Kiln F" design language`

### 9. Logo replacement
- **Create `public/logo.svg`** — solid terracotta `#C2410C` rounded square, e.g. 256×256 viewBox, ~40px corner radius. Will inline as a single `<rect>`.
- **Update `src/components/Sidebar.tsx:24` and `src/components/TaskSidebar.tsx:50`** — change `src="/logo.png"` → `src="/logo.svg"`. SVG scales perfectly at 32px / 36px sidebar slots, no raster artifacts.
- **Create `public/icon.svg`** — same square, used by `index.html:5` favicon (currently broken — file doesn't exist on disk).
- **Delete `public/logo.png`** and **`public/kuse-logo.png`** — both raster, no longer referenced after the swap.
- **Regenerate Tauri bundle icons** in `src-tauri/icons/` from the new SVG. Use Tauri CLI: `npx @tauri-apps/cli icon public/logo.svg`. This regenerates `32x32.png`, `128x128.png`, `128x128@2x.png`, `icon.icns`, `icon.ico`, plus all `Square*.png` mobile icons and the `android/` + `ios/` subtrees in one shot. **Note:** I'll prepare the SVG and document the command — actually running it requires writing the binary icon files, which is part of the implementation phase.
- **Update `README.md:4`** to point at `public/logo.svg` instead of `public/kuse-logo.png`.

### 10. Auto-generated files (no manual edit needed)
- `src-tauri/Cargo.lock` — regenerates on `cargo check`
- `src-tauri/gen/schemas/capabilities.json` — regenerates on next Tauri build
- `package-lock.json` — name field needs manual edit, dep tree regenerates on `npm install`

## Logo SVG (proposed)

```svg
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256">
  <rect width="256" height="256" rx="48" ry="48" fill="#C2410C"/>
</svg>
```

That's it. Single rect, brand terracotta, 48px radius (≈18% of side, the Kiln-F card-radius ratio). Reads as a clean tile at 32px in the sidebar and as a recognizable app icon at all bundle sizes.

## Execution order

1. **Logo first** — write `public/logo.svg` and `public/icon.svg`, swap the two `<img src>` references, delete the old PNGs.
2. **Identifiers** — `package.json`, `Cargo.toml`, `main.rs`, `tauri.conf.json`. After this, `cargo check` must still pass (the `kuse_cowork_lib::run()` → `local_cowork_lib::run()` rename has to land in lockstep with the `[lib].name` rename or the build breaks).
3. **Storage paths** — `database.rs`, `skills/mod.rs`, `docker.rs`, `tauri-api.ts` localStorage keys. Single sweep.
4. **UI strings** — `Sidebar.tsx`, `TaskSidebar.tsx`, `App.tsx`, `index.html`, `SkillsList.tsx`, `agent/types.rs`, `commands.rs`, `mcp/http_client.rs`.
5. **CI + docs** — workflows, `README.md`, `DESIGN.md`.
6. **Regenerate Tauri bundle icons** from `public/logo.svg`.
7. **Verification** (see below).

## Verification

Per `CLAUDE.md`, CI gates on three checks. Run all three locally:

```bash
npx tsc --noEmit                                   # TypeScript type check
cd src-tauri && cargo check                        # Rust compile check
cd src-tauri && cargo clippy -- -D warnings        # Rust lints (zero warnings)
```

Then a manual smoke test (user runs `npm run tauri:dev` themselves per their preference):
- Window title in the title bar reads **Local Cowork**.
- Sidebar logo is the new terracotta square SVG and the heading reads **Local Cowork**.
- Loading screen text reads **Local Cowork**.
- Open settings, send a chat message, create a new conversation — verify it persists (confirms the new localStorage / DB paths work end-to-end).
- Open `~/Library/Application Support/local-cowork/` and confirm `local-cowork.db` exists; old `kuse-cowork` dir, if present, should be untouched (we're not deleting user data).
- Quick `grep -ri 'kuse' .` from the repo root after the rename should return zero hits outside `target/`, `node_modules/`, `.git/`, and the `kuse_cowork` directory name itself.

## Critical files (for quick reference during execution)

- `src-tauri/tauri.conf.json` — productName, identifier, window title
- `src-tauri/Cargo.toml` — package name, lib name, repository URL
- `src-tauri/src/main.rs` — lib call (must match Cargo.toml `[lib].name`)
- `src-tauri/src/database.rs:183` — DB path
- `src-tauri/src/skills/mod.rs:16` — skills dir
- `src/lib/tauri-api.ts` — 13 localStorage keys
- `src/components/Sidebar.tsx` and `src/components/TaskSidebar.tsx` — logo `<img>` + heading
- `index.html` — `<title>` and favicon link
- `public/logo.svg` (new), `public/icon.svg` (new)
- `README.md` — extensive copy
