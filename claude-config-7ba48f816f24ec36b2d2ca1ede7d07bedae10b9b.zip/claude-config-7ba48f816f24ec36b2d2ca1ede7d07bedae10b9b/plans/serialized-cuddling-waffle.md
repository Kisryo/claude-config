# Plan: Finalize `/init` + suggested improvements for `jmoui`

## Context

User ran `/init suggest improvements to this` in the `jmoui` repo — a Claude Code skill specification (not a runnable package). They chose **Project CLAUDE.md only** (no personal file, no skills, no hooks) and asked for improvement suggestions.

Phase 1–4 of `/init` completed before plan mode activated: `CLAUDE.md` was written at the project root. Remaining work is (a) confirming the file reads well, and (b) presenting the improvement punch list the command args asked for.

## Already done (before plan mode)

`CLAUDE.md` at `/Users/johnathanmo/jmoui/CLAUDE.md` — covers:
- This is a skill spec, not a Node package (no `package.json`, no build)
- Pushing `main` ships the skill (install pulls from GitHub HEAD)
- Key files: `SKILL.md` (canonical), `README.md` (landing page), `demo.mp4` (untracked)
- Editing rules: frontmatter `description` is load-bearing; keep code blocks runnable; React-primary; terse voice; no unsolicited sections
- Test loop: edit → push → `npx skills add` → `/reload-plugins` → `/jmoui`

## Remaining work — improvement suggestions (ordered by impact)

Present these to the user as a to-do list. For each, they can ask me to act on it or skip.

1. **`demo.mp4` is 1.2 MB and untracked.** Decide now: (a) add to `.gitignore` and host elsewhere (YouTube/Loom/CDN), (b) commit as-is (bloats `git clone` forever), or (c) move to Git LFS. Untracked + referenced is the worst case — it's in the working tree but invisible to anyone who clones.

2. **No versioning / release signal.** `npx skills add` pulls `main` HEAD, so every push is a release to existing users. Consider: (a) tag releases (`v0.1.0`) and document that the install resolves to the latest tag when tags exist, or (b) add a `CHANGELOG.md` entry each time `SKILL.md` changes meaningfully so users can tell when behavior shifted.

3. **README doesn't link to `SKILL.md`.** Browsers on GitHub see only the README. A one-line "Full spec: [SKILL.md](./SKILL.md)" near the top lets curious users read the actual trigger rules and flow before installing.

4. **No local dev loop.** The current loop (edit → push → reinstall) has a ~30s latency per test. A `scripts/link-local.sh` that symlinks this repo into `~/.claude/skills/jmoui` would let the user test edits instantly. Could live as a doc note or a one-line script — no build system needed.

5. **`SKILL.md` is 265 lines in a single file.** Still readable, but if it grows, the code block for `UIPickerOverlay.jsx` (~95 lines) could move to `examples/UIPickerOverlay.jsx` and be referenced from SKILL.md. Keeps the spec's prose flow tighter without losing the reference.

6. **`.gitignore` doesn't cover common macOS / editor cruft** beyond `.DS_Store`. Adding `.vscode/`, `.idea/`, `*.swp`, `Thumbs.db` is cheap insurance.

7. **No `LICENSE` file.** README says MIT but there's no `LICENSE` file at the root. GitHub won't render the license badge and some package tools complain. Add the standard MIT text.

## Non-recommendations (explicitly not suggesting)

- Tests / CI — there's no code to test. A JSON-schema check on frontmatter would be theater.
- A package.json — this isn't a package. Adding one invites confusion.
- Personal `CLAUDE.local.md` — user declined; no signal it's needed for a solo project.
- Skills or hooks — user declined; no formatter/linter exists for this to attach to anyway.

## Verification

No code to test. To verify CLAUDE.md is correct: `cat /Users/johnathanmo/jmoui/CLAUDE.md` — confirm the editing rules match what the user selected in the gap-fill questions (keep code blocks runnable, React-primary, match voice, no unsolicited sections). If any of the improvement items above get accepted, verify per-item:

- `demo.mp4` decision → confirm `.gitignore` or LFS config reflects it
- Versioning → `git tag --list`
- README link → `grep SKILL.md README.md`
- Local dev loop → script exists and is executable
- Split of `UIPickerOverlay` → file exists under `examples/` and SKILL.md links to it
- `.gitignore` → `cat .gitignore`
- LICENSE → file exists and matches MIT text

## Files to modify (if user accepts items)

- `/Users/johnathanmo/jmoui/.gitignore` — items 1, 6
- `/Users/johnathanmo/jmoui/README.md` — item 3
- `/Users/johnathanmo/jmoui/SKILL.md` — item 5 (light)
- `/Users/johnathanmo/jmoui/examples/UIPickerOverlay.jsx` — item 5 (new)
- `/Users/johnathanmo/jmoui/scripts/link-local.sh` — item 4 (new)
- `/Users/johnathanmo/jmoui/LICENSE` — item 7 (new)
- Git tags — item 2 (no file)
