# Drag Interaction Fix — First-Motion Direction Routing

## Context

The screen time chart's gesture stack regressed after the layered overlay rewrite. Two
problems remain:

1. **Chart scrub is broken.** The current direction filter inside `HourJournalingOverlay`'s
   pan handler (`absX > 6 && absX > absY * 1.4`) is per-frame and too strict — if the
   first few points of motion aren't sharply horizontal-dominant the scrub never engages,
   and even when it does, both the chart's scrub *and* the parent's day-swipe
   sky-preview fire simultaneously, producing competing visual feedback.
2. **Hero number text eats vertical scrolls.** The centered avatar/number `VStack`
   in the GIF region is hit-testable, so vertical pans that start on the number don't
   reach `ScrollView` (or the day-swipe layer) and the page can't scroll.

User intent (most recent message + clarification):
- *"check if the first swipe motion is more vertical or horizontal. If vertical, do
  the pass-through that we're doing now (because it's working), and if horizontal,
  render the Drag thing… [the] times per hour bar"*
- Hero number text should be **scroll-transparent only** — vertical drags scroll the
  page; horizontal drags can still flip days via the existing day-swipe layer.

## Approach

Three small, targeted edits. No new types, no new gesture infrastructure — the
`ScrollFriendlyPanGesture` UIKit wrapper already gives us simultaneous recognition
with `ScrollView`'s pan, so the only changes are *when* each callback engages.

### 1. First-motion direction lock in the chart overlay
**File:** `MojoiOS/UI/Dashboard/Components/HourJournalingOverlay.swift` (~lines 80–122)

Replace the per-frame `isHorizontal` check with a one-shot decision committed at
first significant motion. Add a per-gesture `@State` enum:

```swift
private enum GestureMode { case undecided, scrubbing, ignored }
@State private var gestureMode: GestureMode = .undecided
```

In `onPanChanged`:

```swift
let absX = abs(state.translation.width)
let absY = abs(state.translation.height)

switch gestureMode {
case .undecided:
    // Wait for the user to actually move before deciding.
    guard max(absX, absY) >= 6 else { return }
    if absX > absY {
        gestureMode = .scrubbing
        // fall through into the scrubbing update below
    } else {
        gestureMode = .ignored
        return
    }
case .ignored:
    return
case .scrubbing:
    break
}

// Scrub update (unchanged from existing body of the if-isHorizontal branch):
if !isScrubbingChart { isScrubbingChart = true }
let h = hour(at: state.location.x, barWidth: barWidth, spacing: barSpacing)
scrubHour = h
if !didScrub {
    withAnimation(.easeOut(duration: Self.fadeDuration)) { didScrub = true }
    Self.lightHaptic.prepare()
    Self.lightHaptic.impactOccurred()
    lastHapticHour = h
} else if h != lastHapticHour {
    Self.lightHaptic.impactOccurred()
    lastHapticHour = h
}
```

In `onPanEnded`: reset `gestureMode = .undecided` alongside the existing teardown.

Once `.scrubbing` is committed, subsequent vertical drift does **not** disengage the
scrub — that matches the user's request that horizontal-first means scrub for the
rest of the gesture.

### 2. Suppress day-swipe preview while the chart is scrubbing
**File:** `MojoiOS/UI/Dashboard/DashboardView.swift` (~lines 1174–1213, the
`.overlay { ScrollFriendlyPanGesture(...) }` on the gifBlock)

Add a guard at the top of `onPanChanged`, mirroring the one already in `onPanEnded`:

```swift
onPanChanged: { state in
    if isScrubbingChart {                  // ← NEW
        onSwipeCancel()
        return
    }
    let h = state.translation.width
    let v = abs(state.translation.height)
    guard abs(h) > max(8, v * 1.1) else {
        onSwipeCancel()
        return
    }
    // …unchanged…
}
```

Both pan recognizers fire simultaneously on horizontal drags inside the chart card
(chart's recognizer flips `isScrubbingChart = true` synchronously via the
`@Binding`). This guard keeps the sky from scrubbing while a bar is highlighted.

### 3. Make the hero number `VStack` scroll-transparent
**File:** `MojoiOS/UI/Dashboard/DashboardView.swift` (~lines 1103–1152, the centered
metric overlay on `gifBlock`)

Add `.allowsHitTesting(false)` to the entire metric `VStack`. The avatar, optional
chat-bubble, hero label, and `metric()` content all live inside; none of them need
to be tappable in this surface. Disabling hit-testing on the wrapping container
ensures vertical pans starting on the number always fall through to:

- the day-swipe `ScrollFriendlyPanGesture` layer below (which ignores
  vertical-dominant drags), and
- the ancestor `ScrollView`'s pan (composed via the recognizer's `simultaneously`
  delegate).

```swift
.frame(maxWidth: .infinity, maxHeight: 260)
.offset(y: -Self.avatarLiftOffset)
.allowsHitTesting(false)   // ← NEW
```

This satisfies the "Scroll-transparent only" choice — horizontal day-flips still
work because the day-swipe layer sits below the metric and remains hit-testable;
the `.allowsHitTesting(false)` only affects the metric subtree.

## Files modified

- `MojoiOS/UI/Dashboard/Components/HourJournalingOverlay.swift` — add
  `GestureMode` state and rewrite the `onPanChanged` direction filter; reset on
  `onPanEnded`.
- `MojoiOS/UI/Dashboard/DashboardView.swift` — add the `isScrubbingChart` guard at
  the top of the day-swipe `onPanChanged`; add `.allowsHitTesting(false)` to the
  centered metric `VStack`.

## Reused utilities (no changes)

- `ScrollFriendlyPanGesture` (`MojoiOS/UI/Components/ScrollFriendlyPanGesture.swift`)
  — its simultaneous-recognition delegate is what lets `ScrollView` keep
  scrolling alongside both pan layers.
- `isScrubbingChart` `@Binding` already plumbed from `HourJournalingOverlay` to
  `ScreenTimeMeadowHero`.

## Verification

Build and run on the iOS simulator:

```
xcodebuild -scheme MojoiOS -configuration Debug build
```

(or `mcp__XcodeBuildMCP__build_run_sim` once defaults are confirmed via
`session_show_defaults`).

Then on the Dashboard:

1. **Vertical drag on the chart card** → page scrolls; no bar highlight or
   tooltip appears; no day preview kicks in.
2. **Vertical drag on the hero number** → page scrolls. (Previously stuck.)
3. **Horizontal drag on the chart card** → bar highlights with tooltip; haptic
   ticks per bar; sky/day preview does **not** also scrub.
4. **Vertical-then-horizontal drag on the chart** (start vertical, drift
   horizontal) → page scrolls; chart never engages. Direction is locked at first
   motion.
5. **Horizontal-then-vertical drag on the chart** (start horizontal, drift
   vertical) → bar scrub stays engaged across vertical drift; tooltip continues
   to track the bar under the finger's x.
6. **Tap a chart bar** → hour-detail sheet opens.
7. **Horizontal swipe in the GIF area outside the chart card** → day flips
   (back/forward) at the existing 72pt commit threshold.
8. Repeat 1–6 on a past day (swipe back) → confirm history-backed minute
   readouts (`hourlyTotals(on:)`) still populate the tooltip.
