# Plan: Move referral/invite hosting from Firebase → Vercel (argue-landing.vercel.app)

## Context

The Mojo iOS app currently generates invite/referral links pointing at `https://mojo-ios-c558e.web.app/invite/{code}` and declares `applinks:mojo-ios-c558e.web.app` in its entitlements so iOS treats those links as Universal Links into the app. The referral system is fully wired end-to-end (committed in `ba0735b`) and Firebase Hosting is serving the AASA + invite landing page correctly.

The user wants invite links to live on **`argue-landing.vercel.app`** instead, so the referral system runs on top of the same Vercel-hosted landing where the marketing site lives. Right now `argue-landing.vercel.app/` serves the root marketing page (200), but `/.well-known/apple-app-site-association` and `/invite/*` both 404 — nothing referral-related has ever been deployed to Vercel.

**Scope constraint (user-confirmed):** The iOS app should *cut over* to Vercel, but **do not touch `firebase/public/`** — leave the Firebase hosting files in place (they'll just go unused). Firestore rules and Cloud Functions stay on Firebase regardless; this change is *only about which host serves the AASA + invite landing*.

**Open risk (user-confirmed uncertain):** Whether `argue-landing.vercel.app` deploys from the local `argue-landing/` directory via a GitHub integration, or from a separate repo. The plan handles both — deploy is a `vercel` CLI invocation from `argue-landing/`, which prompts to link to the existing project on first run.

---

## Files to Modify

### 1. Move the AASA file into the Vercel build

Vite's `publicDir` defaults to `public/` and copies that folder verbatim into `dist/`.

**Create:** `argue-landing/public/.well-known/apple-app-site-association`

Copy content from `firebase/public/.well-known/apple-app-site-association`:

```json
{
  "applinks": {
    "apps": [],
    "details": [
      {
        "appID": "BJLT45779D.com.mo.MojoiOS",
        "paths": ["/invite/*"]
      }
    ]
  }
}
```

### 2. Move the invite landing page

**Create:** `argue-landing/public/invite/index.html`

Copy verbatim from `firebase/public/invite/index.html`. This is a static HTML that parses the code from `window.location.pathname` and shows a "Join" card with a Universal Link button. No rebranding in this pass — it still says "Join Argue"; leaving as-is per the user's preference to minimize changes. Flag as a follow-up.

### 3. Add Vercel hosting config

**Create:** `argue-landing/vercel.json`

```json
{
  "headers": [
    {
      "source": "/.well-known/apple-app-site-association",
      "headers": [{ "key": "Content-Type", "value": "application/json" }]
    }
  ],
  "rewrites": [
    { "source": "/invite/:code", "destination": "/invite/index.html" }
  ]
}
```

The rewrite ensures `/invite/ABC123` serves `/invite/index.html` (the JS in that file reads the pathname to display the code). The header override is Apple's strict `application/json` requirement for AASA — Vercel serves `.well-known` as `text/plain` by default, which `swcd` will reject.

### 4. Swap the iOS entitlement domain

**Modify:** `MojoiOS/MojoiOS.entitlements`

Change:
```xml
<string>applinks:mojo-ios-c558e.web.app</string>
```
to:
```xml
<string>applinks:argue-landing.vercel.app</string>
```

User chose full cutover in the entitlement, so the old domain is removed. Any TestFlight build with the old entitlement will keep working against Firebase Hosting (which is left intact) until it's superseded.

### 5. Swap the link-generation domain

**Modify:** `MojoiOS/Core/Social/InviteLinkService.swift` line 19

```swift
static let hostingDomain = "argue-landing.vercel.app"
```

`InviteLinkService.getShareLink()` interpolates `hostingDomain` into `https://\(hostingDomain)/invite/\(code)`. No other reference anywhere in the Swift codebase.

### Files explicitly **not** modified

- `firebase/firebase.json`, `firebase/public/**`, `firebase/firestore.rules`, `firebase/functions/**` — per user direction, Firebase Hosting stays live as-is. Firestore + Functions are unaffected by the host change.
- `argue-landing/index.html`, `src/style.css`, `tailwind.config.js` — root marketing page is untouched; this plan only adds `public/` contents + `vercel.json`.

---

## Verification

### Deploy sequence

1. From `argue-landing/`, run `vercel link` — CLI prompts to link to an existing Vercel project. If the `argue-landing.vercel.app` project is owned by the same account, pick it. If `vercel link` shows no match, user clarifies deploy source (separate repo, GitHub-integration trigger, etc.) before proceeding.
2. `npm run build` — confirm `dist/.well-known/apple-app-site-association` and `dist/invite/index.html` are present in the build output.
3. `vercel --prod` — deploys. Or, if GitHub-integrated, commit + push and let auto-deploy run.

### Post-deploy smoke tests (curl)

```bash
curl -sI https://argue-landing.vercel.app/                                              # expect: 200
curl -s  https://argue-landing.vercel.app/.well-known/apple-app-site-association        # expect: real appID + /invite/* path
curl -sI https://argue-landing.vercel.app/.well-known/apple-app-site-association | grep content-type   # expect: application/json
curl -sI https://argue-landing.vercel.app/invite/TEST123                                # expect: 200 (rewrite working)
```

All four must pass before the iOS changes are useful.

### iOS build verification

```bash
xcodebuild -scheme MojoiOS -configuration Debug \
  -destination 'platform=iOS Simulator,name=iPhone 17 Pro' build
```

Expect green.

### End-to-end Universal Link test

1. Install a fresh build of MojoiOS on a physical iOS device (simulator Universal Links are flaky).
2. On the device, sign in and tap "Share invite" — confirm the generated link is `https://argue-landing.vercel.app/invite/XXXXXX`.
3. Paste the link into Messages (send to self), then tap it from Messages — it should open the Mojo app directly, not Safari. If it opens Safari, AASA cache hasn't propagated yet; wait ~5 min and cold-launch the app once to force a refetch, or run `sudo swcutil reset -d argue-landing.vercel.app` on the dev Mac with the device tethered.
4. Referee accepts in-app → confirm `/referrals/{referrerId}_{refereeId}` document appears in Firestore (unchanged path — Firestore is host-agnostic).

### Rollback

If Universal Links break after cutover, add `applinks:mojo-ios-c558e.web.app` back into the entitlement alongside the Vercel domain (iOS supports multiple) and ship a hotfix. Firebase Hosting is still live, so old links immediately start working again.

---

## Critical Files

| File | Action | Purpose |
|------|--------|---------|
| `argue-landing/public/.well-known/apple-app-site-association` | Create | Apple Universal Link manifest |
| `argue-landing/public/invite/index.html` | Create | Invite landing page (copied from firebase/public) |
| `argue-landing/vercel.json` | Create | AASA content-type + invite rewrite |
| `MojoiOS/MojoiOS.entitlements` | Modify | Swap `applinks:` domain |
| `MojoiOS/Core/Social/InviteLinkService.swift` | Modify | Swap `hostingDomain` constant |

---

## Follow-ups (not in this PR)

- Rebrand invite landing from "Join Argue" → "Join Mojo" if/when product voice is finalized.
- Decide whether to add a custom domain (e.g., `mojo.app`) later — entitlement update would be the same shape as this one.
- Eventually delete `firebase/public/` once confident no production build relies on the old domain.
