# Plan: Own Screen Time data host-side

## Context

Today, all per-app screen-time UI in Mojo is rendered inside the `MojoDeviceActivityReport` (DAR) extension. This forces several limitations:

- **No interactivity:** Buttons inside DAR cannot reach the host (no `openURL`, no `Link`, no Darwin notifications, no App Group writes for per-app data — Apple's privacy sandbox, verified by DTS Quinn in forum thread 728044 and a 5-agent audit on 2026-04-27).
- **Apple-stock styling constraints:** While SwiftUI in DAR is customizable, sheets/modals/navigation inside DAR are bound to the DAR's frame and cannot present host UI.
- **No journaling/tagging surface:** The "+ Time well spent?" pill we just added in `MojoTopAppsReportView.swift` is purely decorative — taps go nowhere.

We want to flip this: own the per-app data host-side so we can render polished, fully-interactive UI inspired by JOMO. Goals:

1. **Top Apps list (host-rendered):** JOMO-style "Most used" with top 9 apps as full rows + a 10th "Other" row that bundles remaining tracked apps' icons. Functional "+ Time well spent?" button that opens a host sheet and persists journal entries.
2. **Screen-time chart icons:** Per-hour app icons (most-used app each hour) overlaid above each bar. Per-hour journaling via transparent host overlay buttons.
3. **Foundation for future:** Argo (the LLM agent) gets cleaner programmatic access to per-app usage; future features (custom analytics, cross-day rollups) can read from a host-side data source instead of a sandboxed extension.

The **architectural pivot** is moving from "DAR computes + renders, host displays" to a **DAM-threshold-event-encoding pattern** (kingstinct/RNDA OSS pattern): the host registers per-app fine-grained `DeviceActivityEvent` thresholds, the DAM extension receives `eventDidReachThreshold` callbacks and writes the encoded event names to App Group, and the host decodes back to `(token, bucketMinutes)` pairs for rendering.

User decisions locked:
- **Tracked-apps source:** Separate `trackedApps: FamilyActivitySelection`, seeded once from blocked apps + popular categories (Social/Entertainment/Games), editable in Settings.
- **Scope:** Full plan — host Top Apps + chart icons + per-hour journaling.

## Critical constraints to design around

- **iOS 26.2 bug FB21450954:** `eventDidReachThreshold` fires prematurely (~50% of days) for per-app filters. Mitigation: display rounded buckets (`~5m`), add an "approximate" caption to the Top Apps card.
- **DA schedule limits:** ~20 events per `DeviceActivitySchedule`, ~50 active activities per app. We use **one activity per tracked app** with up to 7 bucket events each. Hard cap UI at **15 tracked apps** to leave headroom for blocking + reblock activities.
- **Minimum schedule interval = 16 min** (per `TimedAccessManager.deviceActivityMinimumInterval`); minimum threshold = 60s. Daily 00:00–23:59 schedule satisfies both.
- **`hashValue` is empirically stable** for `ApplicationToken` within an iOS major version (existing reblock code relies on this). Persist a slug→tokenData map as source of truth so we don't depend on hash stability across iOS upgrades.

## Architecture (hybrid)

| Surface | Renderer | Data path |
|---|---|---|
| Top Apps list (top 9 + Other) | **Host** | DAM threshold events → App Group dict → `TrackedAppsTracker` → SwiftUI |
| Hourly chart bars | **DAR** | Existing `AppUsageSnapshot.hourlyTotals` (works inside extension) |
| Per-hour app icons over bars | **DAR** | Existing `AppUsageSnapshot.appsToday[].hourlyBreakdown` (already populated in extension) |
| Per-hour journaling tap targets | **Host overlay** | Transparent button grid positioned over the DAR chart via `GeometryReader` |
| "+ Time well spent?" pill | **Host** | Real `Button` → sheet → SwiftData |

## Implementation phases

### Phase 1 — Tracked apps foundation

**Files to modify:**
- `MojoiOS/Core/ScreenTime/ScreenTimeManager.swift` — add `@Published var trackedApps: FamilyActivitySelection` with persistence to App Group key `screenTime.trackedSelection.v1`. Mirror the existing `blockedApps` pattern (lines 27–32, 243–250).
- `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift` — add keys: `trackedSelectionKey`, `trackedSlugMapKey`, `trackedFiringsFilename`, `dailyTrackActivityPrefix = "com.mo.MojoiOS.dailyTrack."`, `dailyTrackEventPrefix = "st-track."`.
- New: `MojoiOS/Core/ScreenTime/TrackedAppsManager.swift` — owns:
  - `register()` — iterates `trackedApps.applicationTokens`, builds slug→token map, persists to App Group, calls `DeviceActivityCenter.startMonitoring` for each app.
  - `slug(for: ApplicationToken) -> String` — `t-\(abs(token.hashValue))`, with collision detection at registration.
  - `token(for: String) -> ApplicationToken?` — reverse lookup using cached slug map.
- New: `MojoiOS/UI/Settings/TrackedAppsView.swift` — picker UI parallel to `BlockedAppsView` but without budget/open controls. Reuse `FamilyActivityPicker` binding pattern from `BlockedAppsView.swift` lines 243–295. Cap selection at 15 with an inline warning.
- `MojoiOS/UI/Onboarding/Screens/OB14_ChooseAppsView.swift` — after the user picks blocked apps, seed `trackedApps` = blocked + Social/Entertainment/Games categories (one-time). User can edit later in Settings.
- `MojoiOS/UI/Profile/ProfileView.swift` — add a "Tracked Apps" settings row (per memory: settings rows live in ProfileView, not SettingsView).

### Phase 2 — DAM threshold scheduling

**Files to modify:**
- `MojoiOS/Core/ScreenTime/TrackedAppsManager.swift` (continued from Phase 1):
  - Bucket ladder: `[1, 5, 15, 30, 60, 120, 240]` minutes (7 events per app).
  - For each tracked app, register `DeviceActivitySchedule(intervalStart: 0:00, intervalEnd: 23:59, repeats: true)` with all 7 bucket events bundled.
  - Activity name: `dailyTrackActivityPrefix + slug`.
  - Event name: `dailyTrackEventPrefix + slug + ".b\(bucketMinutes)"`.
  - Wrap each `startMonitoring` call in do/catch with `ReblockTelemetry`-pattern logging.
- `MojoDeviceActivity/DeviceActivityMonitorExtension.swift` — extend existing `eventDidReachThreshold` (lines 45–60):
  - If event.name starts with `dailyTrackEventPrefix`, parse slug + bucketMinutes, write to App Group.
  - Storage shape: `[dayKey: [slug: highestBucketMinutesFiredToday]]` at key `screenTime.trackedFirings.v1` (UserDefaults) **and** mirrored to `<appGroup>/trackedFirings.json` (file write triggers the host's `DispatchSource` watcher in `ScreenTimeTracker.swift` lines 212–243).
  - Override `intervalDidStart` for `dailyTrack.*` activity names → clear today's slug dict (midnight reset).
- Re-register on `trackedApps` mutation (selection changes) — call `DeviceActivityCenter.stopMonitoring` for stale activity names first.

### Phase 3 — Host-side data layer

**Files to create:**
- New: `MojoiOS/Core/ScreenTime/TrackedAppsTracker.swift` — `ObservableObject` analogous to `ScreenTimeTracker`:
  - `@Published var apps: [TrackedAppUsage]` sorted by `bucketMinutes` desc.
  - `TrackedAppUsage` struct: `slug`, `token: ApplicationToken`, `bucketMinutes: Int`, `displayName: String?` (best-effort from `screenTimeManager.displayName(for:)` cache).
  - Reads `trackedFirings.json` + slug map; reconciles to current selection (drops orphaned slugs).
  - Watches App Group container via `DispatchSource.makeFileSystemObjectSource` (reuse pattern from `ScreenTimeTracker` lines 212–243).
  - Belt-and-suspenders midnight check: if `lastReadDayKey != currentDayKey`, treat last day as historical and zero current.

### Phase 4 — Host-rendered Top Apps UI

**Files to create/modify:**
- New: `MojoiOS/UI/Dashboard/Components/HostTopAppsCard.swift`:
  - Replicates the JOMO design from `MojoTopAppsReportView.swift` (already coded inside DAR — port it to host with `Color.Mojo` / `Font.Mojo` tokens swapped in).
  - Top 9 explicit `AppRow` instances + 1 `OtherRow` if any tracked app ranks 10+.
  - `AppRow`: `Label(token).labelStyle(.iconOnly)` (36pt circle), `Label(token).labelStyle(.titleOnly)` for name, `~Xm` rounded bucket time, blue progress bar, real `Button` "+ Time well spent?" pill.
  - `OtherRow`: stacked overlapping circular icons (5 visible max) + "+N more" text. Tap → sheet showing all overflow apps.
  - Subtitle caption: "Tracked apps · times approximate".
- `MojoiOS/UI/Dashboard/DashboardView.swift` — replace `appBreakdownSection` lines 323–362:
  - Remove `ScreenTimeReportHostView(context: .mojoUsageApps)` branch.
  - Render `HostTopAppsCard(tracker: trackedAppsTracker)` instead.
  - Keep existing `selectedAppUsage`-based drill-in sheet, but adapt to take `TrackedAppUsage` (or wrap in `AppUsageSnapshot` for compatibility).
- `MojoDeviceActivityReport/MojoTopAppsReportView.swift` — keep file in place during rollout; gated behind feature flag for fallback. Remove in a later release.
- `MojoDeviceActivityReport/MojoDeviceActivityReportExtension.swift` — keep `mojoUsageApps` context registered for the rollback path.

**Time Well Spent journaling:**
- New SwiftData model: `MojoiOS/Models/AppJournalEntry.swift`:
  ```swift
  @Model final class AppJournalEntry {
      @Attribute(.unique) var id: UUID
      var date: Date
      var dayKey: String          // for cheap per-day fetch
      var appSlug: String?        // app-bound; nil for chart-hour-bound
      var hour: Int?              // 0-23 for hour-bound; nil for app-bound
      var noteText: String
      var sentiment: String?      // "wellSpent" | "wasted" | "neutral"
      var createdAt: Date
  }
  ```
  Register in `MojoiOSApp.swift` `modelContainer(for:)` array.
- New: `MojoiOS/UI/Dashboard/Sheets/TimeWellSpentSheet.swift` — text field + 3 sentiment chips + Save button. Persists to SwiftData.
- `HostTopAppsCard.AppRow` queries SwiftData per row (`@Query` with predicate `dayKey == today && appSlug == slug`); when count > 0, swap pill from "+ Time well spent?" to "✓ Tagged".

### Phase 5 — Per-hour app icons on chart (DAR)

**Files to modify:**
- `MojoDeviceActivityReport/MojoUsageChartReportView.swift`:
  - Add helper `topAppForHour(_ hour: Int) -> AppUsageSnapshot?` that returns the most-used app for that hour from `snapshot.appsToday[].hourlyBreakdown[hour]`, filtered to `≥ 1m`.
  - Modify `barColumn(hour:width:)` (lines ~133–145) to overlay a small `Label(token).labelStyle(.iconOnly)` (8×8pt) above the bar when bar height ≥ 20pt and a top app exists.
  - Use `ZStack(alignment: .bottom)` with `.offset(y: -barHeight - 4)` for the icon.
  - No icon when bar < 20pt OR no app ≥ 1m that hour (bar stays naked).

### Phase 6 — Per-hour journaling overlay (host)

**Files to create/modify:**
- New: `MojoiOS/UI/Dashboard/Components/HourJournalingOverlay.swift`:
  - `GeometryReader`-based HStack of 24 transparent `Button`s aligned over the DAR chart's hour columns.
  - Tap → `TimeWellSpentSheet` with `hour` set (and `appSlug = nil`, since the chart aggregates all apps).
  - Overlay sits on top of `ScreenTimeReportHostView(context: .mojoUsageChart)` in `DashboardView.chartSection`.
- `MojoiOS/UI/Dashboard/DashboardView.swift` — wrap `chartSection` body in `ZStack { ScreenTimeReportHostView(...); HourJournalingOverlay(...) }`.
- Render a small "✓" badge on bars that have a journal entry that hour (via `@Query` for entries where `hour == h && dayKey == today`). Achieved by drawing a host-side dot overlay on top of the DAR bar at the matching x-position — the DAR chart itself stays unchanged.

### Phase 7 — Feature flag, verification, rollout

**Files to modify:**
- `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift` — `useHostTopAppsKey = "screenTime.useHostTopApps"`. Default false. UserDefault toggle exposed in a Debug menu.
- `MojoiOS/UI/Dashboard/DashboardView.swift` — gate the new `HostTopAppsCard` and `HourJournalingOverlay` behind the flag; fallback to existing DAR rendering when off.

**Verification (real device required — simulator can't test DAM):**
1. Build on real device, authorize FamilyControls.
2. Pick 5 tracked apps via `TrackedAppsView`. Verify `screenTime.trackedSelection.v1` populated and 5 activities registered.
3. Use one tracked app for ~5 minutes; verify console shows DAM `[MojoActivity] threshold fired: st-track.t-XXX.b1` and `b5`.
4. Open dashboard; verify host-rendered Top Apps row shows that app with `~5m` and progress bar.
5. Tap "+ Time well spent?" → fill sheet → save. Verify pill changes to "✓ Tagged".
6. Use another tracked app the next hour; verify chart shows its icon above that hour's bar (DAR-rendered).
7. Tap an hour on the chart; verify host overlay sheet opens.
8. iOS 26.2 sanity check: confirm bucket events fire reasonably (will be early on ~50% of days; that's the documented bug).
9. Toggle feature flag off; verify fallback to existing DAR Top Apps still works.

**Suggested PR breakdown** (commit-by-commit, not all in one PR):
- PR 1: Phase 1 + Phase 2 — tracked-apps picker, scheduler, DAM handler. No UI surface change. Telemetry only.
- PR 2: Phase 3 + Phase 4 (without journaling) — `TrackedAppsTracker`, `HostTopAppsCard`, "Other" row. Behind flag.
- PR 3: Phase 4 journaling — `AppJournalEntry`, `TimeWellSpentSheet`, "✓ Tagged" pill state.
- PR 4: Phase 5 — chart icons in DAR.
- PR 5: Phase 6 — host overlay journaling on chart.
- PR 6: Flip flag default to true.

## Risks

1. **iOS 26.2 premature-fire bug.** Mitigation: rounded bucket display + "approximate" subtitle.
2. **15-app cap on tracked selection.** Surface in `TrackedAppsView` UI with clear count and warning.
3. **DAM cold-start latency** (30–90s after long idle). Top Apps freshness has a floor of ~1–2 min regardless of bucket size — don't over-promise live updates.
4. **Selection mutation racing event reception.** `TrackedAppsTracker` must drop events for orphaned slugs (no crash, just skip).
5. **Hash collision in slug.** Detect at registration in `TrackedAppsManager`, append disambiguator.
6. **`startMonitoring` silent failures.** Wrap in do/catch + telemetry; surface failures in Debug menu.
7. **Cross-process file watcher reliability.** Reuse `ScreenTimeTracker`'s existing `DispatchSource` pattern — already battle-tested.
8. **"Other" row composition.** Only includes *tracked* apps ranked 10+ — does not include untracked apps. UX caveat: "Tracked apps only" subtitle on the card.

## Future work (out of scope for this plan)

- Auto-discovery of newly-installed apps for tracked selection.
- Aggregating per-day buckets into longer-term history (week/month rollups).
- Argo agent integration: a new `get_tracked_app_usage` tool calling `TrackedAppsTracker`.
- Migration off DAR entirely (depends on whether Apple ever ships official per-app data exfil).

## Critical files (cheat sheet)

| Layer | File | Action |
|---|---|---|
| Tracked picker | `MojoiOS/Core/ScreenTime/ScreenTimeManager.swift` | Add `trackedApps` property |
| Tracked picker | `MojoiOS/UI/Settings/TrackedAppsView.swift` | NEW |
| Onboarding seed | `MojoiOS/UI/Onboarding/Screens/OB14_ChooseAppsView.swift` | Seed `trackedApps` from blocked + categories |
| Profile entry | `MojoiOS/UI/Profile/ProfileView.swift` | Add "Tracked Apps" row |
| Constants | `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift` | Add 5 new keys/prefixes |
| Scheduler | `MojoiOS/Core/ScreenTime/TrackedAppsManager.swift` | NEW (owner of slug map + scheduling) |
| DAM handler | `MojoDeviceActivity/DeviceActivityMonitorExtension.swift` | Extend `eventDidReachThreshold` + `intervalDidStart` |
| Host data | `MojoiOS/Core/ScreenTime/TrackedAppsTracker.swift` | NEW |
| Top Apps UI | `MojoiOS/UI/Dashboard/Components/HostTopAppsCard.swift` | NEW (port from `MojoTopAppsReportView`) |
| Journal model | `MojoiOS/Models/AppJournalEntry.swift` | NEW |
| Time Well Spent sheet | `MojoiOS/UI/Dashboard/Sheets/TimeWellSpentSheet.swift` | NEW |
| Chart icons | `MojoDeviceActivityReport/MojoUsageChartReportView.swift` | Add per-hour `Label(token).iconOnly` overlay |
| Hour overlay | `MojoiOS/UI/Dashboard/Components/HourJournalingOverlay.swift` | NEW |
| Dashboard wiring | `MojoiOS/UI/Dashboard/DashboardView.swift` | Replace `appBreakdownSection`, wrap `chartSection` |
| App container | `MojoiOS/App/MojoiOSApp.swift` | Register `AppJournalEntry.self` |
