# Form fill-out flow — submission 401 + 30s blank load

## Context

The previous plan (auto-provisioning the firm slug, defaulting `enabled: true`, auto-opening the form on `flowId` in the URL) shipped. Share URLs now resolve to `/firm/{slug}/onboarding/{flowId}` and the form auto-opens.

Two new issues surfaced when actually using that URL end-to-end:

1. **Anonymous submission fails with 401 Unauthenticated** on `createLeadFromGuestQuiz`. The form renders, the user fills it, hits submit, and Firebase rejects the call. This is the actual blocker — the form is unsubmittable.
2. **The page is blank for ~30s** before the form appears. Even after submission works, the wait makes the share URL feel broken to recipients.

Goal: make anonymous submission succeed reliably (localhost incognito, prod, anywhere) and cut the perceived load time substantially.

## Diagnosis

### 401 root cause
- `createLeadFromGuestQuiz` is declared with `enforceAppCheck: shouldEnforceAppCheck()` (`functions/src/index.ts:2422`). `shouldEnforceAppCheck()` returns `process.env.NODE_ENV === 'production'` (`functions/src/index.ts:104-107`).
- The deployed function on Firebase Functions runs with `NODE_ENV=production`, so App Check is enforced on the live endpoint.
- The localhost frontend generates a debug App Check token via `self.FIREBASE_APPCHECK_DEBUG_TOKEN = true` (`src/firebase.js:148`). Debug tokens require manual registration in Firebase Console per token, per browser session — incognito sessions generate fresh tokens each time, so even after registering once, every new incognito test fails.
- Net effect: the only intentionally-anonymous endpoint in the project is gated behind a token system that isn't workable for the use case.

### 30s blank load root cause
Sequential network waterfall in `FirmLandingPage.fetchFirmPage` (`src/components/FirmLandingPage.jsx:411-770`):
1. `await fetchPublicFirmPage(firmSlug)` — Firestore + HTTP fallback chain (line 437).
2. `await fetchPublicOrganizationContext(pageData.organizationId)` — `publicFirmProfiles` doc read + HTTP enrichment (line 679).
3. `await fetchCustomFlowData(...)` (line 755) — internally calls `await fetchPublicOrganizationContextHttp(organizationId)` *again* on line 813, even when the `organizationDataOverride` (the result of step 2) already contains the target flow with `enabled !== false`. This is the cold-start tax we don't need to pay.
4. Only after all three resolve does `setFlowRouteResolved(true)` fire → page exits its loading state → auto-open effect fires `setShowPreSignupQuiz(true)` → `<Suspense>` starts downloading the `LazyGuestFormExperience` chunk (`src/components/FirmLandingPage.jsx:18`) → another wait with the same blank `FirmLandingPageLoadingShell` (`min-h-screen bg-white`, no skeleton).

Stacked together: ~3 sequential network waits (one of them a redundant Cloud Function cold start) + a chunk download + zero visual feedback throughout.

## Fix (locked decisions)

### A. Drop App Check enforcement on `createLeadFromGuestQuiz`

In `functions/src/index.ts:2422`, change:

```ts
.runWith({ enforceAppCheck: shouldEnforceAppCheck(), memory: '512MB' })
```

to:

```ts
.runWith({ memory: '512MB' })
```

The function is already designed for unauthenticated callers — there's no `context.auth` check in the body. Abuse vectors are gated by:
- `resolvePublicGuestQuizContext` requires a valid firm slug + flow ID (server-side lookup, can't be forged).
- The function only writes to `guestFormSubmissions`, which is locked to server writes (`firestore.rules:1612`).
- Each submission triggers an advisor email — easy to spot in production telemetry if abused.

Deploy via `firebase deploy --only functions:createLeadFromGuestQuiz`.

### B. Eliminate the redundant cold-start call

In `src/components/FirmLandingPage.jsx`, inside `fetchCustomFlowData` (line 777-845), short-circuit the refresh path when the override already contains the target flow:

```js
// If the org override already has the target flow and it's enabled,
// trust it and skip the HTTP refresh — we already paid for that data.
const overrideFlow = findPublicFlow(orgData);
if (overrideFlow?.enabled !== false) {
  if (applyResolvedFlowData({ organizationId, flowId, targetFlow: overrideFlow, currentPageData })) {
    return;
  }
}

// Only fall through to the HTTP refresh when the override is missing/stale.
let refreshedPublicOrgData = null;
try {
  refreshedPublicOrgData = await fetchPublicOrganizationContextHttp(organizationId);
} catch (refreshError) {
  console.warn('[FirmLandingPage] HTTP refresh did not resolve custom flow:', refreshError?.message || refreshError);
}
```

This cuts one Cloud Function round-trip (often a cold start) on the happy path.

### C. Add a real loading skeleton

Replace `FirmLandingPageLoadingShell` with a styled skeleton that uses the firm's logo/colors when available, falling back to a neutral form-card placeholder when not. Two render paths use it today:
- The pre-resolve gate at `src/components/FirmLandingPage.jsx:1638-1644`.
- The `<Suspense>` fallback for `LazyGuestFormExperience` at line 1848.

The skeleton should:
- Show firm logo + name centered (use `firmPage?.title` and `organization?.branding?.firmLogo` once they resolve; otherwise show a neutral spinner only).
- Render a card-shaped shimmer placeholder where the form will appear.
- Respect the existing teal palette (`#0F2D26`) per `DESIGN.md`.
- Keep `aria-hidden="true"` on decorative shimmer and `min-h-screen bg-white` on the wrapper to avoid layout shift on swap-in.

Implement as a single new component file: `src/components/FirmLandingLoadingSkeleton.jsx`. Replace the two existing `<FirmLandingPageLoadingShell />` call sites and delete the inline shell definition at line 20-22.

### D. Prefetch the GuestFormExperience chunk on flowId URLs

Extend the existing prefetch effect at `src/components/FirmLandingPage.jsx:895-925`. Today it prefetches `./QuizFlow` only when `allowPreSignupQuiz` is true. Add a parallel `requestIdleCallback` that imports `./forms/renderer/GuestFormExperience` whenever `flowId` is present in the URL — so the chunk download overlaps with the network waterfall instead of running after it.

## Files to modify

- `functions/src/index.ts` — drop `enforceAppCheck` from line 2422. Leave `memory: '512MB'`. (Single-line change.)
- `src/components/FirmLandingPage.jsx`
  - Inside `fetchCustomFlowData` (line 777+): add the override-first short-circuit before the HTTP refresh.
  - Around line 895-925: extend the prefetch effect to also prefetch `./forms/renderer/GuestFormExperience` when `flowId` is set.
  - Lines 20-22, 1642, 1848: replace `FirmLandingPageLoadingShell` with the new `FirmLandingLoadingSkeleton` import.
- `src/components/FirmLandingLoadingSkeleton.jsx` *(new)* — the skeleton component. Reads `firmPage`, `organization`, `formName` from props; gracefully degrades when they're null.

## Verification

1. **401 fix:**
   - After redeploying the function, open the share URL in a fresh incognito window.
   - Fill the form, submit, watch the network tab.
   - Expect: 200 response from `createLeadFromGuestQuiz`. The FormResponses tab in `/forms/{formId}/responses` shows the new submission within ~10s.
   - Re-test on the production domain to confirm normal (non-incognito) anonymous users still work — they don't need App Check tokens since enforcement is gone.

2. **Slow load fix:**
   - Hard reload the share URL in incognito with DevTools Network throttling on "Fast 4G."
   - Expect: skeleton renders within ~300ms (logo + form placeholder visible). Form opens within ~3-5s on a warm function, ~5-8s if the public-firm-page Cloud Function is cold. Compare against the ~30s baseline.
   - Confirm in the Network tab: only one call to `getPublicFirmContextHttp` (down from two), and the `GuestFormExperience-*.js` chunk request fires concurrently with the firm page fetch rather than after it.

3. **Regression checks:**
   - Authenticated firm admin previewing the share URL: still sees the firm landing chrome (auto-open is gated on `!user`).
   - Form with `enabled: false` (manually toggled off): URL still loads firm landing, form doesn't auto-open.
   - Existing `OnboardingFlowManager` and `FirstActionStep` share surfaces (`src/components/OnboardingFlowManager.jsx:3595`, `src/pages/Onboarding/FirstActionStep.jsx:89`): still produce working URLs.
