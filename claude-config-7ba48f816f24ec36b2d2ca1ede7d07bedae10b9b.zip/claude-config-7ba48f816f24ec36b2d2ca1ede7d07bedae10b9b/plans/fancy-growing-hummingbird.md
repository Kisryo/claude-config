# Flutterli — UI overhaul: Reddit-compact-warm layout, wholesale dark-mode rip, Magic UI

## Context

The design-lab exploration from earlier this session produced 5 variants for `/home`. Before reviewing them the user shared a reference screenshot (attached in chat) showing an almost-exact match to Variant C's structural idea — horizontal topic chips, compact cards with Reddit-style stacked vote arrows, cream/warm background, three-card right rail (Welcome / Our Values / Trending Topics) — but executed at a higher polish level than the lab mockups reached.

The user is picking that direction as the new target, with three additional mandates:
1. **Wholesale dark-mode removal** — not a toggle-off, delete every `dark:` Tailwind class, the `ThemeProvider`, and `/public/theme-init.js`. 76 files carry `dark:` classes today.
2. **"Less basic components"** — keep shadcn/Radix as the accessibility base, layer [Magic UI](https://magicui.design) on top for motion + expressive primitives. Also retune every existing `components/ui/*` file with warm brand opinion.
3. **Drop emoji reactions in favor of classic up/down vote arrows** — matches the existing `VoteButtons` component, zero schema change.

Scope shift locked: Flutterli stays **broad** (autism + ADHD + speech + developmental disabilities). Sub-groups stay as the data model. The horizontal chips on `/home` literally ARE the user's joined sub-groups re-rendered as color-coded pills. Zero database migration.

## Decisions locked (from interview)

| Decision | Value |
|---|---|
| Hero surface | `/home` |
| Audience | Broad — unchanged from today |
| Chips at top of /home | User's joined sub-groups, color-coded, URL-driven filter |
| "All topics" chip | Cross-sub-group merged feed (= current `/home` behavior) |
| Brand name | **Flutterli** (reference image's "AuraSpace" is template placeholder) |
| Palette anchor | Warm paper (`#FAF8F4`) + coral (`#E89B7A`) + sage (`#7BA894`) + Manrope |
| Default mode | Light only — dark mode removed wholesale |
| Emoji reactions | **Dropped** — classic up/down vote arrows via existing `VoteButtons` |
| Custom font | Manrope via `next/font/google`, wired into `tailwind.config.ts` `fontFamily.sans` |
| Expressive library | **Magic UI** (copy-paste components, pulls in `motion` / framer-motion as new runtime dep) |
| Compose affordance | Inline "What's on your mind?" bar above the feed |
| Welcome card | Dismissible, one-time, localStorage-backed, client island |
| Our Values card | Always visible in right rail, multi-condition copy (see proposals below) |
| Trending Topics | Always visible, bottom of right rail |
| Dead routes | Delete `app/test-ui/` and `app/test-editor/`. Keep `/suspended`. |
| `TOTP_DISABLED` bypass | Stays. Unrelated to this work. |

## Phased delivery — 3 PRs

### PR 1 — Dark-mode wholesale rip + warm Tailwind tokens

Foundation. No visual redesign yet. Ships the app as light-only with a warm palette instead of blue/slate. Every existing page should still render and still function after this PR — just lighter and warmer.

**Steps**
1. **Delete theme system files**
   - `components/theme/theme-provider.tsx` (133 lines)
   - `components/theme/theme-toggle.tsx` (67 lines)
   - `public/theme-init.js` (36 lines)
2. **Strip theme wiring from root layout**
   - `app/layout.tsx` — remove `<ThemeProvider>` wrapper, remove `<Script src="/theme-init.js">` tag
   - Remove any `useTheme()` callers (grep: `grep -rn "useTheme\|ThemeProvider\|ThemeToggle" --include='*.tsx' --include='*.ts'`)
3. **Update `tailwind.config.ts`**
   - Remove `darkMode: "class"`
   - Replace the `brand` scale with warm coral: `brand.50: "#FDF4EC"` → `brand.900: "#7A3F28"` (warm coral-brown progression)
   - Add new token groups: `warm` (paper + ink scales), `sage` (green scale), `hairline` (border scale). Values from `app/__design_lab/tokens.ts:WARM_PALETTE` — promote them now that we know they're the winners.
   - Register Manrope as `fontFamily.sans` (Manrope is already on the `--font-sans` CSS var in tailwind, we just need to actually load it via next/font)
4. **Load Manrope via `next/font/google`** in `app/layout.tsx` and bind to `--font-sans`
5. **Strip `dark:` classes from 76 files** — mechanical sweep, sorted by file count (highest impact first):
   - `components/mod/ModerationItemCard.tsx` (37), `app/(app)/settings/page.tsx` (31), `components/chat/NewGroupChatForm.tsx` (27), `components/admin/ModLogFilters.tsx` (21), `app/(app)/home/page.tsx` (21), `components/forum/CommentThread.tsx` (20), `components/chat/GroupSettingsDialog.tsx` (20), `components/notifications/NotificationsList.tsx` (19), `components/admin/ModLogTable.tsx` (19), `components/mod/UserHistoryTimeline.tsx` (18), …
   - And all UI primitives in `components/ui/` (button, input, textarea, dialog, alert-dialog, dropdown-menu, tabs, tooltip, toast, avatar, label) — they're also part of the 76.
   - For each file: remove the `dark:` variant and keep ONLY the light side. Also flip any light side that was referencing blue/slate toward the new warm tokens where it's cheap to do so in the same edit.
6. **Clean `app/globals.css`** — delete `dark:` classes on `.rich-text a`, `.rich-text code`, `.rich-text blockquote`, `.rich-text hr` (lines 99, 102, 111–114). Remove any lingering blue focus ring color → switch to `theme(colors.brand.500)` (now coral).
7. **Delete dead dev routes** — `rm -rf app/test-ui/ app/test-editor/`
8. **Delete the design lab** — `rm -rf app/__design_lab/ .claude-design/` (the AuraSpace layout is the chosen direction; the 5-variant mockups are superseded)

**Verification**
- `pnpm typecheck` — must pass
- `pnpm exec eslint .` — must pass (warnings OK, no errors)
- `pnpm dev` + visit `/login`, `/signup`, `/home` (logged in), `/g/autism-family`, `/chat`, `/ai`, `/settings` — all render without blue, without dark mode, without the theme toggle. Nothing 500s.
- `grep -rn "dark:" --include='*.tsx' --include='*.ts' --include='*.css'` should return **zero** matches
- `grep -rn "useTheme\|ThemeProvider\|ThemeToggle\|theme-init" --include='*.tsx' --include='*.ts' --include='*.js'` should return **zero** matches

---

### PR 2 — `/home` redesign + `components/ui/*` retune + Magic UI setup

The visual redesign. Establishes the new pattern on `/home` and rebuilds the shared primitives so PR 3 can reuse them.

**Steps**
1. **Install Magic UI runtime**
   - `pnpm add motion` (framer-motion's new package name)
   - Create `components/magicui/` directory
   - Copy in the 4–6 components we'll actually use from magicui.design: `animated-list`, `number-ticker`, `shimmer-button`, `animated-shiny-text`, plus one for the Welcome card illustration (probably `dot-pattern` or `grid-pattern`). Each component is a single `.tsx` file with clsx + motion.
2. **Retune `components/ui/*`** — keep the CVA shape, replace the brand-blue treatments with warm coral + sage + new hairline borders + softer shadows:
   - `button.tsx` — `default` uses coral gradient (`bg-brand-600 hover:bg-brand-700` → `bg-gradient-to-b from-brand-500 to-brand-600 hover:from-brand-600 hover:to-brand-700`), `outline` uses warm hairline, new `soft` variant for secondary CTAs, add `xl` size for hero buttons
   - `input.tsx` / `textarea.tsx` — warm bg, softer ring, larger default height (h-11 instead of h-10)
   - `dialog.tsx` / `alert-dialog.tsx` — blurred backdrop (`backdrop-blur-sm bg-warm-ink/30`), lifted shadow, 16px radius, slide+fade entrance (200ms ease-out)
   - `dropdown-menu.tsx` / `tooltip.tsx` — slide+fade entrance, warm hairline border, bigger padding
   - `tabs.tsx` — underline treatment with coral indicator (for `HomeTabs` in PR2 and sub-group `SortTabs` in PR3)
   - `toast.tsx` — soft shadow, warm palette, slide-in from top-right
3. **Redesign `/home` — `app/(app)/home/page.tsx`**
   - Two-column layout: `[ feed: max-w-2xl ] [ right rail: 300px ]` on `lg+`, single column below
   - **Greeting row** (top): small "Good afternoon" + display name — no welcome card here, that's in the rail
   - **Chip strip**: horizontal scrollable row of color-coded chips. First chip is "All topics" (coral, default active). Then one chip per joined sub-group, each colored per its slot (ADHD Parents = coral, Autism Family = sage, Speech & Language = lavender, IEP & 504 = amber). URL-driven: `/home?sg=<slug>` re-fetches the page with a filtered `fetchHomeFeed`. "All topics" = `?sg` absent. HomeTabs (Feed/Saved) moves below the chip strip.
   - **Compose bar**: "What's on your mind, {name}?" inline input with sub-group picker dropdown + "Share" button. Client component (new: `components/forum/InlineComposer.tsx`) that routes to `/g/<slug>/new` with prefilled state OR opens a modal dialog.
   - **Feed**: retune `PostCard` to match the reference — classic Reddit-style stacked up/down vote arrows on the LEFT (swap `variant="stacked"` layout to be left-aligned instead of under the title), color-coded sub-group chip above title, NO body excerpt (sacrifice the earlier decision; reference shows title-only), comment count + save as a minimal footer row. Keep `initialVote` / `currentUserId` / `VoteButtons` client island — no architecture change.
   - **Right rail** (new file: `components/home/HomeRightRail.tsx`):
     - `WelcomeCard` — dismissible, one-time via `localStorage.setItem("flutterli:home-welcome-dismissed", "1")`. Client island. Coral gradient background + Magic UI dot/grid pattern. Copy below.
     - `ValuesCard` — static server component, multi-condition copy. Copy below.
     - `TrendingTopicsCard` — static for now (hard-coded mock hashtags). A real version would query `posts` with a tag column; out of scope for this PR. Note in a TODO.
4. **Extend `lib/forum/queries.ts:fetchHomeFeed`** to accept an optional `subGroupSlug` filter. Existing behavior (no filter) stays default. Add `fetchJoinedSubGroups(userId)` if not already present — chip strip needs the list.
5. **Delete the existing `/home` welcome card** (lines 97–110 of the current `home/page.tsx`) — replaced by the right rail `WelcomeCard`.

**Content proposals** (change these if the copy doesn't land)

> **Welcome card**
> **Heading**: Welcome to Flutterli
> **Body**: A safe, supportive community for families navigating neurodivergence and developmental disabilities. We show up with curiosity, respect, and lived experience.
> **CTA**: Read community guidelines →

> **Our Values card** (4 bullets, green check icons)
> - Compassionate, honest conversation — assume the best of each other
> - Identity-first or person-first language — use what each member prefers
> - Focus on strengths and support needs, not "function" labels
> - What's shared here stays here — no screenshots, no outside links to members

**Chip color slot assignment**
- ADHD Parents → **coral** (`brand`)
- Autism Family → **sage**
- Speech & Language → **lavender**
- IEP & 504 Plans → **amber**
- Future sub-groups cycle through these 4 slots by `sort_order`

**Verification**
- `pnpm typecheck` + `pnpm exec eslint .` — clean
- `pnpm dev` + visit `/home` logged in:
  - Warm cream background, Manrope type, no blue
  - Chip strip across the top with 4 sub-group chips + "All topics"
  - Click a chip → URL changes to `/home?sg=<slug>` → feed re-fetches with only that sub-group's posts
  - Click "All topics" → URL clears → full merged feed
  - Compose bar visible above the feed
  - Vote arrows on the LEFT of each post card, numeric score between them
  - Right rail shows Welcome / Our Values / Trending Topics in that order
  - Dismiss the Welcome card → refresh → Welcome card does NOT reappear
  - Clear `localStorage` → refresh → Welcome card DOES reappear
- Existing post detail page `/g/<slug>/post/<id>` still works (will get the new polish in PR 3, but must not regress)

---

### PR 3 — Roll the new treatment out to the rest of the app

Apply the pattern established in PR 2 to every remaining surface. No new components, no new libraries — just restyling + chip strips where appropriate.

**Surfaces to restyle**
1. **Sub-group page** (`app/(app)/g/[slug]/page.tsx`) — same compact card pattern, sub-group header with member count + join button, sort tabs (Hot/New/Top) retuned to match HomeTabs
2. **Post detail + comment thread** (`app/(app)/g/[slug]/post/[id]/page.tsx`) — post body reads as a long-form article, vote arrows on the left, comments thread with the warm hairline dividers
3. **Chat** (`app/(app)/chat/*`) — chat list with warm bubbles, message composer retuned, group chat settings dialog updated
4. **AI agent** (`app/(app)/ai/page.tsx`) — streaming chat with warm bubbles, citation chips in coral, crisis-detected messages in a soft-alert treatment
5. **Auth surfaces** (`app/(auth)/login`, `signup`, `reset-password`, `setup-totp`) — centered card layout with the warm palette, Manrope, Magic UI shimmer on the primary CTAs
6. **Settings** (`app/(app)/settings/page.tsx`) — simplified sections (31 `dark:` classes already stripped in PR 1), warm group cards, remove theme toggle section (already deleted in PR 1)
7. **Moderation + admin** (`app/(app)/mod/*`, `app/(app)/admin/*`) — retained functional layout but warm treatment on cards, tables, filter chips
8. **Notifications** (`app/(app)/notifications/page.tsx`) — notification list with the HomeRightRail pattern

**Not in scope for PR 3**
- Real trending-topics query (stays mocked — separate follow-up)
- Email notifications (Phase 2 scope, unchanged)
- Password reset custom UX (Supabase default flow stays)
- Dark mode re-enable (deliberately gone)
- TOTP re-enable (deliberately bypassed, `TOTP_DISABLED` markers stay for later revert)

**Verification**
- Visit every top-level route, screenshot, compare to PR 2 `/home` aesthetic. All should feel like the same product.

---

## Critical files

### Touched in PR 1
- `components/theme/theme-provider.tsx` — **delete**
- `components/theme/theme-toggle.tsx` — **delete**
- `public/theme-init.js` — **delete**
- `app/layout.tsx` — strip theme wiring, add Manrope via `next/font/google`
- `tailwind.config.ts` — drop `darkMode`, rewrite `brand` scale as warm coral, add `warm`/`sage`/`hairline` tokens
- `app/globals.css` — strip `dark:` classes from `.rich-text` rules
- 76 files with `dark:` classes — mechanical sweep (full list from grep)
- `app/test-ui/**`, `app/test-editor/**` — **delete**
- `app/__design_lab/**`, `.claude-design/**` — **delete** (design lab superseded)

### Touched in PR 2
- `app/(app)/home/page.tsx` — full rewrite
- `components/forum/PostCard.tsx` — retune footer (vote arrows on left, color-coded chip, drop body excerpt, minimal footer)
- `components/forum/VoteButtons.tsx` — add left-stacked layout option (existing `variant="stacked"` currently renders horizontally)
- `components/forum/HomeTabs.tsx` — restyle with coral underline
- `components/forum/InlineComposer.tsx` — **new**
- `components/home/HomeRightRail.tsx` — **new**
- `components/home/WelcomeCard.tsx` — **new**, client island for dismiss
- `components/home/ValuesCard.tsx` — **new**, server component
- `components/home/TrendingTopicsCard.tsx` — **new**, server component with mocked content
- `components/home/ChipStrip.tsx` — **new**, server component that reads joined sub-groups and renders color-coded chips
- `lib/forum/queries.ts` — extend `fetchHomeFeed(userId, options?: { subGroupSlug?: string })`; add `fetchJoinedSubGroups(userId)` if absent
- `components/ui/button.tsx`, `input.tsx`, `textarea.tsx`, `dialog.tsx`, `alert-dialog.tsx`, `dropdown-menu.tsx`, `tooltip.tsx`, `tabs.tsx`, `toast.tsx` — warm retune
- `components/magicui/*.tsx` — **new**, copy-paste from magicui.design
- `package.json` — add `motion` dependency

### Existing utilities to reuse (do not rewrite)
- `lib/utils/cn.ts` — existing `cn()` helper using clsx + tailwind-merge
- `hooks/useOptimisticVote.ts` — existing optimistic vote hook; `VoteButtons` stays on top of it
- `lib/forum/queries.ts:fetchUserVotes` — pre-fetch viewer votes (keep this pattern)
- `lib/forum/queries.ts:fetchUserBookmarks` — same pattern for bookmarks
- `lib/auth/session.ts:requireFullAuth` — still used by every authed page (even though it's now identical to `requireUser` per the TOTP_DISABLED bypass)

## Verification — end to end

After all 3 PRs:

1. `pnpm typecheck` — clean
2. `pnpm exec eslint .` — zero errors
3. `pnpm dev`:
   - `/` → warm landing (PR 3 polish)
   - `/login` → warm auth card with Manrope (PR 3 polish), log in → `/home`
   - `/home` → chip strip, compose bar, warm feed cards with classic vote arrows, right rail with dismissible Welcome + Our Values + Trending Topics
   - Click a sub-group chip → feed filters
   - Click "All topics" → feed un-filters
   - Dismiss Welcome card → reload → stays dismissed
   - Click a post → warm post detail (PR 3)
   - Navigate to `/chat`, `/ai`, `/settings`, `/notifications` → all warm, all consistent
4. `grep -rn "dark:"` → 0 matches
5. `grep -rn "ThemeProvider\|useTheme\|theme-init"` → 0 matches
6. No references to `app/test-ui` or `app/test-editor`
7. No references to `app/__design_lab` or `.claude-design`

## Not in scope

- Re-enabling TOTP (`TOTP_DISABLED` markers stay)
- Database schema changes — sub-groups stay the same, no topics table, no welcome-dismissed column
- Real trending-topics query — mocked in PR 2, follow-up task to wire to `posts`
- New features (search, email notifications, user-created sub-groups) — unchanged
- Moderation logic changes — mod pages get visual retune only
- Accessibility regressions — maintain the existing a11y baseline (focus rings become coral, everything else preserved)

## Open question for execution

The 3-PR phasing is long. If you want me to execute **just PR 1 first** and then review before moving to PR 2, say so when I start. Otherwise I'll go PR 1 → PR 2 → PR 3 in sequence and check in between each.
