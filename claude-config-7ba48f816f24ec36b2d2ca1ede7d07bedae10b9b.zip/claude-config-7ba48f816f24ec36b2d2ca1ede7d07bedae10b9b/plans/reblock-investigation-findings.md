# Reblock Regression Investigation - Comprehensive Findings

## Executive Summary
The investigation has identified **critical architectural changes in the wall-clock reblocking system**. The most recent changes (May 5-6, 2026) altered how the system handles DeviceActivity slot exhaustion and fail-closed behavior, creating a potential regression pathway.

## Timeline of Recent Changes

### Commit a7cc7f0 (May 6, 07:59 UTC)
**"fix(ios): unstick perpetual 'couldn't safely start the reblock timer'"**

This commit introduced a **best-effort** wall-clock reblock model:
- Changed `guard scheduleDeviceActivityReblock(grant: grant)` to `_ = scheduleDeviceActivityReblock(grant: grant)`
- This allows grants to proceed even when `startMonitoring()` fails
- Justification: "checkExpiredGrants reconciles on every .active scenePhase"
- Also introduced:
  - 16-minute schedule window (instead of 7-day) to prevent slot exhaustion
  - cleanUpStaleWallClockActivities() to sweep orphaned activities

### Commit 198aa8c (May 6, 08:17 UTC) 
**"fix(ios): keep grantAccess fail-closed when reblock schedule fails"**

This commit **reverted** the best-effort model back to fail-closed:
- Changed back to `guard scheduleDeviceActivityReblock(grant: grant) else { return false }`
- Justification: Without fail-closed, users who never foreground Mojo again could keep access past expiry
- Assumption: The 16-minute window + stale-activity sweep fixes prevent perpetual failures

### Commit 32b06d5 (May 6, 04:33 UTC) — PR #77
**"Fix wall-clock reblock scheduling to prevent activity slot exhaustion"**

This is the **merged version** combining both fixes:
1. Added fail-closed guard with detailed comment (lines 113-120)
2. Added 16-minute schedule window (line 237)
3. Added cleanUpStaleWallClockActivities() method (lines 268-286)
4. Calls cleanup in restorePersistedGrants() (line 375)

## Current Code State (HEAD)

### TimedAccessManager.grantAccess() - Line 102-137
```
- Calls `guard scheduleDeviceActivityReblock(grant: grant) else { return false }`
- Fail-closed: if scheduling fails, grant is denied entirely
- Justification assumes architectural fixes prevent perpetual failures
```

### scheduleDeviceActivityReblock() - Line 207-257
```
- Uses 16-minute end window: grant.expiryDate.addingTimeInterval(16 * 60)
- Returns false if startMonitoring() throws
- Records ReblockTelemetry.record(.scheduleRegistered) or (.scheduleRegisterFailed)
```

### DeviceActivityMonitorExtension.intervalDidStart() - Line 29-40
```
- Checks: if activity.rawValue.hasPrefix(ScreenTimeConstants.reblockWallClockActivityPrefix)
- Calls: reapplyShieldForExpiredGrant(grantID: ...)
```

### reapplyShieldForExpiredGrant() - Line 75-103
```
- Looks up grant by grantID in persistedGrants
- Validates: grant.expiryDate <= Date()
- Re-inserts token into store.shield.applications
- Removes grant from persistence
- Logs: "[MojoActivity] Reblocked via wall-clock DeviceActivity"
```

## Known Issues (From Commit Messages)

### Root Cause of Previous Failure (Fixed in #77)
- Old code: 7-day schedule window (grant.expiryDate + 7 days)
- iOS limitation: ~20 concurrent DeviceActivity monitors per app
- Result: After ~14-20 grants in a rolling week, every new `startMonitoring()` threw
- Effect: BlockerInterventionView showed "couldn't safely start the reblock timer" perpetually

### Architectural Constraint
- `checkExpiredGrants()` only runs on scenePhase .active (MojoiOSApp.swift:307)
- If user closes Mojo before returning to foreground, wall-clock DeviceActivity is the only reblock guarantee
- Without wall-clock registration succeeding, grant proceeds but no system-side expiry callback exists

## Possible Regression Vectors

### 1. Fail-Closed Gate Over-Aggressive
- User hits DeviceActivityCenter.startMonitoring() failure for any reason (not just slot exhaustion)
- Grant is denied entirely, user sees "couldn't safely start the reblock timer"
- Assumption (16-min window + cleanup) may not be enough if:
  - Stale activities from previous builds still exist
  - System limits reset less often than expected
  - Multiple concurrent grant requests hit transient failures

### 2. Wall-Clock Activity Never Fires
- Schedule registered successfully but intervalDidStart never called
- Possible causes:
  - iOS skips callback for 16-minute windows in certain conditions
  - Activity name mismatch between registration and callback check
  - Persistence layer corruption (grant removed but activity still scheduled)

### 3. cleanUpStaleWallClockActivities() Incomplete
- Called in restorePersistedGrants() (line 375)
- Only runs on app launch
- Doesn't handle:
  - Activities created by old 7-day-window code (may have different naming?)
  - Activities from force-quit scenarios
  - Activities from extension-initiated reblocks

### 4. Grant Persistence Mismatch
- reapplyShieldForExpiredGrant() removes grant AFTER re-applying shield
- If app crashes between remove and persist, grant may be duplicated
- If TimedAccessManager and extension load different grant snapshots, re-block might not trigger

### 5. Foreground-Only Fallback Broken
- checkExpiredGrants() in MojoiOSApp.swift:307 is the fallback
- Only runs when app comes to foreground
- If this is broken or skipped, and wall-clock fails silently, shields never reapply

## Data Points Needed to Diagnose

1. **Does `intervalDidStart` get called?**
   - Check logs: "[MojoActivity] intervalDidStart: com.mo.MojoiOS.reblock.wallclock.{grantID}"
   - If missing: wall-clock system never fires

2. **Is `reapplyShieldForExpiredGrant` reached?**
   - Check logs: "[MojoActivity] Reblocked via wall-clock DeviceActivity"
   - If missing: wall-clock activity fires but grant lookup fails

3. **Are shields actually re-applied?**
   - Check: ManagedSettingsStore.shield.applications contains the expired token
   - Check logs: "[ScreenTimeManager] Applied shields" with app name

4. **Is `checkExpiredGrants` fallback working?**
   - Check logs: "[TimedAccessManager] checkExpiredGrants: N expired"
   - Should run when app comes to foreground (scenePhase .active)

5. **Are stale activities being swept?**
   - Check logs: "[TimedAccessManager] Cleaned up N stale wall-clock activities"
   - Should appear on app launch

