# First-class editor support for all 16 form question types

## Context

`/forms/:formId/edit` → `AddQuestionZone` already advertises 15 question types (plus `long_text` from the in-card picker = 16 total). Clicking any of them successfully **creates** a question of the correct type — `formManagementService.addQuestion` (L222) looks the type up in `QUESTION_TYPE_DEFAULTS` (L152-185) which has entries for all 16.

Respondents **see** the correct UI — `FormQuestionRenderer.jsx` (L21-98) dispatches to the right per-type input (`PhoneInput`, `DateInput`, `YesNoInput`, `FullNameInput`, `AddressInput`, `InfoCard`, `LinkCard`, etc.).

But **in the editor**, everything that isn't `short_text`/`long_text`/`multiple_choice`/`checkbox`/`dropdown`/`rating`/`file_upload` renders as a plain "Short answer" underline — so the user's complaint *"half of these don't actually exist as question types and instead they just create short answer questions"* is accurate from their vantage point. The data is right; the editor UX is lying.

Two editor pieces need to catch up:

1. **`QuestionCard.PreviewArea` (L50-75)** — only knows about 3 branches (`hasOptions` / `rating` / `file_upload`). Everything else → "Short/Long answer". So Phone, Email, Date, Number, FullName, Address, YesNo, Signature, InfoCard, LinkCard all look identical in the editor.
2. **`QuestionTypePicker` (L13-21)** — the type-change menu inside each card only lists 7 types, so users can't switch *to* Phone / Email / Date / etc. from an existing card even though those types exist.
3. **Type-specific metadata** — Rating stores `scale`, InfoCard/LinkCard store `body`, LinkCard stores `url`. None of these are editable today — the defaults from the service are the only values the user can ever get.

## Strategy

Fidelity first (cheap, high-impact), metadata editors second (needed for Rating/InfoCard/LinkCard to be usable at all).

**Fidelity trick**: reuse the existing respondent input components (`src/components/forms/renderer/inputs/*.jsx`) directly in the editor preview, passed `disabled={true}` + a no-op `onChange`. Every input already supports `disabled` styling (`TextInput.jsx:2` — `disabled:bg-[#f8fafc] disabled:text-[#94a3b8]`; `YesNoInput.jsx:18`, `RatingInput.jsx:18`, etc.). This guarantees the editor preview is pixel-identical to what respondents see, with zero drift risk — any future change to respondent rendering flows to the editor automatically.

Keep the interactive option editor (`DraggableOptionList`) for `multiple_choice` / `checkbox` / `dropdown` — those types need inline option editing, which is a different affordance than a read-only preview.

## File-level changes

### New

- **`src/components/forms/editor/questionTypes.js`** — canonical registry shared by `AddQuestionZone`, `QuestionTypePicker`, and `QuestionCard.handleTypeChange`. Single source of truth for:
  - the 16 type keys with labels, icons, and a `group` (`'basic' | 'choice' | 'personal' | 'display'`) for picker section headers
  - per-type capability flags: `isDisplayOnly`, `hasOptions`, `hasScale`, `hasUrl`, `hasBody`
  - `getDefaults(type)` → returns the field defaults when switching *into* that type (mirrors the server-side `QUESTION_TYPE_DEFAULTS` so switching types in the editor and creating a new question converge on the same shape)

### Edit

- **`src/components/forms/editor/AddQuestionZone.jsx`** — replace the inline `QUESTION_TYPES` array (L19-35) with an import from `questionTypes.js`. No visual change; just the source. Keeps the 4-column grid.

- **`src/components/forms/editor/QuestionTypePicker.jsx`**
  - Replace the inline `TYPES` array (L13-21) with the same import.
  - Render with section headers in the `Menu.Items` (`Basic`, `Choice`, `Personal`, `Display`) so 16 items are scannable. Headers are plain `<div>` children (not `<Menu.Item>`) so keyboard navigation skips them.
  - Keep the glass-menu styling, `anchor={{ to: 'bottom start', gap: 4 }}`, and transparency values as-is.
  - Drop `getQuestionTypeLabel` / `getQuestionTypeIcon` exports — `QuestionCard` is the only consumer and already switched to the picker itself.

- **`src/components/forms/editor/QuestionCard.jsx`**
  - **Rewrite `PreviewArea` (L50-75)** to dispatch by type:
    - `hasOptions` (multiple_choice / checkbox / dropdown) → keep `DraggableOptionList` (interactive option editing)
    - `info_card` / `link_card` → render respondent `InfoCard` / `LinkCard` directly (they already match the Liquid Glass design and read from `question.label` / `question.body` / `question.url`)
    - Everything else → render the matching respondent input with `disabled` + `onChange={() => {}}`. Wrap in a container with `pointer-events-none` to be sure (some inputs have interactive local state like `FullNameInput`/`AddressInput`).
  - **Extend `handleTypeChange` (L105-115)**: currently only injects options for choice types. Extend to merge in `getDefaults(newType)` so switching to `rating` fills in `scale: 5`, to `link_card` fills in `url: ''`, etc. Preserve existing fields (`label` especially) so users don't lose their question text when swapping types.
  - **Hide the `Required` toggle when `isDisplayOnly(type)`** — display-only cards don't collect a response, so the toggle is meaningless (the renderer already ignores `required` for these, per `FormQuestionRenderer.jsx:91`).
  - **Add a type-specific meta editor block** below the preview, above the footer, for types that need it:
    - **Rating** → a small segmented control for `scale` with choices `3 / 5 / 7 / 10`. Styled like the Yes/No buttons (pill, teal when selected) but smaller.
    - **Info Card** → a `body` textarea (3 rows, same input styling as the label field, labeled "Body text").
    - **Link Card** → a `body` textarea + a `url` text input (with `type="url"`, placeholder `https://…`). Show the URL field first (it's the required piece) then body underneath.
  - Each meta editor uses the same blur-commit pattern as `FormTitleCard` — commit on blur, not on every keystroke, so we don't hammer Firestore.

### No changes needed

- **`src/services/formManagementService.js`** — server-side `QUESTION_TYPE_DEFAULTS` (L152-185) already covers all 16. The new `questionTypes.js` registry intentionally mirrors this rather than replacing it; the service is backend-agnostic and shouldn't take a runtime dependency on UI-registry code.
- **`src/components/forms/renderer/*`** — respondent-side already correct.

## Critical files

| File | Change |
|------|--------|
| `src/components/forms/editor/questionTypes.js` | **New** — shared registry (keys, labels, icons, groups, capability flags, defaults) |
| `src/components/forms/editor/AddQuestionZone.jsx` | Import `QUESTION_TYPES` from registry; drop inline list |
| `src/components/forms/editor/QuestionTypePicker.jsx` | Import from registry; render 16 items with section headers |
| `src/components/forms/editor/QuestionCard.jsx` | Rewrite `PreviewArea` to dispatch to respondent inputs (disabled); add meta editors for rating/info_card/link_card; extend `handleTypeChange` defaults; hide Required toggle for display-only types |

## Reused utilities / components

- `src/components/forms/renderer/inputs/*` — all 17 input components reused directly as disabled previews (pure prop-driven, `disabled`-aware)
- `src/components/forms/renderer/inputs/InfoCard.jsx` — reused in editor preview for `info_card` type
- `src/components/forms/renderer/inputs/LinkCard.jsx` — reused for `link_card` type
- `src/components/forms/renderer/validation.js::isDisplayOnlyType` — reused to gate Required toggle visibility
- `src/components/forms/editor/DraggableOptionList.jsx` — kept as-is for option-bearing types
- Heroicons already imported in `AddQuestionZone` (L1-17) — move those imports to `questionTypes.js`

## Out of scope (candidate follow-ups)

- Placeholder text editor for text-like types (`short_text`, `long_text`, `email`, `phone`, `number`) — useful but not blocking the "first-class support" complaint
- `description` / `helperText` editor (shown to respondent via `QuestionShell.helperText`)
- Multi-file-upload options, accepted file types, max size for `file_upload`
- Redesigning the `AddQuestionZone` grid itself

## Verification

1. `npm run dev`, open `/forms/<form-id>/edit` on an existing form.
2. **Picker parity**: open the per-card type dropdown — all 16 types appear, grouped as Basic / Choice / Personal / Display with section headers. Menu scrolls smoothly (prior Reorder.Item `touch-action: none` fix already landed).
3. **Add-and-render fidelity** — for each type (via AddQuestionZone), confirm the editor preview matches respondent:
   - Short Text / Paragraph / Email / Phone / Number / Date → disabled styled input, type-appropriate
   - Full Name → two side-by-side disabled inputs (First / Last)
   - Address → 4-field disabled grid with state dropdown
   - Dropdown / Multiple Choice / Checkbox → inline draggable option list (unchanged)
   - Yes / No → two pill buttons (disabled)
   - Rating → row of numbered buttons matching `scale` (disabled); segmented 3/5/7/10 scale editor visible above footer
   - Information Card → liquid-glass card with label + body (body textarea editor visible)
   - Link Card → liquid-glass card with label + body + Open link button (url + body editors visible)
   - Document Upload → placeholder card
   - E-Signature → placeholder
4. **Type switching**: switch an existing question from Short Text → Rating → Info Card → Multiple Choice. Verify (a) label text is preserved, (b) new type's defaults populate (`scale: 5`, `options: ['Option 1', 'Option 2']`, empty `body`), (c) preview re-renders correctly without a refresh.
5. **Required toggle gating**: switch to Info Card or Link Card — Required toggle is hidden. Switch back to a question type — toggle returns.
6. **Meta editor persistence**: change rating scale to 7, edit info_card body, set link_card URL. Blur each field; refresh the page. Values persist. Open `/forms/:id/preview` — respondent view reflects the changes.
7. **Regression sweep**: existing forms with questions of type `short_text`/`long_text`/`multiple_choice`/`checkbox`/`dropdown`/`rating`/`file_upload` still render identically in the editor (no layout shifts from the PreviewArea rewrite).
8. **Respondent regression**: assigned forms still submit correctly; onboarding, guest modes unchanged (none of the files touched are in the respondent flow).

## Risk and mitigation

- **Risk**: reusing respondent inputs in the editor drags their `useState` / `useEffect` behavior into every render — e.g., `FullNameInput` parses `value` on each mount. Mitigation: pass `value=""` + `disabled` + wrap in `pointer-events-none`; the inputs are pure-render on empty strings. No data fetching, no side effects, verified by reading each input file.
- **Risk**: the inputs were designed at respondent-page widths; `QuestionCard` is narrower (inside `max-w-3xl` minus padding). Mitigation: manual visual check during implementation; most inputs are already width-fluid (`w-full` or `flex`). The `AddressInput` 4-column grid may look cramped — acceptable for preview.
- **Risk**: expanding `QuestionTypePicker` to 16 items in a 192px-wide menu may overflow vertically. Acceptable — Floating UI will auto-flip if needed; no user has a viewport under 600px tall.
- **Risk**: section headers inside a `Menu` break keyboard nav if they become focusable items. Mitigation: render headers as plain `<div>` children, not `<Menu.Item>`.
