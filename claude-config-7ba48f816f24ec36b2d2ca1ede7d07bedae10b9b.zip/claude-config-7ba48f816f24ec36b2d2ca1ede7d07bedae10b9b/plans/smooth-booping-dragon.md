# Dedicated FormRenderer (Sprint 2)

## Context

The form preview at `/forms/:id/preview` and live form submissions (in `FormsWidget`, `AccountFormExperiencePage`, the FirmSettingsPage test overlay) currently delegate to `src/components/QuizFlow.jsx` (~12,700 lines) via the `isFormMode` branch. QuizFlow carries quiz-specific chrome (card flips, flow-between-steps animations, pre-signup lead writes, multi-signer e-signatures, card/scroll mode toggle) that doesn't fit the redesigned form editor visual language.

The user's redesigned editor surfaces (`FormTitleCard`, `QuestionCard`, `AddQuestionZone` in `src/components/forms/editor/`) use a specific design vocabulary from `DESIGN.md` at the worktree root: liquid-glass cards (`rounded-2xl border border-white/60 bg-white/70 backdrop-blur-xl`), neumorphic teal orb badges (`radial-gradient(circle at 30% 25%, #b8d4ce 0%, #3f7267 45%, #0F2D26 100%)`), Space Grotesk Bold titles, and `cubic-bezier(0.2, 0.8, 0.2, 1)` motion curves. The current preview shows QuizFlow's older quiz aesthetic instead.

Goal: replace the 32-line `FormRenderer.jsx` stub with a purpose-built renderer so the entire form surface (preview + live submit) is visually unified with the editor, without touching QuizFlow or existing quiz/onboarding code paths. The stub itself flagged this as Sprint 2 work in its header comment.

## Scope — what swaps, what doesn't

**Swaps to new FormRenderer**: preview route, live client submissions via `AccountFormExperiencePage`, `FormsWidget` modal, `FirmSettingsPage` test-flow overlay.

**Stays on QuizFlow (untouched)**: all quizzes, pre-signup onboarding (`OnboardingFlowManager`, `OnboardingProgressOverlay`, `FirmLandingPage`), guest lead writes, multi-signer e-signature flows (forms with `enableMultiSignature: true` fall back to QuizFlow).

**Firestore contract**: unchanged. `saveFormSubmission()` at `src/services/formSubmissionService.js:36` is called with the same shape — FormRenderer produces identical writes.

## Architecture

Forms are read from `organizations/{orgId}.onboardingFlows[]` (via `src/hooks/useOrgForms.js`). Each form's questions live at `form.settings.customQuestions[]` with `{ id, type, label, required, order, enabled, options?, scale?, body?, url? }`. Legacy forms may use `fieldType` instead of `type` and legacy aliases (`information_card`, `e_signature`, `document_upload`) — a `normalizeType()` helper translates both.

One file per concern, all under `src/components/forms/renderer/`:

### Orchestration
- **`FormRenderer.jsx`** (rewrite — replaces stub) — top-level. Props: `form`, `isPreview`, `onSubmit`, `presentation` (`page` | `modal` | `embed`), `assignmentId`, `clientId`, `organizationId`, `advisorSignatures`. Owns `responses` (keyed by `question.id` internally), `errors`, `submitting`, `submitted`. Normalizes questions (filters `enabled !== false`, sorts by `order`). Renders title card → progress bar → stacked questions → nav buttons, or completion screen when `submitted`. On submit: validates all, maps id→label via `mapResponsesToSubmissionShape`, splits `personalInfo` (full_name/email/phone/address) from `customFields`, then either calls `onSubmit(...)` (preview) or `saveFormSubmission(...)` followed by `onSubmit(...)` (live).
- **`FormQuestionRenderer.jsx`** (new) — pure switch on `normalizeType(question)`. Wraps in a `QuestionShell` (glass-light card with index orb badge, required marker, title). Dispatches to the right input primitive. Also exports `isQuestionAnswered(question, value)` and `validateQuestion(question, value)`.
- **`validation.js`** (new) — pure helpers: `validateEmail`, `validatePhone` (US 10-digit), `validateRequired(value, type)` (type-aware empty checks), `validateQuestion(question, value)`, `normalizeType(question)` (handles `type || fieldType` and legacy aliases), `mapResponsesToSubmissionShape(questions, responses)` (the one place the id→label + personalInfo/customFields split lives).

### Input primitives (one file per type, all under `src/components/forms/renderer/inputs/`)
- `TextInput`, `TextAreaInput`, `NumberInput`, `DateInput`
- `EmailInput`, `PhoneInput` (US mask `(555) 555-5555`, stores raw digits)
- `FullNameInput` (two-field row, emits single `full` string)
- `AddressInput` (street/city/state/zip; state dropdown reuses `US_STATE_NAME_TO_CODE` from `src/components/forms/renderer/conditionalLogic.js:7-59`; emits concatenated string)
- `DropdownInput`, `MultipleChoiceInput`, `CheckboxInput`, `YesNoInput`, `RatingInput`
- `InfoCard`, `LinkCard` (display-only; `isQuestionAnswered` always `true`)
- `FileUploadPlaceholder` (Phase 2 stub — signed-URL service extraction deferred)
- `SignaturePlaceholder` (Phase 2 — wraps existing `src/components/SignaturePad.jsx` for single-signer; multi-signer stays on QuizFlow)

### Shell
- **`FormTitlePreviewCard.jsx`** (new) — read-only twin of the editor's `FormTitleCard`. Hidden when `presentation === 'embed'` with `hideTitle` prop.
- **`FormProgressBar.jsx`** (new) — 4px track `#dde4e5`, fill `#0F2D26`, width transitions 220ms.
- **`FormNavButtons.jsx`** (new) — primary teal CTA using the glossy pattern from `DESIGN.md` verbatim. Sticky-bottom on `page`/`modal`, inline on `embed`.
- **`FormCompletionScreen.jsx`** (new) — glass card with neumorphic orb + check icon. Two variants: preview ("Preview complete — no data was saved") vs live ("Thanks — we've got your responses").

## Decisions (with rationale)

**Scroll mode, not one-at-a-time.** The editor shows all `QuestionCard`s stacked; preview should match. Wizard mode is a future `presentation="wizard"` addition.

**State keyed by `question.id` internally, mapped to `question.label` at submit.** Mirrors QuizFlow's existing translation at lines 6200–6242 so Firestore writes stay shape-compatible with dashboards (`getAllFirmFormSubmissions`, submissions list in `FirmSettingsPage`).

**Validation is submit-only, except email/phone format on blur.** Keeps the page quiet while users fill. Inline errors in `#b91c1c` with subtle `bg-[#fef2f2]` tint. Scroll-to-first-error on submit.

**File upload & signature deferred to Phase 2.** QuizFlow's upload path (lines 8258+) depends on a deployed signed-URL service with guest/client branching that has no clean seam. Ship placeholders. For forms with `enableMultiSignature: true`, `AccountFormExperiencePage` detects and falls back to QuizFlow — safer than silently degrading.

**One file per input primitive.** Each stays ≤100 lines, trivially testable, and a fix to `PhoneInput` doesn't collide with `RatingInput` work. Avoids the QuizFlow-2.0 outcome.

## Files to change

| Path | Change |
| --- | --- |
| `src/components/forms/renderer/FormRenderer.jsx` | rewrite (drops QuizFlow import) |
| `src/components/forms/renderer/FormQuestionRenderer.jsx` | new |
| `src/components/forms/renderer/validation.js` | new |
| `src/components/forms/renderer/FormTitlePreviewCard.jsx` | new |
| `src/components/forms/renderer/FormProgressBar.jsx` | new |
| `src/components/forms/renderer/FormNavButtons.jsx` | new |
| `src/components/forms/renderer/FormCompletionScreen.jsx` | new |
| `src/components/forms/renderer/inputs/*.jsx` | 17 new input/display files |
| `src/components/AccountFormExperiencePage.jsx` (line 78 import, line 448 JSX) | swap QuizFlow → FormRenderer; add multi-signature fallback detection |
| `src/components/widgets/FormsWidget.jsx` (line 34 import, line 2329 JSX) | swap QuizFlow → FormRenderer |
| `src/components/FirmSettingsPage.jsx` (line 78 import, line 27470 JSX) | swap QuizFlow → FormRenderer |
| `src/pages/FormEditor/FormPreviewPage.jsx` | no change — already uses `<FormRenderer>`; becomes the canonical visual once the underlying component is rewritten |

**Explicitly NOT touched**: `QuizFlow.jsx`, `formSubmissionService.js`, editor components, `OnboardingFlowManager.jsx`, `OnboardingProgressOverlay.jsx`, `FirmLandingPage.jsx`, `conditionalLogic.js` (read only).

## Reuse (don't reinvent)

- `src/components/forms/editor/QuestionCard.jsx:34-48` — `RatingPreview` visual is the template for the interactive `RatingInput`.
- `src/components/forms/editor/QuestionCard.jsx:108-132` — the question card shell (orb badge, type label row, title) is the template for `QuestionShell`.
- `src/components/forms/editor/QuestionTypePicker.jsx` — styling template for `DropdownInput`.
- `src/components/forms/renderer/conditionalLogic.js` — `US_STATE_NAME_TO_CODE` for `AddressInput`; `evaluateConditions` for visibility filtering.
- `src/components/SignaturePad.jsx` — wrap for single-signer signatures.
- `DESIGN.md` at worktree root — copy class strings and inline-style recipes verbatim; do not invent hexes/gradients/easing.

## Implementation order

1. `validation.js` + `normalizeType` (everything depends on these).
2. Shell: `FormTitlePreviewCard`, `FormProgressBar`, `FormNavButtons`, `FormCompletionScreen`.
3. `FormRenderer.jsx` rewrite against empty `FormQuestionRenderer` stub — verify preview layout with no questions.
4. `FormQuestionRenderer.jsx` + `TextInput`, `TextAreaInput` — proves shell→input handoff.
5. Options: `DropdownInput`, `MultipleChoiceInput`, `CheckboxInput`, `YesNoInput`.
6. Format: `EmailInput`, `PhoneInput`, `NumberInput`, `DateInput`.
7. Compound: `FullNameInput`, `AddressInput`.
8. Specialty: `RatingInput`.
9. Display-only: `InfoCard`, `LinkCard`.
10. Phase 2 stubs: `FileUploadPlaceholder`, `SignaturePlaceholder`.
11. Call-site migration, safest first: `FormPreviewPage` (verify) → `FirmSettingsPage` test overlay → `FormsWidget` → `AccountFormExperiencePage` (biggest blast radius — last).

## Verification

1. **Preview per type** — build a form with one of each of the 15 question types in the editor. Open preview. Each renders; progress bar increments; no console errors.
2. **Required validation** — mark all required, try submit empty, every one blocks with inline red error. Fill invalid email/phone → blur triggers error.
3. **Preview submit** — with `isPreview`, submit a full form → completion screen, no `addDoc` network call, "preview complete" copy.
4. **Live submit via `AccountFormExperiencePage`** — assign a form to a test client, complete it, verify new doc at `users/{clientId}/formSubmissions/{newId}`:
   - `responses` keyed by label (not id)
   - `metadata.personalInfo` contains full_name/email/phone/address when those types are present
   - `metadata.customFields` contains everything else
   - `flowId`, `flowName`, `organizationId`, `assignmentId`, `submittedAt` present
   - `questionLabels` map written (per `formSubmissionService.js:71-78`) if `flowConfig` was passed — pass `flowConfig: form` from FormRenderer so this stays populated
5. **Dashboard compat** — open the Forms tab in `FirmSettingsPage`, the new submission must appear in the submissions list (hits `getAllFirmFormSubmissions`).
6. **`FormsWidget` modal** — client dashboard → open widget → complete assigned form → widget closes, submission appears server-side.
7. **Multi-signature fallback** — assign a form with `enableMultiSignature: true`. `AccountFormExperiencePage` must route to QuizFlow, not FormRenderer. Verify in console / DOM.
8. **Visual parity** — side-by-side screenshots of editor preview vs live preview: glass title card, neumorphic orbs, question cards, CTA all pixel-match.

## Risks

- **Firestore contract drift** — `mapResponsesToSubmissionShape` is the single source of truth for id→label + personalInfo split. Test against three flows (profile-only, custom-only, mixed) before enabling live writes. QuizFlow's reference is `QuizFlow.jsx:6200-6242` and `7032+`.
- **File upload complexity** — external signed-URL service + guest/client branching. Ship placeholder; don't block Sprint 2.
- **Multi-signature** — explicit fallback to QuizFlow on the `AccountFormExperiencePage` swap; don't silently degrade.
- **Legacy `fieldType` vs `type`** — `normalizeType()` must handle both, plus aliases (`information_card` → `info_card`, `e_signature` → `signature`, `document_upload` → `file_upload`), or older forms render as "unknown type".
- **Preview banner duplication** — `FormPreviewPage.jsx:52-75` already renders the preview banner around the renderer. Do NOT render a banner inside `FormRenderer` itself.
- **Validation edge cases** — Phase 2 covers required, email format, US phone 10-digit. Everything else accepts any non-empty value. Document this limit.

## Non-goals

- No QuizFlow changes.
- No schema migration or Firestore contract change.
- No new question types beyond the 15 in `AddQuestionZone.jsx`.
- No wizard / one-at-a-time mode.
- No international phone / address handling.
- No file upload (placeholder only).
- No multi-signer e-signature (QuizFlow fallback).
- No conditional routing ("go to question X") — only visibility filtering via `conditionalLogic.js`.
