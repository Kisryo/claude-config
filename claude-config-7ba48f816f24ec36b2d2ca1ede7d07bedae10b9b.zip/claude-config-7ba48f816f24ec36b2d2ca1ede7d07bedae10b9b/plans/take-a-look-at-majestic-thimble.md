# FinDash Forms & Onboarding — Revised Spec (post-interview)

> Baseline: Sircia's spec (April 27, 2026), Three Starter Packs.
> This document closes all open questions and addresses gaps that surfaced during the interview. Where original-spec acceptance criteria still apply, they're preserved by reference; where decisions were made, the chosen path is bolded and the alternatives noted.
> All new advisor-side surfaces follow `DESIGN.md` (teal `#0F2D26`, liquid-glass surfaces §4.2, glass modals §4.7, neumorphic orb §4.1, Space Grotesk titles §2, motion brackets §3, multi-layer shadow stack §4.5).

---

## Context

The original spec defines three Starter Packs but is silent on (a) how a new advisor first encounters them, (b) what objects exist in the account at signup, (c) several behavioral edge cases marked as open questions, and (d) which surfaces get the new design system. Without those decisions the packs ship as features without a flow.

The interview produced 28 decisions across onboarding architecture, defaults seeding, friction tradeoffs, edge-case handling, and design scope. They are encoded below.

---

## 0. Cross-cutting decisions (apply to all packs)

### 0.1 Account-creation seeding (new advisors)
Every new advisor org gets the following seeded at sign-up, in a single idempotent function `seedDefaultsForNewOrg(orgId)`:

| Object | Default | Editable |
| --- | --- | --- |
| Default Pipeline | **5 stages: Open → Contacted → Meeting Booked → Proposal → Won/Lost** (single pipeline; client lifecycle pipeline deferred) | Yes |
| Default Prospect Intake Form | Per Pack 1 P0 spec, badged `Starter form` | Yes; badge persists, "Restore default" button reverts content |
| Default Client Intake Form | Per Pack 3 P0 spec, **includes Plaid Account Linking card** (override: ship even before Plaid stability gate, with graceful fallback if Plaid errors) | Yes; badge persists |
| Firm Landing Page | Per Pack 2 P0 defaults, connected form = Default Prospect Intake | Yes |
| Workflow Templates | Pack 1 P1 (Templates A/B/C) + Pack 3 P1 (Templates A/B/C) — **pre-loaded but inactive** until advisor activates | Yes |

### 0.2 Existing advisors
Existing accounts see the onboarding wizard (§1) but **seeding is non-destructive** — `seedDefaultsForNewOrg` checks for an `orgDefaultsSeededAt` flag and skips any object whose role already exists (e.g., if the org has a non-empty pipeline list, no new pipeline is added). The wizard's branching question still appears the first time an existing advisor logs in post-deploy.

### 0.3 OAuth email connection
**Hard gate.** Step 1 of the onboarding wizard requires the advisor to connect Gmail or Outlook before any other step. No skip. Welcome emails, invite emails, and notification emails all originate from this account (existing OAuth pipeline). Removes every "advisor hasn't connected an email" edge case across all three packs.

### 0.4 Lead/bounce notification surface
Single notification component used by Pack 1 P1 (lead notification) and Pack 3 (bounce surfacing):

- **In-app primary**: bell icon in top nav with unread badge; clicking opens a glass dropdown (DESIGN.md §4.7 panel-styled). New form submission = toast on dashboard + bell badge increment.
- **Email digest secondary**: daily 7am digest of new submissions and bounce events, sent to the advisor's connected email. Per-form toggle in form settings to disable digest inclusion.
- Bounce surfacing: contact record gets a red "Invite bounced — update email" badge; the contact's "Send invite" button becomes "Update email + resend"; bell notification fires once per bounce.

### 0.5 Design system scope
**Every advisor-side surface this spec touches gets DESIGN.md treatment** (user explicit). Concretely:

- Onboarding wizard — full-page glass panels (§4.7), Space Grotesk titles, teal `Continue` button (§4.3), sliding highlight progress indicator (§4.4)
- Embed code share modal — glass modal (§4.7), copy buttons with native title tooltips (§4.6.1)
- Add Client split-button + dropdown — pill-shape outer, glass dropdown
- Bulk import mapping review screen — glass panel for the mapping table; sliding highlight on confirm/edit toggle
- Post-import summary screen — glass panel with FormCard-style row per outcome bucket
- Pre-invite checklist popover — glass tooltip (§4.6) above the Send Invite button
- Client first-login welcome banner — full-width liquid-glass strip (§4.2) at top of client dashboard, dismissible
- Notification dropdown — glass panel anchored to bell icon
- Forms list seeded-form badge — pill chip with §4.5 inset highlight at α=0.08

All shadow rgbs tinted to the dominant element color per §4.5; dark-mode substitutions per §7.

---

## 1. Onboarding wizard (foundational — gates Pack 1/2/3)

**Shape: branching wizard up front.** First post-signup screen presents:

```
Welcome to FinDash
What brings you here?

  ◉ I have a website        → Pack 1 (embed)
  ○ I need a landing page    → Pack 2 (landing)
  ○ I'm migrating clients    → Pack 3 (import)
  ○ All of the above

[Continue]   [Skip — explore on my own]
```

Wizard steps in order:

1. **Connect email** (hard gate — see §0.3). Two buttons: Connect Gmail / Connect Outlook. Cannot proceed until OAuth completes. UI: glass panel, neumorphic-orb icon (§4.1) for the success state.
2. **Branching pick** (above). Routes the wizard's "first action" step (#5).
3. **Brand basics** (skippable). Three fields: firm logo upload, theme color (DESIGN.md presets), firm name. Powers the Firm Landing Page defaults and the invite email signature. Live preview tile (per existing landing-page builder). Targets Pack 2 P0 "under 2 minutes" acceptance criterion.
4. **Pick default dashboard template** (skippable). Three radio cards: Standard / Retirement-focused / Simple. Sets the global default for new clients (Pack 3 P0 #4). Override lives on the Add Client flow — see §4.1.
5. **First action card** (matches branching pick):
   - Pack 1 → "Get your embed code" → opens the Embed Code Share Modal (§2.1) for the Default Prospect Intake Form.
   - Pack 2 → "Share your landing page" → opens the Firm Landing Page with copy-URL CTA.
   - Pack 3 → "Import your clients" → opens the Bulk Import flow with the new mapping review step (§4.2).
   - All of the above → first action defaults to "Get your embed code"; the other two appear in the persistent setup checklist.

**Skip behavior**: clicking Skip (or closing the wizard) **still seeds all defaults**. The wizard's checklist persists as a collapsible glass panel on the dashboard with the unfinished steps. "Skip" really means "don't walk me through it now."

**Existing-advisor first login**: same wizard, but Step 1 (Connect email) auto-passes if the advisor already has an OAuth connection; brand basics auto-fill from existing firm settings; defaults seeding is non-destructive (§0.2).

---

## 2. Pack 1 — Embed in External Website

### 2.1 Default Prospect Intake Form (P0)
Per original spec questions and config. **Naming**: form name is `Prospect Intake` with a `Starter form` pill badge (DESIGN.md badge style — see §0.5). Form is fully editable; the badge stays as an origin marker; "Restore default" button reverts content (Decision 26).

### 2.2 Embed Code Share Modal (P0 — replaces "Embed Instructions in Onboarding")
Single component reused by:
- Wizard step 5 (Pack 1 first action)
- Per-form share/embed section (existing surface, restyled)
- Persistent setup checklist tile

Modal contents:
- Two glass tabs: **Link** / **Iframe code** (sliding highlight per §4.4)
- Each tab shows a one-line code block + copy button with native `title` tooltip (§4.6.1)
- Brief explainer: "Paste this on your website and prospects can submit their info directly to your FinDash account."
- Embed code includes a `postMessage` height-resize snippet so the host iframe auto-resizes (see §2.5).
- "Preview on a mock page" button (lazy P2, hidden behind feature flag for now).

### 2.3 Default Workflow Templates (P1) — preloaded inactive
Per original spec Templates A/B/C. Pre-loaded with `active: false`; advisor activates from workflow templates list. No automatic execution at seeding time.

### 2.4 Lead notification (P1)
See §0.4 cross-cutting notification surface. Verifies "Advisor Alert on Answer" fires for guest submissions (open question from spec — implementation must touch the guest-submission write path to enqueue both per-question alerts and the new global "new lead" notification).

### 2.5 Iframe responsive embed (new — closes mobile gap)
- Embed snippet ships with `width: 100%; border: 0; height: 800px` plus a small inline script that listens for `postMessage` from the form origin.
- Form host page emits `{ type: 'findash:resize', height: <px> }` on every layout-affecting state change (card change, validation error appear/disappear).
- Host iframe sets its `height` to the received value. No internal scrollbars on small screens.
- Form itself is fluid down to 320px width; field widths use `min(100%, Npx)`.

### 2.6 Edge case resolution
- **Duplicate email on guest submission**: existing dedup behavior (handled).
- **Guest converts to account when contact already exists**: `shareNewClientWithFirm` looks up contact by email; if found, sets `hasFinDashAccount: true`, `linkedUserId`, merges form data into the new account profile. Decision 11.
- **No connected email**: cannot occur — OAuth is a hard gate (§0.3).

---

## 3. Pack 2 — FinDash Landing Page

### 3.1 Default firm landing page (P0)
Per original spec defaults. Brand basics from wizard step 3 substitute into title/logo/theme color. If brand basics were skipped, fall back to: title `Your Financial Dashboard`, subtitle `From clutter to clarity.`, theme color = teal preset, logo = FinDash mark.

### 3.2 Form-specific landing pages
**Inherit firm design = ON by default** (Decision 13). New form-specific pages auto-mirror the firm-wide page; advisor un-checks to customize from blank.

### 3.3 Campaign tag (P1, new)
Form settings get an optional **Campaign tag** text field (Decision 14). Defaults to form name. System tag on guest submission uses campaign tag if set, else form name. Visible on contact records and pipeline cards as a chip — DESIGN.md pill style.

### 3.4 Landing page analytics (P1, narrowed)
Two server-side counters (Decision 24):
- `pageViews` — incremented on landing-page render (Cloud Function increment)
- `completions` — already tracked via `guestFormSubmissions`

Surfaced on the form-detail page as `X views → Y completions = Z%`. Form-start events deferred to v2.

### 3.5 Per-form workflow differentiation (P1, mostly documentation)
Existing capability. Surface in the form settings UI: a "Workflows" section that lists which workflow this form triggers, with a swap dropdown. Combined with §3.3 campaign tag, advisors can see in the contact record AND pipeline which page a lead came from.

### 3.6 Edge case resolution
- **Form abandonment**: localStorage-only resume (Decision 21). Stash answers keyed by form ID + browser. No backend partial doc; no pre-pipeline contact created. Surfaces via a "Resume where you left off" banner on the form load if local state exists.
- **Sign In click on landing page**: existing routing — verify it goes to `/signin`, not the form. Add a UI test.
- **Multiple forms / different landing pages, same firm**: each form's pipeline/workflow/tag config already isolated. Add an integration test asserting independence.
- **Form deletion with connected landing page**: landing page falls back to "Default Prospect Intake" (auto-relink); soft warning toast to advisor.

---

## 4. Pack 3 — Direct Client Onboarding

### 4.1 Add Client UX (P0 — replaces "Start Fresh or Import?" modal)
**Inline split button** (Decision 6) — replaces the spec's persistent modal:

```
[ + Add Client ▾ ]
   ├ Start from scratch        — opens client creation form
   └ Upload existing info       — opens AI extraction / document upload
```

DESIGN.md treatment: pill outer with the glass modal styling §4.7 on the dropdown; both options keyboard-navigable.

Add Client form includes a **Dashboard template chip** (Decision 10): defaults to the global default chosen in onboarding step 4; advisor changes per-client in one click.

### 4.2 Bulk Import — fix + mapping review (P0, expanded)
Three deliverables in one workstream:

1. **Root-cause fix for the bulk import failure**. Likely cause: `f_name` / `l_name` headers route to `customFields` instead of standard `firstName` / `lastName`. Fix: case-insensitive fuzzy header matcher with explicit aliases for `f_name`, `fname`, `firstname`, `first_name`, `first name` → `firstName` (and equivalents for `lastName`, `email`, `phone`, `dob`).
2. **Mapping review screen** (Decision 8) — new surface following DESIGN.md:
   - After CSV upload, show a glass-panel table: CSV header → FinDash field. Auto-mapped via fuzzy matcher; advisor confirms or edits each row from a dropdown of standard fields + "Custom field".
   - Sliding highlight on `[Confirm + Import]` / `[Edit]` toggle.
   - Includes a "Download example CSV" button (closes spec open question).
3. **Post-import summary screen**:
   - X imported, X failed (with row-level reasons), X duplicates detected.
   - Each row clickable → contact detail.
   - Primary CTA: **"Convert these contacts to client accounts and send invites"** (Decision 27) — routes to bulk convert (now P1, see §4.4).

### 4.3 Default Client Intake Form (P0)
Per original spec questions. **Includes Plaid Account Linking card** (Decision 16, override). Plaid card has a graceful-fallback skip button so a Plaid outage doesn't block the form.

### 4.4 Bulk contact-to-account conversion (was P2 — promoted to P1) (Decision 18)
- Contacts page gets row-level checkboxes + a "Convert + invite" bulk action.
- Action: for each selected contact, run `convertContactToAccount`; if a Firebase Auth user already exists for the email, **find the existing UID and link** (no duplicate, no failure — Decision 15). Then queue invite emails respecting per-org rate limits.
- Pre-action: pre-invite checklist popover (Decision 12) — soft prompt only, dismissable.

### 4.5 Default workflow templates (P1)
Per original spec. Pre-loaded inactive (§0.1).

### 4.6 Pre-invite checklist (P1)
Soft prompt only (Decision 12). Glass tooltip popover (§4.6) anchored to the Send Invite button. Contents: dashboard configured? / forms or tasks assigned? / data reviewed? Each row dismissable. Advisor proceeds regardless.

### 4.7 Client first-login welcome banner (P1)
Liquid-glass strip on the client dashboard top (Decision 7):

```
┌─────────────────────────────────────────────────────────┐
│ Welcome — [Advisor Name] set up your dashboard.    [×]  │
│ They'd like you to fill out: [Intake Form →]            │
└─────────────────────────────────────────────────────────┘
```

DESIGN.md §4.2 (light-mode liquid glass; §7 dark-mode substitution). First login only; dismissal stored on user doc; never reappears. CTA shows assigned form/task if one exists.

### 4.8 Expired invite recovery (new — closes spec edge case)
30-day TTL preserved. Expired-link click lands on a friendly page (firm logo, brand color):

```
This invitation has expired.

[ Request a new link ]
```

Click sends a regenerate-invite Cloud Function; advisor's bell fires "Invite re-requested by [client]" notification; new link emails the original address. Decision 19.

### 4.9 Edge case resolution
- **Bounce on invite send**: §0.4 handling.
- **CSV mixed valid/missing emails**: rows with email succeed, rows without fail with clear reason `Missing email` in the summary screen.
- **Two advisors at same firm import same email**: dedup at firm level (existing behavior — verify with integration test).
- **Convert preserves contact record**: `convertContactToAccount` already handled; integration test enforces.

### 4.10 Cuts vs original spec
- **"Send Your Export to Our Team" P2 button** — cut. Email a support address is something advisors can already do; no need for a built-in surface.
- **Import progress indicator** P2 — kept (basic spinner + "X of N rows processed" text; no fancy progress bar).

---

## 5. Closed open questions (mapping to original spec)

| Original open question | Resolution |
| --- | --- |
| Does "Advisor Alert on Answer" fire for Form First guest submissions? | Pack 1 implementation must verify and, if not, extend write path. |
| Encourage Account Creation links to existing contact? | Yes (auto-link by email). §2.6, Decision 11. |
| Notification system beyond per-question alert? | Yes — §0.4 cross-cutting surface. |
| Form-specific page inherit by default? | Yes (Decision 13). §3.2. |
| System tag = form name or campaign? | Optional Campaign tag, defaults to form name (Decision 14). §3.3. |
| Track landing page views? | Yes — `pageViews` counter (Decision 24). §3.4. |
| Bulk import root cause? | Header fuzzy-match + mapping review (Decision 8). §4.2. |
| `convertContactToAccount` with existing auth user? | Find existing UID and link (Decision 15). §4.4. |
| Download Example CSV button? | Yes (§4.2). |
| Dashboard template data model? | Per-client picker with global default (Decision 10) — implies template stored as reference + per-client override on `clientAccounts/{uid}.dashboardConfig`. |
| Resend/regenerate expired invite? | Self-serve "Request new link" flow (Decision 19). §4.8. |

---

## 6. Verification recipe (e2e)

For any worker that ships a UI change, the verification path is:
- `npm run dev` from repo root (Vite dev server).
- Use the `claude-in-chrome` MCP tools (or `agent-browser` skill) to drive the flow.
- Capture before/after screenshots and confirm DESIGN.md compliance (correct shadows, gradients, fonts, motion brackets).

For backend / data-model changes:
- Run `npm run test:rules` for security rule changes.
- Run `node src/utils/dateUtils.test.js`-style ad-hoc tests for utility logic.
- Spin up the Firebase emulator (`firebase emulators:start`) and exercise affected Cloud Functions via `curl` or the firebase CLI.

For seeding logic specifically:
- Create a fresh test org via the Auth emulator.
- Invoke `seedDefaultsForNewOrg(orgId)` directly.
- Assert the seeded objects exist (default pipeline with 5 stages, two seeded forms with Starter badges, firm landing page with brand defaults, inactive workflow templates).
- Re-invoke and assert idempotence (no duplicates).

---

## 7. Work-unit decomposition (for /batch Phase 2)

Sized so each unit is independently mergeable. ~20 units.

| # | Title | Files / scope | Description |
| --- | --- | --- | --- |
| 1 | Default pipeline seeding | `functions/src/seedDefaults/pipeline.ts` (new) | Idempotent function creating the 5-stage default pipeline on org create. |
| 2 | Default Prospect Intake Form template | `functions/src/seedDefaults/forms/prospectIntake.ts` (new); seed function | Per-spec questions, Form First on, auto-create contact on, badge metadata. |
| 3 | Default Client Intake Form template | `functions/src/seedDefaults/forms/clientIntake.ts` (new) | Per-spec questions including Plaid card and document upload. |
| 4 | Workflow template seeding | `functions/src/seedDefaults/workflows/*.ts` (new) | Pack 1 + Pack 3 templates loaded inactive. |
| 5 | Firm landing page defaults | existing landing page builder + `seedDefaults/landingPage.ts` | Pre-fill title, subtitle, hero, trust indicators, CTA, connect to Default Prospect Intake. |
| 6 | `seedDefaultsForNewOrg` orchestrator + idempotence flag | `functions/src/seedDefaults/index.ts` | Wires units 1–5; sets `orgDefaultsSeededAt`; non-destructive checks for existing advisors. |
| 7 | Onboarding wizard shell | `src/pages/Onboarding/*` (new) | Multi-step wizard with branching pick, glass panels per DESIGN.md. |
| 8 | Wizard step: OAuth email gate | inside wizard | Hard gate; reuses existing OAuth flow. |
| 9 | Wizard step: brand basics | inside wizard | Logo / theme color / firm name with live preview tile. |
| 10 | Wizard step: dashboard template default | inside wizard + `users/{uid}.defaultDashboardTemplate` | Stores global default. |
| 11 | Wizard step: first action card + checklist persistence | inside wizard + dashboard | Routes to embed/landing/import; persists wizard state as a dashboard checklist. |
| 12 | Embed Code Share Modal | `src/components/forms/EmbedShareModal.jsx` (new) | Glass modal with Link / Iframe tabs and copy buttons. |
| 13 | Iframe responsive height (postMessage) | form host page + embed snippet | Auto-resize host iframe to content. |
| 14 | Lead notification surface (in-app + digest) | `src/components/NotificationBell.jsx`, Cloud Function for digest | New global notification path; bell, toast, daily email. |
| 15 | Bounce surfacing on contacts | contact detail page + bounce hook | Inline badge + bell notification. |
| 16 | Add Client split button + dropdown | replaces existing add-client trigger | DESIGN.md treatment; routes to scratch / upload paths. |
| 17 | Bulk import field-mapping fix + review screen | `src/pages/Contacts/BulkImport/*` | Fuzzy matcher, mapping review, post-import summary screen. |
| 18 | Bulk contact-to-account conversion | contacts page row checkboxes + bulk action | Calls `convertContactToAccount` with existing-auth-user link. |
| 19 | Pre-invite checklist popover | invite button on contact page | Glass tooltip with checklist; soft. |
| 20 | Client first-login welcome banner | client dashboard top | Liquid-glass strip; dismissal persists on user doc. |
| 21 | Expired invite "request new link" page | Cloud Function + landing route | Self-serve regenerate flow. |
| 22 | Form-specific landing page inherit-default ON | landing page builder | Default-on toggle + preview. |
| 23 | Campaign tag field on form settings | form settings UI + guest submission write path | New optional field; system tag prefers campaign tag. |
| 24 | Landing page analytics counters + display | Cloud Function + form detail page | `pageViews` increment + display. |
| 25 | Form abandonment localStorage resume | form host page | Stash + resume banner. |
| 26 | DESIGN.md upgrade pass on touched surfaces | grep across units 7–25 | Verify each new/changed surface conforms to DESIGN.md (final cleanup unit). |

Dependencies: units 1–6 (seeding) block unit 7 (wizard) at integration time but are independently mergeable. Units 12–13 depend on the same form share component — sequence 12 then 13. Unit 26 runs last.

---

## 8. Worker template (for /batch Phase 2)

```
GOAL: Implement the FinDash Forms & Onboarding starter packs revision (see /Users/johnathanmo/.claude/plans/take-a-look-at-majestic-thimble.md for the full spec).

YOUR UNIT: <#> — <title>
FILES / SCOPE: <list>
DESCRIPTION: <one-line>

CONVENTIONS:
- All new advisor-side surfaces follow /Users/johnathanmo/.superset/worktrees/SAMWEALTH-new/23jmo/batch/forms-and-onboarding/DESIGN.md (teal #0F2D26, liquid-glass surfaces §4.2, glass modals §4.7, Space Grotesk titles, motion brackets §3, multi-layer shadow stack §4.5).
- Seeded defaults use idempotent functions checking `orgDefaultsSeededAt` flag; do not overwrite existing advisor data.
- Welcome / invite / notification emails always come from the advisor's OAuth-connected account (Gmail or Outlook).
- New components use existing patterns from src/components/forms/* (FormIcon, FormCard, FormsPageHero, DeleteFormModal) as references for the design system.
- Form data writes go through existing Cloud Functions (upsertGuestQuizContactFromResponses, shareNewClientWithFirm, convertContactToAccount).
- No backwards-compat shims; if a default conflicts with current code, just change the code (per user's documented "prefer cutting over preserving" preference).

E2E TEST RECIPE:
- For UI work: `npm run dev` from repo root; drive the flow with the claude-in-chrome MCP tools (or agent-browser skill); capture before/after screenshots; confirm DESIGN.md compliance.
- For backend work: Firebase emulator (`firebase emulators:start`); invoke functions directly; assert effects.
- For seeding: create fresh test org → invoke seedDefaultsForNewOrg → assert state → re-invoke → assert idempotence.
- Skip e2e for purely typing / linting changes; rely on `npm run lint` and `npm run build`.

After implementation:
1. Invoke the Skill tool with skill: "simplify".
2. Run `npm run lint` (must pass with zero warnings — repo enforces --max-warnings 0). Run unit tests where present (`npm run test:rules` etc).
3. Execute the e2e recipe above.
4. Commit + push + open PR with a descriptive title prefixed `[FINDASH-XXX]` if a Linear ticket exists, otherwise just descriptive.
5. End your reply with `PR: <url>` (or `PR: none — <reason>`).
```

---

## 9. Decisions log (28)

1. Onboarding shape — Branching wizard up front
2. Backfill — New accounts get defaults; existing see onboarding non-destructively
3. Default pipeline — Single 5-stage (Open → Contacted → Meeting Booked → Proposal → Won/Lost)
4. OAuth — Hard gate as Step 1
5. Two intake forms — Distinct names + badges
6. Add-client UX — Inline split button
7. Client first-login banner — Liquid-glass dashboard strip
8. Bulk import mapping — Auto-map + manual review step
9. Lead notification — In-app primary + daily email digest
10. Dashboard templates — Per-client picker with global default
11. Guest→account merge — Auto-link by email
12. Pre-invite checklist — Soft prompt, dismissable
13. Form-specific landing inherit — ON by default
14. Campaign tag — Add optional per form
15. `convertContactToAccount` with existing auth user — Find + link by UID
16. Plaid in default form — Ship WITH (with graceful fallback)
17. Onboarding skip — Seed everything, persist checklist
18. Bulk contact-to-account — Promoted to P1
19. Expired invite — Self-serve "request new link"
20. DESIGN.md scope — Every touched surface
21. Form abandonment — localStorage-only resume
22. Bounce surfacing — Inline badge + bell notification
23. AI form generation — Held for v2
24. Landing analytics — Views + completions only (no start events)
25. Wizard steps — Email → branching pick → brand basics → dashboard template → first action
26. Seeded forms — Fully editable, badge stays, "Restore default" button
27. Post-import — Summary → "Convert + invite" batch CTA
28. Mobile/embed — Fully responsive, iframe auto-resizes via postMessage
