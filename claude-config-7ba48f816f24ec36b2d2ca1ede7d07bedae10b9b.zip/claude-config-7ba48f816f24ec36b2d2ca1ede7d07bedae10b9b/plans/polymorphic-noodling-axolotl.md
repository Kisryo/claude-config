# Plan: Document-Aware Agent with Memory, Citations, and Cross-Document Analysis

## Context

Local Cowork is a Tauri 2 + Rust desktop AI agent app targeting real-estate CEOs and
asset managers. The React + A2UI frontend migration is in progress (14/26 stories done,
Ralph running). This plan is for the BACKEND: making the agent document-aware with
memory, citations, and cross-document analysis.

**Target demo:** User uploads a lease PDF → asks "what's the rent in Year 3?" → agent
thinks, extracts, creates a lease abstract artifact with citations → user later asks
"what was the rent again? Compare it to the other lease on a per-sqft basis" → agent
retrieves from memory (not re-parsing), cross-references both documents, shows A2UI
comparison table with citations.

**Key decisions from interview:**
- Documents ingested via drag-drop, file picker, AND folder scanning (all three)
- Artifacts are files on disk (PDF, DOCX, markdown) — not structured DB records
- Per-project flat MEMORY.md file (like Claude Cowork) for cross-session persistence
- Citations: page + section + exact quote, rendered as clickable UI (hover=preview, click=open PDF)
- Memory-first retrieval + re-read fallback for deep analysis
- Cross-doc comparison output as A2UI chart/table surface
- Enhanced Python pdfplumber skill with position data (bbox for citations)
- DITCH DOCKER — run Python natively (matches what Claude Cowork does with seatbelt sandboxing)
- Scale: 50-100 documents per project
- System prompt updated so agent knows about memory, artifacts, citations

## Current Backend Architecture

- **Agent loop** (`src-tauri/src/agent/agent_loop.rs`): Turn-based streaming, multi-provider (Anthropic/OpenAI/Gemini), emits events via Tauri
- **Tools** (`src-tauri/src/tools/`): read_file, write_file, edit_file, bash, glob, grep, list_dir, docker_run, docker_list, docker_images
- **Skills** (`src-tauri/src/skills/mod.rs`): PDF, DOCX, XLSX, PPTX — Python scripts run via docker_run
- **Database** (`src-tauri/src/database.rs`): SQLite — tasks, task_messages (role+content+timestamp), task_artifacts (path+kind+mime), projects, scheduled_tasks
- **Artifacts**: Tracked via ArtifactCreated events, stored in task_artifacts table, files on disk
- **Message history**: task_messages table, loaded at task start, passed to agent as conversation context

## Implementation Plan

### Phase 1: Remove Docker, Go Native (US-001, US-012)

**What:** Replace docker_run tool with native bash/python execution. Auto-install Python deps.

**Files to modify:**
- `src-tauri/src/tools/docker.rs` → remove or feature-gate
- `src-tauri/src/agent/tool_executor.rs` → remove docker tool routing, skills run via bash
- `src-tauri/src/skills/mod.rs` → update skill execution to use native python3
- `src-tauri/Cargo.toml` → feature-gate bollard crate
- `src-tauri/src/lib.rs` → remove docker tool registration

**How skills execute after this change:**
1. Agent reads SKILL.md (existing pattern)
2. Agent writes Python script to temp file (existing pattern)
3. Agent calls `bash` tool with `python3 script.py` instead of `docker_run`
4. First execution checks for pip packages, auto-installs if missing
5. Output parsed for artifacts (existing pattern, just remove Docker path mapping)

**New tool: `ensure_python_deps`** — checks and installs required Python packages. Called once per session, cached.

### Phase 2: Project Memory System (US-004, US-007, US-008, US-010)

**What:** Per-project MEMORY.md file that the agent reads at session start and writes to during execution.

**Files to modify:**
- `src-tauri/src/tools/` → new `memory.rs` with read_memory and write_memory tools
- `src-tauri/src/agent/tool_executor.rs` → register memory tools
- `src-tauri/src/agent/agent_loop.rs` → read MEMORY.md at task start, include in system context
- `src-tauri/src/agent/message_builder.rs` → append memory contents to system prompt

**Memory file location:** `{project_folder}/memory/MEMORY.md`

**read_memory tool:** Returns contents of MEMORY.md for the current project. If file doesn't exist, returns empty string.

**write_memory tool:** Takes a section heading and content. Appends to MEMORY.md or updates existing section with matching heading. Creates file + directory if they don't exist.

**Auto-read at task start:** In `run_task_agent`, before passing history to agent loop, read MEMORY.md and prepend to system prompt: "## Project Memory\n{memory_contents}\n"

**Agent writes memory after document analysis:** System prompt instructs agent to call write_memory after extracting document data, recording: document name, file path, key terms, extraction date, artifact paths.

**System prompt additions:**
```
## Memory
You have a project memory file (MEMORY.md) that persists across sessions.
- Use read_memory to check what you already know before analyzing documents
- Use write_memory to record important findings, extracted data, and artifact paths
- When answering questions, check memory first. Say "Based on my previous analysis..." when using cached knowledge
- Include timestamps in memory entries so you can judge staleness
- Memory is human-readable markdown — keep entries concise and scannable
```

### Phase 3: Enhanced PDF Extraction with Citations (US-005)

**What:** Upgrade pdfplumber extraction script to return structured JSON with page numbers, section headings, bounding boxes, and exact quotes.

**Files to modify:**
- `~/.local-cowork/skills/pdf/SKILL.md` → update extraction instructions
- New Python script: `extract_structured.py` — pdfplumber extraction that outputs:
```json
{
  "source_file": "/path/to/lease.pdf",
  "extraction_timestamp": "2026-04-12T16:00:00Z",
  "total_pages": 42,
  "pages": [
    {
      "page_number": 7,
      "text": "full page text...",
      "sections": [
        {
          "heading": "Section 3.2 Base Rent",
          "content": "Base Rent shall be $45.00 per rentable square foot...",
          "bbox": [72, 200, 540, 280],
          "page_number": 7
        }
      ]
    }
  ]
}
```

**Section detection:** Use pdfplumber's font-size analysis — text with larger font size or bold is treated as a section heading. Fall back to line-break-separated paragraphs if no headings detected.

### Phase 4: Citation UI (US-006)

**What:** Agent outputs citations in a parseable format. Frontend renders them as clickable elements.

**Citation format in agent output:**
```
The base rent is $45.00 per square foot [[cite: 123-Main-Lease.pdf | p.7 | Section 3.2 Base Rent | "Base Rent shall be $45.00 per rentable square foot per annum"]]
```

**Frontend parsing:** Regex matches `[[cite: ... ]]` markers in react-markdown output. Replaces with a `<CitationChip>` React component.

**CitationChip behavior:**
- Styled: subtle bg (--accent), small font, inline
- Hover: shadcn Popover shows the quoted text and source location
- Click: `invoke("open_file_at_page", { path, page })` → Tauri opens PDF at page via shell

**New Tauri command: `open_file_at_page`**
- macOS: `open -a Preview "file.pdf"` (Preview doesn't support page params via CLI, but we can use `qlmanage -p` for Quick Look or just open the file)
- Alternative: use the page number in the citation display, let user navigate manually

**Files to modify:**
- `src/components/CitationChip.tsx` (new)
- `src/components/CitationChip.css` (new)
- `src/components/AgentMain.tsx` → parse citations in markdown output
- `src-tauri/src/commands.rs` → new open_file_at_page command

### Phase 5: Document Ingestion UI (US-002, US-003, US-011)

**What:** Drag-drop, file picker, and folder scanning for document upload.

**Drag-drop:**
- React `onDragOver`/`onDrop` handlers on the chat input area
- Dropped files copied to `{project_folder}/documents/` via Tauri fs plugin
- File paths inserted into the chat message input

**File picker:**
- Paperclip icon button in input bar
- Uses Tauri dialog plugin `open({ multiple: true, filters: [...] })`
- Selected files copied to project documents folder
- File chips shown below input

**Folder scanning:**
- Agent uses existing `glob` tool to scan project folder
- System prompt instructs: when user says "analyze all documents", scan for PDF/DOCX/XLSX/CSV/TXT
- Each found document processed sequentially with memory entries

**Files to modify:**
- `src/components/AgentMain.tsx` → drag-drop handlers, file picker button
- `src/components/AgentMain.css` → drop zone styling
- `src-tauri/src/commands.rs` → copy_file_to_project command (if needed, or use existing fs)

### Phase 6: Cross-Document Comparison (US-009)

**What:** Agent reads from memory for multiple documents, generates A2UI comparison surface.

**Depends on:** React migration completing (A2UI generate_chart tool)

**Flow:**
1. User asks "compare rent from lease A vs lease B per sqft"
2. Agent reads MEMORY.md, finds entries for both documents
3. If key terms in memory → uses them directly
4. If not → re-reads source documents, extracts, updates memory
5. Calls `generate_chart` tool with comparison data
6. A2UI table/chart surface renders inline with citations for each data point
7. User can ask "export this as a PDF" → agent creates artifact document

**No new backend code needed** — this is all orchestrated via system prompt instructions + existing tools (read_memory, generate_chart, write_file).

## Story Dependency Graph

```
US-001 (ditch Docker) ──────────────────────────────┐
US-012 (pip auto-install) ──────────────────────────┤
                                                     │
US-004 (memory system) ─────┬── US-007 (write memory)│
                            ├── US-008 (read first)  │
                            └── US-010 (system prompt)│
                                                     │
US-005 (PDF extraction) ──── US-006 (citation UI) ───┤
                                                     │
US-002 (drag-drop) ─────────────────────────────────┤
US-003 (file picker) ───────────────────────────────┤
US-011 (folder scan) ───────────────────────────────┤
                                                     │
                              US-009 (cross-doc A2UI) ┘
                              [requires React migration]
```

## Parallel Execution Strategy

**Lane A (Rust backend — can start NOW):**
US-001 → US-012 → US-004 → US-005 → US-010 → US-007 → US-008

**Lane B (Frontend — after React migration):**
US-002 → US-003 → US-006 → US-011

**Lane C (Integration — after both lanes):**
US-009

## Verification

After each story:
```bash
npx tsc --noEmit                    # TypeScript type check
cd src-tauri && cargo check         # Rust compile check
cd src-tauri && cargo clippy -- -D warnings  # Rust lints
```

End-to-end demo test:
1. Open app, create a project with a folder containing lease PDFs
2. Drag a lease PDF into chat
3. Ask "What's the rent in Year 3?"
4. Verify: agent extracts, creates abstract, citations are clickable
5. Close task, open new task in same project
6. Ask "What was the rent again?"
7. Verify: agent reads from memory, doesn't re-parse PDF
8. Ask "Compare it to [other lease] per sqft"
9. Verify: A2UI comparison table renders with citations from both documents

## Critical Files

| File | Changes |
|------|---------|
| `src-tauri/src/tools/docker.rs` | Remove or feature-gate |
| `src-tauri/src/tools/memory.rs` | NEW — read_memory, write_memory tools |
| `src-tauri/src/agent/tool_executor.rs` | Remove docker, add memory tools |
| `src-tauri/src/agent/agent_loop.rs` | Read MEMORY.md at task start |
| `src-tauri/src/agent/message_builder.rs` | Append memory to system prompt |
| `src-tauri/src/skills/mod.rs` | Update skill execution for native python |
| `src-tauri/Cargo.toml` | Feature-gate bollard |
| `src/components/CitationChip.tsx` | NEW — clickable citation UI |
| `src/components/AgentMain.tsx` | Drag-drop, file picker, citation parsing |
| `src-tauri/src/commands.rs` | open_file_at_page command |
