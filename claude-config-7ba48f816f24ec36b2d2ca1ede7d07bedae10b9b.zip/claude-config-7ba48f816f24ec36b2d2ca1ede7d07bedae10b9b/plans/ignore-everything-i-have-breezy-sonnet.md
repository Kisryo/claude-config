# Landing page — full rebuild (Klarna IA, FinDash words)

## Context

16 commits of teal + liquid-glass iteration on `src/components/LandingPage.jsx` are being abandoned. The user wants a ground-up rebuild using klarna.com's information architecture as the structural reference, with **all existing FinDash copy preserved verbatim** (words stay, design is thrown out). Klarna's visual language (pink, consumer lifestyle photography) is explicitly *not* being copied — only its section rhythm.

## Scope boundary (important — "delete everything" can't be taken literally)

Some files the current landing depends on are **also used by `AdvisorSignupPage` and `AdvisorFirmSignupModal`**, so nuking them would break the advisor signup flow.

| File | Consumers outside landing | Action |
|---|---|---|
| `src/components/LandingPage.jsx` | none (mounted in `App.jsx:40` as direct import) | **Full rewrite** |
| `src/components/LandingPage.module.css` | `AdvisorSignupPage.jsx`, `AdvisorFirmSignupModal.jsx`, `FinancialInstitutionsSlider.jsx` | **Fork: new module file for landing; leave old one alone** |
| `src/components/landingDesignTokens.js` | `AdvisorSignupPage.jsx` | **Leave alone** |
| `src/components/InteractiveDashboardPreview.jsx` | `AdvisorSignupPage.jsx` | **Leave alone** (may or may not render in new landing) |
| `src/components/SecurityPrivacySection.jsx` | landing only | **Delete** (content absorbed inline) |
| `src/components/FinancialInstitutionsSlider.jsx` | landing only | **Delete** (logo-strip rebuilt inline; `/assets/logos/banks/*.png` reused) |

## Target structure (11 sections, Klarna's IA, condensed to fit FinDash's copy)

1. **Top nav** — FinDash wordmark · "For Advisors" · "Sign in"
2. **Split hero** — eyebrow + H1 + subhead + body + dual CTA left; product visual right
3. **4-card "use-case" grid** — On the web / In the household view / With your advisor / On mobile
4. **5-icon benefits row** — condense 3 workspace-proof + 2 research stats into 5 chips
5. **Full-bleed dark SOC 2 / trust banner** — AICPA SOC 2 Type 2 line + Trust center link
6. **Horizontal testimonial carousel** — 3 cards (Colin, Al, Steve) with star rating, quote, avatar, role
7. **Institution logo strip** — 2-row scroller, 16 bank logos, reuse `/assets/logos/banks/*.png`
8. **Planning surfaces grid** — 3 tiles for Cash Flow / Estate / Goals, reuse existing `/media/findash-*.webm|mp4`
9. **Split security block** — 3 pillars + 4-metric trust strip (AES-256, TLS 1.3, 24/7, Read-only)
10. **Full-bleed final CTA** — "One place for the whole picture." + dual CTA
11. **Multi-column footer** — link groups + hello@findash.ai + LinkedIn + © year

## Copy inventory (preserved verbatim)

Source of truth below. All strings, hrefs, and asset paths must appear in the new landing exactly as listed.

### SEO / Helmet
- Title: `FinDash | Financial Dashboard From Clutter to Clarity`
- Meta description: `Track net worth, cash flow, goals, estate planning, and household finances in one clear workspace. Share the full picture with family or a trusted advisor.`
- Keywords: `findash, personal finance dashboard, net worth tracker, cash flow planner, financial planning app, household finance app, family financial dashboard, estate planning`
- Canonical: `https://findash.ai/`
- OG/Twitter: same title + `FinDash brings net worth, cash flow, goals, estate planning, and household coordination into one clear dashboard.`
- JSON-LD blocks: WebSite · Organization · SoftwareApplication (contactPoint `hello@findash.ai`, sameAs `https://twitter.com/findash_ai`, `https://www.linkedin.com/company/105955173/`, logo `https://findash.ai/headerlogo.png`)

### Hero
- Eyebrow: `Personal financial dashboard`
- H1: `Your Financial Dashboard`
- Subhead: `from clutter to clarity`
- Body: `Track net worth, cash flow, goals, estate planning, and household finances in one clear workspace you can share with family or a trusted advisor.`
- CTAs: `Start for Free` / `For Advisors`

### Workspace proof (3 cards → cards 1–3 of the 4-card grid; card 4 = mobile view or shared/advisor view)
1. One balance sheet · `1 view` · `Net worth, liabilities, and institutions in a single operating view.`
2. One decision layer · `5 surfaces` · `Cash flow, taxes, insurance, estate, and goals informing each other.`
3. One household story · `Shared` · `Accounts, goals, documents, and advisors aligned in one place.`

### Planning surfaces (videos)
- Cash Flow — `Cash Flow Intelligence` · `Budgeting optimization, anomaly detection, and smart categorization across connected accounts.` · `/media/findash-cashflow.{webm,mp4}`
- Estate — `Estate Planning AI` · `Entity-aware automation that keeps multi-generational estate plans coordinated.` · `/media/findash-estate.{webm,mp4}`
- Goals — `Goals & Projections` · `Strategic guidance that aligns every goal with cash flow, tax, and risk insights.` · `/media/findash-goals.{webm,mp4}`

### Testimonials (avatar paths preserved)
- Colin Philips, `CFP®`, `/colinphilps.jpeg` — `The ease of use is immediately noticeable. The platform is clean, intuitive, and saves time by putting the planning workflow in one place.`
- Al Faber, `CFP®, ChFC®, CLU®`, `/al.jpg` — `FinDash shows past, present, and future finances together. That context makes planning assumptions easier to validate and conversations more meaningful.`
- Steve Sherman, `Vice President/Principal, Industrial Rivet & Fastener Co., Inc.`, `/steve.jpeg` — `Within 20 minutes I was connected and up and running. It is far more intuitive and makes the full financial picture easier to organize and act on.`

### Section eyebrows + headlines
- `One workspace` — `Planning, without the clutter.` — `One living dashboard for net worth, cash flow, estate, and goals — so every decision has the full picture behind it.`
- `Depth, not just dashboards` — `Every surface, coordinated.` — `Cash flow, estate, and goals stay connected so decisions carry full context.`
- `What people are saying` — `Less friction. Clearer conversations.` — `Households get organized faster, families stay aligned, and advisors enter a cleaner conversation.`
- `Connected data layer` — `FinDash plugs into the institutions you already use.` — `Secure aggregation across 12,000+ financial institutions, so your accounts stay connected in one place.`
- `Security & privacy` — `Independently audited. Quietly boring.` — `Your financial data sits behind the same controls trusted by regulated institutions — continuously monitored and independently verified.`
- `Research-backed` — `When people can see the system, they use it.` — `FinDash is built around visibility and follow-through. The research points in the same direction.`
- `Start with clarity` — `One place for the whole picture.` — `Start free to organize your own finances, or visit the advisor experience if you're evaluating FinDash for a firm.`

### Security pillars (3) + SOC 2 banner + trust strip (4)
SOC 2 banner: `SOC 2 Type 2` · `Independently audited under the AICPA SOC framework for Security controls.` · Trust center → `https://findash.trustshare.com/home`

Pillars:
1. Enterprise-grade security — `Built on Google Cloud with AES-256 at rest, TLS 1.3 in transit, continuous monitoring, and regular third-party penetration tests.`
2. Private by default — `We never see bank passwords. Data is encrypted, stored in the US, and never sold. You control who can see what.`
3. Read-only connections — `Accounts connect via Plaid and custodian APIs in read-only mode. We cannot move money or transact on your behalf.`

Trust strip: `AES-256` Encryption at rest · `TLS 1.3` Encryption in transit · `24/7` Continuous monitoring · `Read-only` Account access

### Research findings (3)
- `44% more likely` · `to save 10%+ of income` · `People with a written financial plan materially improve savings behavior over time.` · [1]
- `Literacy compounds` · `knowledge grows wealth` · `Households with stronger financial literacy tend to accumulate meaningfully more wealth.` · [2]
- `Visibility changes behavior` · `tracking supports follow-through` · `Regular visibility into net worth and cash flow encourages more deliberate financial habits.` · [1]

Citations: [1] `https://www.plansponsor.com/written-financial-plan-improves-savings-asset-allocation/` (Hearts & Wallets — Having a Written Financial Plan Improves Savings and Asset Allocation) · [2] `https://pmc.ncbi.nlm.nih.gov/articles/PMC3554245/` (Behrman et al. — How Financial Literacy Affects Household Wealth Accumulation)

### Institutions (logo strip, 2 rows)
Row 1: Chase · Bank of America · Wells Fargo · Citibank · American Express · Fidelity · TD Bank · Capital One
Row 2: US Bank · PNC · Charles Schwab · Barclays · HSBC · Ally · Discover · Black Diamond
Assets: `/assets/logos/banks/{chase,bofa,wellsfargo,citibank,amex,fidelity,tdbank,capitalone,usbank,pnc,schwab,barclays,hsbc,ally,discover,blackdiamond}.png`

### Final CTA + footer
Final CTAs: `Try FinDash Free` / `For Advisors`
Footer links: For Advisors · Pricing · Our Team · Privacy Policy · Terms of Service · Security (`https://findash.trustshare.com/`) · FAQ · Documentation · Release Notes
Contact: `hello@findash.ai` · LinkedIn: `https://www.linkedin.com/company/105955173/`
Copyright: `© {year} FinDash. All rights reserved.`

## Behavioral code that MUST survive the rewrite

All of these live in `LandingPage.jsx` today and are independent of visual design:

- `hasPendingGoogleSMS2FA()` + `isGoogle2FAPrecheckInProgress()` helpers
- Auto-redirect to `/account/me` when `user` exists and no 2FA is pending
- `openSignInModal` window-event listener that sets `signInMode` and opens the modal
- `?mfa=required` query-param → read `sessionStorage.mfaResolver` → open MFA modal
- `?signup=1` query-param → open signup modal, set `authDestination` = `/account/me`
- `?signin=1` or `?login=1` query-param → open signin modal; if `?reset=1` also present, toast `Password updated. Please sign in with your new password.`
- `handleGetStarted()` → open signin modal for signed-out, else navigate to `/account/me`
- `<SignInModal>` integration with `showSignInModal` + `signInMode` state

## Visual direction

- **Klarna's IA and rhythm** (split hero, 4-card use-case grid, 5-chip benefits row, horizontal logo scroller, dark full-bleed banner, horizontal testimonial carousel, full-bleed final CTA, fat multi-column footer)
- **Not** Klarna's pink/coral/lifestyle-photo aesthetic
- Suggested new palette: clean white/off-white backgrounds, charcoal body text, single FinDash accent (TBD with user — existing brand teal is available, or a fresh color). Bold display typography, generous whitespace, no glassmorphism this time.
- Exact palette + type system decisions will happen during implementation; plan is structural.

## Media & component sourcing (per user direction: "find on internet or generate")

- **UI primitives**: prefer open-license component patterns over hand-rolled. Candidates: shadcn/ui (already likely compatible), Tailwind UI free components (marketing-section patterns), Radix primitives for carousel/tabs. `@heroicons/react/24/outline` is already in the import graph and stays.
- **Illustrations / decorative visuals**: source from open-license libraries — unDraw, Storyset (free tier, attribution as required), Pixeltrue, Humaaans. SVGs preferred so they can be themed to the accent color.
- **Lifestyle / hero photography**: Unsplash or Pexels (free commercial use). Pulled into `public/landing/` as local assets (never hot-linked). Only pull if a lifestyle photo is actually needed — default is a stylized product-mockup card instead.
- **Dashboard mockups for hero + surface grid**: *do NOT* reuse the existing `InteractiveDashboardPreview` or `/media/findash-{cashflow,estate,goals}.{webm,mp4}` videos. Instead:
  - Build net-new mockup cards in pure JSX + Tailwind (static "fake" dashboard UI — numbers, bars, pill charts) so each section-hero visual lives in-repo and themes with the palette.
  - Or, if a screenshot is warranted, generate one by running the app and capturing `/account/me` into `public/landing/dashboard-hero.png`; requires one extra capture step during implementation.
- **Logos**: the existing `/assets/logos/banks/*.png` set stays (16 institutions already on disk, licensed for use).
- **Fonts**: whatever Tailwind default + one display face (Inter + Geist, or Inter + Fraunces, etc.); locked during implementation.
- **Explicit non-goal**: no AI image generation in this session (no image-gen tool available); any "generated" visuals are CSS/SVG mockups built in code.

## Files touched

- **Rewrite**: `src/components/LandingPage.jsx` (full)
- **Add**: `src/components/LandingPageV2.module.css` (new CSS module, landing-only; avoids collision with the shared `LandingPage.module.css`)
- **Delete**: `src/components/SecurityPrivacySection.jsx`
- **Delete**: `src/components/FinancialInstitutionsSlider.jsx`
- **Untouched**: `src/components/LandingPage.module.css`, `landingDesignTokens.js`, `InteractiveDashboardPreview.jsx`, `LazyVideo.jsx`, `SignInModal.jsx`, `App.jsx`

## Verification

1. `npm run dev` — landing renders at `/`, no console errors.
2. Smoke signed-out → sign-in flow: `?signup=1` opens signup modal; `?signin=1&reset=1` opens signin + success toast; `?mfa=required` with seeded `mfaResolver` opens MFA modal.
3. Smoke signed-in → auto-redirect to `/account/me` (and blocked when `sessionStorage.google2FARequired === 'true'`).
4. Visit `/advisor-signup` (`AdvisorSignupPage`) — confirm it still renders (its imports from `landingDesignTokens.js`, `LandingPage.module.css`, and `InteractiveDashboardPreview` are untouched).
5. Firm signup path that renders `AdvisorFirmSignupModal` — confirm its styling still loads from `LandingPage.module.css`.
6. `npm run lint` — passes with `--max-warnings 0`.
7. `npm run build` — production build completes; generated route HTML for `/foradvisors`, `/pricing`, `/security`, `/net-worth` still emits (see `scripts/generate-route-html.js`).
8. Lighthouse/LCP sanity check on `/` — hero image or video loaded with `loading="eager"` for above-the-fold media only.

## Confirmed decisions (from user Q&A)

- **CSS module**: fork. New `LandingPageV2.module.css`; `LandingPage.module.css` left untouched so advisor flows keep working.
- **Media**: source components/illustrations from open-license libraries on the internet; build static dashboard mockups in JSX/Tailwind/SVG rather than reusing the existing findash-{cashflow,estate,goals} videos or the `InteractiveDashboardPreview` component. Bank logos (`/assets/logos/banks/*.png`) reused.
