# Re-attempt PR #60's reblocking fixes — staged & careful

## Context

PR #60 tried to fix inconsistent Screen Time reblocking by adding telemetry, a `ReblockArmer`, an `eventDidReachThreshold` reblock path, and a BG-task-register call in `App.init()`. It also dropped `applicationCategories` / `webDomainCategories` from `applyShields()`. The bundle crashed on launch on real devices with Screen Time approved (build 19), and was reverted via PR #61 (build 20 shipped from reverted main, currently `WAITING_FOR_REVIEW`).

Root cause was not isolated before revert. Most likely vectors recorded in `memory/project_pr60_revert_crash.md`: the `monitorAuthorizationChanges` Combine sink calling the new `applyShields()`, the `restorePersistedGrants` rewrite, or `removeUnsupportedCategories(from: &blockedApps)` mutation pattern.

**The original problem still exists**: timed-access expirations don't always reblock reliably — sometimes the user stays in the app past the timer. We want to extract the durable, low-risk themes from PR #60 in three small staged PRs, with a real-device verification fixture for each one.

The post-revert baseline already has 4 of 5 reblock paths wired:
- ✅ in-process `Task.sleep` timer (`scheduleRelock`)
- ✅ per-token `intervalDidEnd` via `scheduleDeviceActivityReblock` + `reblockTokenKeyPrefix`
- ✅ `.timeSensitive` notification at T+1s (mid-session shield repaint)
- ⚠️ `BGAppRefreshTaskRequest` is `submit()`ed but `BGTaskScheduler.register` is **never called** → silently no-ops
- ❌ `eventDidReachThreshold` only does blanket `applyShieldsFromSharedData()`, not per-token

So the gap is much smaller than PR #60 implied.

## Staged PRs

### PR1 — Observability + threshold-event reblock (combined)

**Risk: low.** Pure additions. Touches no existing decision logic.

**New files:**
- `MojoiOS/Core/ScreenTime/ReblockTelemetry.swift` — App Group counters keyed by path:
  - Keys (under `group.com.mo.MojoiOS`): `reblockTelemetry.inProcessTimer`, `.bgTask`, `.intervalDidEnd`, `.thresholdEvent`, `.notificationT1`. Each holds an `Int` count.
  - Companion key per path: `reblockTelemetry.lastFireTimestamp.<path>` (Double epoch).
  - One static `record(path:)` entrypoint that bumps the count and writes the timestamp.
  - All writes idempotent; never crashes if `sharedDefaults` is nil.
- Mirror file at `MojoDeviceActivity/ReblockTelemetry.swift` (or shared Swift Package) — extension can't import the main target. Use the same App Group keys.

**Wire-up in `MojoiOS/Core/ScreenTime/TimedAccessManager.swift`:**
- `handleExpiry` — record `.inProcessTimer` after `reapplyShieldForApp`.
- `handleBackgroundRelock` (static) — record `.bgTask`.
- `scheduleExpiryNotification` — recorded by the notification delegate's `willPresent`/`didReceive` for `expiredNotificationIdentifier(for:)`. Best effort; if not feasible, skip and live with no telemetry on that path (the notification doesn't reblock directly — it triggers iOS shield repaint).

**Wire-up in `MojoDeviceActivity/DeviceActivityMonitorExtension.swift`:**
- `intervalDidEnd` for `reblockActivityPrefix` slugs — record `.intervalDidEnd` inside `reapplyShieldForExpiredBreak` after the successful `store.shield.applications = currentApps` write.
- `eventDidReachThreshold` — change behavior:
  - Add a new constant in `ScreenTimeConstants`: `reblockEventPrefix = "com.mo.MojoiOS.reblockEvent."` and `reblockEventTokenKeyPrefix = "reblock.event.token."`.
  - When `event.rawValue.hasPrefix(reblockEventPrefix)`, derive slug, look up token from `reblockEventTokenKeyPrefix + slug`, reapply per-token (mirror of `reapplyShieldForExpiredBreak`).
  - Record `.thresholdEvent`.
  - Keep the blanket fallback `applyShieldsFromSharedData()` for any non-reblock event so we don't regress the existing behavior.

**Wire-up in `TimedAccessManager.grantAccess` / `scheduleDeviceActivityReblock`:**
- In addition to the existing `DeviceActivitySchedule`, register a `DeviceActivityEvent.Name(reblockEventPrefix + slug)` event with `threshold: DateComponents(second: Int(expiryDate.timeIntervalSince(now)))` (or a tighter `.minute`/`.second` mix). Per Apple, the event fires when the threshold elapses inside the schedule.
- Persist the token under `reblockEventTokenKeyPrefix + slug`.
- Pass `events: [eventName: event]` into `startMonitoring(_:during:)`.
- `cancelDeviceActivityReblock` — also remove the event-token defaults entry.

**Debug surface (gated to debug builds or hidden settings row):**
- `MojoiOS/UI/Debug/ReblockTelemetryView.swift` — read-only list showing each counter and last-fire timestamp. Tap to reset all counters. Not user-facing in shipped builds.

**Verification fixture (must run before merging PR1):**
1. Real device, Screen Time approved (`approvedWithDataAccess` ideally).
2. Block one app (single token, no categories) via `BlockedAppsView`.
3. Cold-launch the app from springboard (kill via swipe first). Confirm no crash on launch — this is the *primary* regression check.
4. Trigger the shield, take a 60s grant via `BlockerInterventionView`.
5. Open the granted app and stay in it past T+0. Confirm shield repaints over the foreground app.
6. Open `ReblockTelemetryView` — at least one path counter should be ≥ 1. Note which path(s) fired.
7. Repeat with app backgrounded (Mojo suspended) at T+0. Confirm `.intervalDidEnd` or `.thresholdEvent` counter increments.
8. Toggle Screen Time off → on in Settings between cold launches to exercise the `monitorAuthorizationChanges` Combine sink (this is the suspected PR #60 crash vector — we touch nothing here, but every PR must verify this path stays clean).

### PR2 — BG task register fix (two-phase `App.init()`)

**Risk: medium.** Refactors the App entry point and changes which threads/order things run on.

**`MojoiOS/Info.plist`** — confirm presence (post-revert state has neither):
- `BGTaskSchedulerPermittedIdentifiers` array containing `"com.mo.MojoiOS.relockExpiredGrants"` (matches `TimedAccessManager.backgroundTaskIdentifier`).
- `UIBackgroundModes` array containing `"fetch"`. (`BGAppRefreshTaskRequest` is the "fetch" mode; `processing` is for `BGProcessingTaskRequest`. We use the former.)

**`MojoiOS/App/MojoiOSApp.swift`** — restructure `init()`:
```swift
@State private var container: DependencyContainer
@State private var notificationManager: NotificationManager

init() {
    // Must happen before any BGTaskScheduler.submit call. The first submit
    // happens inside DependencyContainer init → TimedAccessManager.init →
    // restorePersistedGrants → persistGrants → scheduleBackgroundRelock.
    TimedAccessManager.registerBackgroundTask()

    let manager = NotificationManager()
    manager.configure()
    _notificationManager = State(initialValue: manager)

    let deps = DependencyContainer()
    _container = State(initialValue: deps)
}
```

Drop the property-initializer form `@State private var container = DependencyContainer()` — that initializer runs before `init()` body, defeating the ordering.

**Verification fixture (in addition to PR1's checks):**
- Cold launch with Screen Time approved + at least one persisted future-dated grant in `TimedAccessPersistedGrants.v2`. Confirm no crash. (This is the exact state PR #60 crashed in.)
- Background the app immediately after granting access. Wait past expiry without foregrounding Mojo. Foreground after expiry. Confirm `BackgroundRelockPending` was set and `reblockTelemetry.bgTask` counter incremented.
- Confirm `reblockTelemetry.bgTask` > 0 over a 24-hour soak with normal usage.

### PR3 — `ReblockArmer` factoring (optional, data-driven)

**Only ship if** PR1's telemetry shows multiple paths firing redundantly or the wake paths feel fragile after a week of soak. If telemetry shows the existing setup is reliable, skip this entirely — it's pure factoring with no behavior change.

If we do ship: extract the "arm all 5 wake paths for token X expiring at date Y" logic from `grantAccess` into a single `ReblockArmer.arm(token:, expiry:)` method. Same shape as PR #60 but without the launch-time `monitorAuthorizationChanges` interaction that we suspect contributed to the crash.

### PR4 — Drop `applicationCategories` / `webDomainCategories` from `applyShields()`

**Risk: medium.** This was on PR #60's suspect list as a possible crash vector (mutation pattern when running app has categories in flight).

Only ship after PR1, PR2, and (optional) PR3 are stable in TestFlight. Keep this as a one-line edit:
- `ScreenTimeManager.applyShields()` — drop the two `applicationCategories` and `webDomainCategories` assignments.
- Real-device fixture: verify shields still paint for individual apps; confirm there's no regression to category-level shielding (which folklore says doesn't paint reliably anyway).

If a regression appears, this PR alone reverts cleanly without touching the reblock infrastructure.

## Themes from PR #60 we are explicitly NOT re-introducing

- **`removeUnsupportedCategories(from: &blockedApps)` in `blockedApps.didSet`** — even though Swift suppresses didSet re-entry from within the same setter (proven via `/tmp/test-inout2.swift`), the mutation-during-publish pattern is on the suspect list for the crash. Skip.
- **Touching `monitorAuthorizationChanges` semantics** — that Combine sink fires `applyShields()` on auth state change. This is the most-suspected crash path. We don't change `applyShields()` until PR4, and PR4 is purely subtractive.
- **Single combined "reblock fix" PR** — PR #60 was one mega-PR. Each PR here is a single concern with its own verification fixture.

## Critical files (with current line numbers post-revert)

| File | Change |
|---|---|
| `MojoiOS/Core/ScreenTime/ReblockTelemetry.swift` | NEW (PR1) |
| `MojoDeviceActivity/ReblockTelemetry.swift` | NEW or shared package (PR1) |
| `MojoiOS/Core/ScreenTime/TimedAccessManager.swift` | PR1: add telemetry calls in `handleExpiry` (L195), `handleBackgroundRelock` (L209), `grantAccess` (L67); register threshold event in `scheduleDeviceActivityReblock` (L359); persist event token; cleanup in `cancelDeviceActivityReblock` (L402) |
| `MojoDeviceActivity/DeviceActivityMonitorExtension.swift` | PR1: add per-token reblock branch in `eventDidReachThreshold` (L45); telemetry calls in `reapplyShieldForExpiredBreak` (L57) |
| `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift` | PR1: add `reblockEventPrefix`, `reblockEventTokenKeyPrefix` constants |
| `MojoiOS/UI/Debug/ReblockTelemetryView.swift` | NEW (PR1, debug only) |
| `MojoiOS/Info.plist` | PR2: add `BGTaskSchedulerPermittedIdentifiers`, `UIBackgroundModes` |
| `MojoiOS/App/MojoiOSApp.swift` | PR2: refactor `init()` for two-phase container construction (currently L19-L24) |
| `MojoiOS/Core/ScreenTime/ScreenTimeManager.swift` | PR4: drop categories from `applyShields()` (currently L114-L119) |

## Verification (end-to-end)

Before merging each PR:
1. Build for iPhone 17 Pro simulator. Confirm clean launch with Screen Time *not* approved.
2. Build for real device (iPhone 16 Pro). Approve Screen Time. Cold-launch from springboard. Confirm no crash. *This is the primary regression check — PR #60 only crashed in this state.*
3. Run that PR's specific fixture above.
4. Cycle scenePhase: foreground → background → foreground. Confirm `monitorAuthorizationChanges` sink doesn't crash.
5. After merge, ship to TestFlight Public Beta following `.claude/skills/ship-testflight/SKILL.md`. Soak for ≥24 hours and check telemetry counters before deciding the next PR.

If the launch crash from PR #60 reproduces in any PR's verification, fetch the Xcode crash log (Window → Devices and Simulators → View Device Logs) before re-attempting. The crash log short-circuits the hypothesis tree we lost time on last round.
