# Plan: Convert `/bach-feature` Phase 4 from parallel batch to Ralph loop

## Context

The `/bach-feature` skill at `/Users/johnathanmo/SAMWEALTH-new/.claude/skills/bach-feature/SKILL.md` currently builds redesigned features by spawning N parallel `Agent` subagents in a single message ("the batch") in Phase 4. Each subagent is one-shot, writes to a disjoint directory glob, and never gets feedback or a chance to self-correct. This is fast but brittle — when a shard fails, you discover it only at the lint/build gate, and the repair loop is bolted on as an afterthought (Phase 6).

The user wants the build phase replaced with a Ralph autonomous loop (the same one driven by `~/.claude/skills/jmo-ralph/`). Ralph already exists in this repo at `scripts/ralph/`. It picks the highest-priority story with `passes: false` from `scripts/ralph/prd.json`, implements it, runs the project's quality checks, commits, marks the story complete, and iterates. Each iteration is a fresh `claude --print` subprocess reading `scripts/ralph/CLAUDE.md`. Ralph stops when all stories pass (`<promise>COMPLETE</promise>`) or hits max iterations.

The trade-off the user is buying: slower wall-clock for sequential, self-correcting, story-by-story commits with quality gates baked into every iteration — instead of one fast batch with no feedback.

User-confirmed decisions:
1. **Async background** — skill exits immediately after kicking off ralph. Phases that depended on ralph completion (lint/build gate, /qa, final report) are removed from the skill or repositioned before ralph starts.
2. **Final ralph story** — App.jsx route wiring becomes the last user story in `prd.json`, not a sequential post-ralph step.

## New phase structure

Phases 0–2 unchanged. Phase 3 expanded. Phases 4–8 collapse into three new phases (4 doc, 5 prd.json + ralph bootstrap, 6 launch-and-exit).

| Phase | Was | Now |
|---|---|---|
| 0 | Bootstrap & detection | unchanged |
| 1 | Confirm scope (3 questions) | + 2 questions: ralph tool (`claude`/`amp`), max iterations (default 30) |
| 2 | Spec exploration & write | unchanged (parallel Explore subagents are about *reading*, not *building* — not "the batch" the user means) |
| 3 | Design token cheat-sheet (in-memory) | now writes cheat-sheet to disk so each ralph iteration can read it |
| 4 | (was Phase 8) Write user-facing doc | moved up — runs on main thread before ralph starts |
| 5 | (was Phase 4) Parallel build | replaced with: generate `scripts/ralph/prd.json` from the spec, sharded by directory disjointness with route wiring as final story |
| 6 | (was Phases 5–7) Route wiring + lint/build + QA | replaced with: bootstrap ralph infrastructure, kick off ralph in background, exit |
| — | (was Phase 8) Doc | promoted to Phase 4 |

## Critical files

**Edit:**
- `/Users/johnathanmo/SAMWEALTH-new/.claude/skills/bach-feature/SKILL.md` — the only file this plan changes

**Reference (no edit):**
- `/Users/johnathanmo/.claude/skills/jmo-ralph/SKILL.md` — bootstrap recipe to copy from (don't depend on `/jmo-ralph` being run; inline the bootstrap into bach-feature so it's self-contained)
- `/Users/johnathanmo/SAMWEALTH-new/scripts/ralph/ralph.sh` — the runner; bach-feature invokes it directly
- `/Users/johnathanmo/SAMWEALTH-new/scripts/ralph/CLAUDE.md` — the per-iteration instructions; bach-feature writes a customized version that embeds the design-token cheat-sheet and hard-write-boundary rules
- `/Users/johnathanmo/SAMWEALTH-new/scripts/ralph/prd.json` — example of the schema bach-feature generates
- `/Users/johnathanmo/ralph/skills/ralph/SKILL.md` — story-sizing rules and prd.json schema (re-use these conventions verbatim)

## Phase-by-phase changes

### Phase 1 — Confirm scope

Add two questions to the existing batched `AskUserQuestion` call:

4. **Ralph tool** — `claude` (default, recommended) / `amp`. Captures `$RALPH_TOOL`.
5. **Max ralph iterations** — `20` / `30` (default) / `50` / `Custom`. Captures `$RALPH_MAX_ITERATIONS`.

### Phase 3 — Design token extraction (now writes to disk)

Reads `DESIGN.md` once, builds the same cheat-sheet (palette, gradients, shadows, fonts, motion), and writes it to **`scripts/ralph/design-tokens.md`** so each ralph iteration can read it. Reason: ralph iterations are fresh subprocesses with no in-memory context handoff. The cheat-sheet must be a file ralph's customized `CLAUDE.md` can reference.

Exit gate: `scripts/ralph/design-tokens.md` exists and contains the verbatim paste-ready strings.

### Phase 4 — Write user-facing doc (promoted from old Phase 8)

Moved up so it runs on the main thread *before* ralph kicks off. The doc only needs the spec (which Phase 2 produced) and the route URL (set in Phase 1) — neither requires the new code to exist yet. Same content rules as before (~80–120 lines, no implementation terms, link to spec). File path: `$DOCS_DIR/$FEATURE_NAME.md`.

Exit gate unchanged: doc file exists; spec link resolves; no implementation terms leaked.

### Phase 5 — Generate `scripts/ralph/prd.json`

Replaces the old "parallel batch" entirely. On the main thread, derive a prd.json from the spec.

**Story shape:** each user story = one shard from the original Phase 4 sharding table, but ordered dependencies-first (leaves before composites). Default 6 stories:

| Story | Title | Hard write boundary |
|---|---|---|
| US-001 | Shared internal components | `src/pages/$NEW_DIR/_components/**` |
| US-002 | List / table view | `src/pages/$NEW_DIR/list/**` |
| US-003 | Detail / drawer view | `src/pages/$NEW_DIR/detail/**` |
| US-004 | Forms / edit view | `src/pages/$NEW_DIR/edit/**` |
| US-005 | Page shell | `src/pages/$NEW_DIR/index.jsx`, `src/pages/$NEW_DIR/${NEW_DIR}Layout.jsx` |
| US-006 | Wire route into App.jsx | `src/App.jsx` (insertion-only) |

Heuristic for story-count adjustment is the same as the old Phase 4: ≤2 surfaces → drop list/detail/edit down to a single combined story; 3–4 → trim accordingly; 5+ → full 6.

**Each story's `acceptanceCriteria` must include:**
- The hard-write-boundary glob (verbatim)
- "Read `SPECS/$SPEC_FILENAME` before writing"
- "Use design tokens from `scripts/ralph/design-tokens.md` — do not invent hexes, gradients, easing curves, or shadow recipes"
- "Do NOT modify `src/pages/<OldDir>/**` or import from it"
- "Do NOT modify any sibling shard's directory"
- "`npm run lint` passes with `--max-warnings 0`"
- "`npm run build` passes (or `npm run build:lowmem` on OOM)"
- For US-006 only: "Insertion-only edit to `src/App.jsx`; `git diff src/App.jsx` shows no other modifications anywhere"

**prd.json top-level fields:**
- `project`: `"$FEATURE_PASCAL redesign — bach-feature"`
- `branchName`: current branch (read via `git rev-parse --abbrev-ref HEAD`) — not `ralph/<feature>` because bach-feature runs on whatever feature branch the user is on; ralph.sh's branch-archive logic should not trigger
- `description`: short paragraph naming the new route, the new directory, and the additive-not-replacing rule
- `userStories`: the 6 entries above, all with `passes: false` and empty `notes`

**Archive guard:** if `scripts/ralph/prd.json` exists with a different `project`, archive it the way ralph.sh's branch-change logic does (`scripts/ralph/archive/YYYY-MM-DD-<old-project-slug>/`) before overwriting. Never silently clobber an in-flight ralph run.

Exit gate: `scripts/ralph/prd.json` exists, validates as JSON, has 2–6 user stories, every story has `passes: false`, and the boundary acceptance criteria are present on every story.

### Phase 6 — Bootstrap ralph infrastructure and kick off

Replaces the old Phases 5 (route wiring), 6 (lint/build), 7 (QA), and final report.

**Bootstrap (only if files missing) — copies the recipe from `~/.claude/skills/jmo-ralph/SKILL.md`:**

```bash
mkdir -p scripts/ralph
[ ! -f scripts/ralph/ralph.sh ] && cp ~/ralph/ralph.sh scripts/ralph/ralph.sh
chmod +x scripts/ralph/ralph.sh
[ ! -f scripts/ralph/progress.txt ] && printf '# Ralph Progress Log\nStarted: %s\n---\n' "$(date)" > scripts/ralph/progress.txt
# Apply nested-session fix if missing
grep -q 'env -u CLAUDECODE' scripts/ralph/ralph.sh || \
  sed -i '' 's|claude --dangerously-skip-permissions|env -u CLAUDECODE claude --dangerously-skip-permissions|' scripts/ralph/ralph.sh
```

**Write a customized `scripts/ralph/CLAUDE.md` (overwriting whatever was there):**
This is the per-iteration prompt. It's a copy of the standard ralph CLAUDE.md plus three blocks injected before the "Quality Requirements" section:

1. **Hard write boundary** — paragraph from old Phase 4 Block 3, scoped to the current story's boundary glob (read it from the prd.json story being worked on). Boilerplate explains: "You may READ any file in the repo. You must NOT modify `src/App.jsx` (except in US-006), `src/pages/<OldDir>/**`, or any sibling shard's directory. If your task seems to require modifying any of those, return early and report."
2. **Design tokens** — a directive to read `scripts/ralph/design-tokens.md` before writing any UI code, and the verbatim "do not invent hexes, gradients, easing curves, or shadow recipes" line.
3. **Old route stays alive** — paragraph re-stating that the redesign is purely additive; the old feature directory is read-only reference.

**Kick off ralph in the background:**

```bash
cd "$(git rev-parse --show-toplevel)" && \
  scripts/ralph/ralph.sh --tool $RALPH_TOOL $RALPH_MAX_ITERATIONS
```

Use `Bash` with `run_in_background: true` per the user's `~/.claude/CLAUDE.md` deployment-style convention.

**Exit message to user (replaces old final report):**
- Spec path: `$SPEC_DIR/$SPEC_FILENAME`
- Doc path: `$DOCS_DIR/$FEATURE_NAME.md`
- prd.json path: `scripts/ralph/prd.json`
- Tool: `$RALPH_TOOL`, max iterations: `$RALPH_MAX_ITERATIONS`
- Watch progress: `tail -f scripts/ralph/progress.txt`
- Watch story status: `cat scripts/ralph/prd.json | jq '.userStories[] | {id, title, passes}'`
- Once ralph reports COMPLETE: run `/qa` manually to dogfood the new route at `$NEW_ROUTE`

Exit gate: ralph background process is running (return value of background Bash call indicates a started process).

## Removed phases

- **Old Phase 5 (route wiring)** — folded into ralph as US-006
- **Old Phase 6 (lint + build gates)** — ralph enforces these per-iteration as acceptance criteria; the runner won't mark a story `passes: true` without them
- **Old Phase 7 (/qa)** — user-driven post-ralph; the skill's exit message tells them when and how
- **Old "final report"** — replaced by the kickoff exit message

## Why this preserves the original safety properties

The original Phase 4 leaned on parallel-disjoint-globs as a *constructive* safety guarantee (concurrent writes to non-overlapping paths cannot collide). With ralph, the loop is sequential — there's no concurrency to defend against — but the per-story write boundary is still important for scope discipline (story B mustn't touch story A's files). The boundary moves from a runtime invariant (Phase 4) to an acceptance criterion (each prd.json story). Plan calls this out explicitly in the SKILL.md's "Operating rules" section so the next reader doesn't lose the property.

The "old route untouched" invariant is unchanged — it's now restated in the ralph CLAUDE.md hard-write-boundary block so every ralph iteration sees it.

The "DESIGN.md tokens are paste-only" invariant is unchanged — it's restated in the ralph CLAUDE.md design-tokens block, and the cheat-sheet itself is now on disk at `scripts/ralph/design-tokens.md` so every fresh subprocess can read it.

## Verification

End-to-end smoke test (run by the user, not the plan-writer):

1. Pick a small feature with an existing route, e.g., `/recommendations` if it exists.
2. Run `/bach-feature recommendations`.
3. Confirm the skill stops after kicking off ralph (no lint/build/QA waiting).
4. Confirm `SPECS/RECOMMENDATIONS_SPEC.md`, `docs/recommendations.md`, `scripts/ralph/prd.json`, `scripts/ralph/design-tokens.md`, and a customized `scripts/ralph/CLAUDE.md` all exist.
5. `cat scripts/ralph/prd.json | jq '.userStories | length'` returns 2–6.
6. Watch `tail -f scripts/ralph/progress.txt` and confirm ralph picks US-001 (shared components) first.
7. After ralph reports COMPLETE: `/recommendations-v2` (or chosen route) renders the new feature and the old `/recommendations` still works.
8. `git log --oneline | head -10` shows one commit per story plus one for route wiring.

Static verification on the SKILL.md edit itself:
- `grep -c "Phase " /Users/johnathanmo/SAMWEALTH-new/.claude/skills/bach-feature/SKILL.md` returns 7 (Phase 0 through Phase 6).
- No `Agent` calls remain in Phase 4 or later (the parallel build batch is gone).
- The frontmatter `allowed-tools` no longer needs `Agent` for the build phase, but keeps it for Phase 2 Explore. Update `allowed-tools` to drop nothing — `Agent` is still needed for Phase 2.
- Description in frontmatter updated to mention "drives a Ralph loop" instead of "spawns parallel subagents".
