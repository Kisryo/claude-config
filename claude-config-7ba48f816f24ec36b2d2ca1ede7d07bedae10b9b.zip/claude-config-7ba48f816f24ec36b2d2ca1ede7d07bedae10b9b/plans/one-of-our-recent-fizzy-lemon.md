# Fix cold-launch perf regression on home dashboard

## Context

**User report**: Home dashboard takes **3–10 seconds to load on cold launch** (Mojo killed → tap icon). Started "the last few days" — user is on TestFlight build 27 or 28. User suspects the slow launch is *also* what's making timed-access reblocking appear broken (if the main thread is starved during cold launch, the `scenePhase .active` reconcile in `MojoiOSApp.swift:298` and any in-process expiry checks land too late). Per the user's request, this plan focuses on cold-launch perf; the reblock failure is treated as a downstream symptom we expect to recover once launch is fast.

The user's heuristic: the regression is tied to **"the change we made to the app tap sheet in rules"** — i.e. PR #79 (`08d5526`, *Hard rules enforcement + dashboard cleanup*). PRs #78 (streaks), #80 (friends-tab redesign), and #81 (activity-feed dedup + history-cache invalidation) all also landed in the same 48-hour window.

## Suspect inventory

I have not yet confirmed a single root cause. The diff between PR #77 and HEAD adds 4,095 lines and removes 1,180. Plausible cold-launch contributors, ranked by likelihood:

1. **`ContentView.swift:31-37` — `.onAppear` calls `screenTimeManager.applyShields()` synchronously on the main actor**. Every cold launch. `applyShields()` does multiple `ManagedSettings.shield.*` setter mutations, which on a physical device round-trip to the FamilyControls daemon and can take hundreds of ms each. This already runs once via `TimedAccessManager.restorePersistedGrants()` (`TimedAccessManager.swift:379`) earlier in the boot sequence — the `ContentView.onAppear` call is redundant and load-bearing only on rare cases (onboarding flow used a different `ScreenTimeManager` instance). Moving this off the synchronous appear callback is the cheapest, lowest-risk win.

2. **`MojoiOSApp.swift:67` — `_container = State(initialValue: DependencyContainer())` runs the entire DI graph synchronously in `App.init()`**, before SwiftUI can present anything. The graph now constructs ~12 services (`ScreenTimeManager`, `TimedAccessManager`, `DeviceActivityScheduler`, `ScreenTimeTracker`, `ScreenTimeDataAccessCollector`, `BackendLLMProvider`, `AuthService`, `SocialService`, `LeaderboardService`, `StatsSyncService`, `InviteLinkService`, `ChallengeService`, `PushNotificationService`, `ActivityFeedService`, `ReferralService`). `ScreenTimeManager.init` synchronously calls `AuthorizationCenter.shared.authorizationStatus` (FamilyControls IPC). `TimedAccessManager.init` calls `restorePersistedGrants()` which decodes JSON tokens, walks `DeviceActivityCenter().activities`, runs `cleanUpStaleWallClockActivities()`, calls `applyShields()`, and starts/reconciles Live Activities. `ScreenTimeTracker.init` reads a snapshot file. `BackendLLMProvider.init` builds a `CertificatePinningSession`.

3. **`ActivityFeedService.startListening()` fires immediately on attach** (called from `auth.onSignIn` handler at `DependencyContainer.swift:140-148` and from `performLaunchSequence` at line 291). The Firestore snapshot listener fires *synchronously* with cached data; the callback hops back to `@MainActor` and runs `applyFetchedEvents` (`ActivityFeedService.swift:99-108`) which **fetches all `ActivityEvent` rows, deletes them all, inserts up to 50 new ones, and calls `context.save()` — all on the main actor**. With a busy social graph this can fire repeatedly during boot.

4. **PR #78 added two fields to `StreakProgress`** (`lastUpdatedAt: Date`, `ownerUserId: String?`). That's a SwiftData schema change → a one-time migration on first launch after upgrade. *One-time only* — not a cold-launch-every-time cause, but worth ruling out as a confound.

5. **`ChallengeService.configure(modelContext:)` at `DependencyContainer.swift:175`** now calls `loadCachedChallenges()` *and* `backfillCompletionUIShown()` (added by PR #80). `backfillCompletionUIShown` does `context.fetch(FetchDescriptor<Challenge>(predicate: ...completed))` plus mutations.

6. **`StreakManager.fetchOrCreate(modelContext:)` and `evaluateStreakIfNeeded`** run on every foreground (including cold launch) and now do extra Firebase work via `statsSyncService.syncStreakProgress` if signed in.

## Goal

Get cold-launch dashboard time back under 1 second. Two-step approach: **measure first**, then fix the confirmed bottleneck. Don't blindly refactor everything.

## Step 1 — Instrument the boot path with `os_signpost`

Add `OSLog` signposts at the boundaries below so we can see exactly where the 3–10s is being spent. This is the only way to avoid guessing. Five-minute change, removable in one commit.

Critical files & sites:

- `MojoiOS/App/MojoiOSApp.swift:61-68` — wrap `MojoiOSApp.init` with a signpost (`AppInit`).
- `MojoiOS/Core/DependencyContainer.swift:60-148` — wrap `DependencyContainer.init` (`DIInit`), and add child signposts around: `ScreenTimeManager()` init, `TimedAccessManager()` init, `ScreenTimeTracker()` init, `BackendLLMProvider()` init, the social-services block, the `wireAuthenticatedLaunchHandlers`/`auth.onSignIn` plumbing.
- `MojoiOS/Core/ScreenTime/TimedAccessManager.swift:321-397` — wrap `restorePersistedGrants` (`RestoreGrants`).
- `MojoiOS/Core/DependencyContainer.swift:260+` — wrap `performLaunchSequence` (`LaunchSeq`) and each major await inside it (`startMonitoring`, `syncBestAvailableScreenTimeForFriends`, `loadProfile`, `startListening` calls).
- `MojoiOS/App/ContentView.swift:31-37` — wrap the `onAppear` block (`ContentAppear`) so we can see if `applyShields()` is the dominant cost.

Run on the user's physical device with Instruments (`Product → Profile`, then "App Launch" or "os_signpost"). The user can then attach the .trace and we'll know the actual offender within minutes instead of guessing across five candidates.

## Step 2 — Apply the targeted fixes the trace identifies

The fixes below are pre-staged so we can land whichever ones the signpost data indicts. Do **not** apply them all blindly — each has nuance and needs the trace to justify the change.

### Fix A — Move `applyShields()` off `ContentView.onAppear` (highest probability)

`MojoiOS/App/ContentView.swift:31-37` currently:

```swift
.onAppear {
    dependencies?.screenTimeManager.reloadPersistedSelection()
    dependencies?.screenTimeManager.applyShields()
}
```

Replace with:

```swift
.task {
    // Onboarding ran in a separate `ScreenTimeManager` instance, so re-read
    // its persisted selection before applying. Run off the appear callback
    // so cold-launch doesn't block on FamilyControls daemon round-trips.
    dependencies?.screenTimeManager.reloadPersistedSelection()
    dependencies?.screenTimeManager.applyShields()
}
```

`.task` is async-aware and runs after first frame. `restorePersistedGrants()` already calls `applyShields()` during DI init (`TimedAccessManager.swift:379`), so dropping this synchronous call should not regress shield correctness — but the task-deferred re-apply still picks up onboarding-time changes. Verify by selecting/unselecting an app in onboarding and confirming the shield engages on first cold launch.

### Fix B — Defer `ActivityFeedService.startListening()` and stop wiping SwiftData on every snapshot

Two related issues in `MojoiOS/Core/Social/ActivityFeedService.swift`:

1. **Wipe-and-insert on every snapshot** (`applyFetchedEvents`, lines 99-108) is doing far more work than needed. Switch to a diff: keep a `Set<String>` of seen `firestoreId`s, only insert new rows, and only delete rows whose `firestoreId` is no longer in the snapshot. This bounds main-actor work per listener fire to the actual delta, not the full 50-row replacement.

2. **The listener attaches at sign-in** (called from `DependencyContainer.swift:140-148` and `performLaunchSequence` at 291) and fires its first snapshot immediately on the boot critical path. Defer with a `Task.detached(priority: .background) { ... await Task.yield(); /* attach */ }` *or* attach after a `try? await Task.sleep(for: .milliseconds(500))` so the dashboard has time to render before the SwiftData write storm starts. The lag is invisible on a busy social feed; it's only the boot-frame budget we need to protect.

### Fix C — Lazy-initialize the LLM/Firebase-touching services

If the signpost shows DI init alone is 1+ seconds, split `DependencyContainer` into "essentials" (created in `App.init`) and "deferred" (created lazily on first access from a background `Task` in `performLaunchSequence`). Most likely candidates to defer:

- `BackendLLMProvider` (cert-pinned URLSession setup; only needed once chat opens)
- `ReferralService` (only used post-onboarding)
- `PushNotificationService` (only used after sign-in)
- `LeaderboardService` (only used in Friends tab)

Keep `ScreenTimeManager`, `TimedAccessManager`, `ScreenTimeTracker`, and `AuthService` eager — the dashboard renders against them. This is a structural change, so only pursue it if Fixes A + B don't get launch under 1 second.

### Fix D — Skip `ChallengeService.backfillCompletionUIShown` when modelContext is empty

`MojoiOS/Core/Social/ChallengeService.swift:150` runs a `FetchDescriptor<Challenge>` query and mutations even on first-ever launch when the table is empty. Add an early-return:

```swift
private func backfillCompletionUIShown() {
    guard let context = modelContext else { return }
    var emptyDescriptor = FetchDescriptor<Challenge>()
    emptyDescriptor.fetchLimit = 1
    if (try? context.fetch(emptyDescriptor))?.isEmpty ?? true { return }
    // ... existing work ...
}
```

Only ship if the trace shows the fetch is non-trivial.

## Verification

1. **Quantitative**: Build + install on the user's device. Profile cold launch with Instruments → "App Launch" template. Take a `os_signpost` reading at HEAD and after each landed fix. Target: <1s from process spawn to dashboard first frame.
2. **Reblock recovery**: After the perf fix lands, repeat the user's reblock test — grant access for 1 minute, stay in the granted app, wait. The reblock should now reapply the shield at expiry. If it still fails, the reblock has its own bug independent of perf and we go back to the reblock-paths plan.
3. **Regression sweep**:
   - Cold launch + onboarding flow: shield still engages on first cold launch after onboarding (Fix A safety check).
   - Activity feed: feed still updates live when a friend posts a challenge (Fix B safety check).
   - Friends tab: leaderboard still loads (Fix C safety check, if applied).
4. **Telemetry sanity**: `ReblockTelemetry.count(for: .reconcileForeground)` should still increment after a foreground that catches an expired grant. No silent regressions in the existing reconcile path.

## Out of scope

- Any change to `TimedAccessManager.scheduleDeviceActivityReblock` (the 16-min wall-clock schedule from PR #77). Leave it alone — if the perf fix doesn't restore reblock, we revisit reblock as a separate fix.
- The per-app history queries in `AppDetailSheet` (`appMinutes`, `appDailyTotals`, `appHourlyBreakdown`). Those run only when the sheet is presented, not on dashboard load.
- Anything in PRs #78, #80, #81 not on the cold-launch hot path.
