# Optimistic updates for /forms Settings toggles

## Context

Clicking a switch in `/forms/:formId/settings` feels laggy. The toggle doesn't flip until the Firestore write round-trips and an `onSnapshot` listener pushes the new value back down through props. That's typically 300–800ms of visual lag per click.

**Data flow** (end-to-end):

1. `FormEditorLayout.jsx:19` calls `useOrgForms(organizationId)`.
2. `src/hooks/useOrgForms.js:39` subscribes via `onSnapshot` to `doc(db, 'organizations', orgId)` and exposes `forms` (the org's `onboardingFlows` array).
3. `FormEditorLayout.jsx:20,41` picks the current `form` by id and passes it through outlet context.
4. `src/pages/FormEditor/FormSettingsView.jsx:296` reads `form` via `useOutletContext()` and binds every toggle's `checked` prop directly to `form.settings.*` (e.g. line 427, 432, 440, 447, 473, 530, 539).
5. `save()` / `saveSettings()` (lines 299–307) call `await updateFlow(...)` with **no local state update**.

So the round-trip for a click is: click → write → Firestore commit → snapshot echo → parent re-renders → child gets new `form` → toggle flips. The fix is to introduce a local optimistic overlay so the toggle flips immediately and the write happens in the background.

User asked for switches/toggles specifically; the same fix naturally covers the segmented controls and selects that live alongside them (same `save`/`saveSettings` path), so they come along for the ride.

## Scope

Single file: `src/pages/FormEditor/FormSettingsView.jsx`.

No changes to `useOrgForms`, `FormEditorLayout`, or `formManagementService.updateFlow` — those are correct as-is. The fix stays local to the settings view.

## The fix

Add a small local `pending` overlay, deep-merged over `form` for every read. Writes update the overlay first, then fire the Firestore update. On error, drop the overlay so the UI reverts to the server-confirmed value.

### Shape of the change in `FormSettingsView.jsx`

1. Add a `pending` state and a `deepMerge` helper (inline, plain JS):

   ```jsx
   const [pending, setPending] = useState({});

   // Plain-object deep merge. Arrays replaced wholesale (autoTags etc.).
   const deepMerge = (base, patch) => {
     if (patch === undefined) return base;
     if (
       patch === null ||
       typeof patch !== 'object' ||
       Array.isArray(patch) ||
       base === null ||
       typeof base !== 'object' ||
       Array.isArray(base)
     ) return patch;
     const out = { ...base };
     for (const k of Object.keys(patch)) out[k] = deepMerge(base[k], patch[k]);
     return out;
   };

   const view = useMemo(() => deepMerge(form, pending), [form, pending]);
   ```

2. Rewrite `save` / `saveSettings` / `saveTheme` to update `pending` first, then write:

   ```jsx
   const save = async (patch) => {
     setPending((prev) => deepMerge(prev, patch));
     try {
       await updateFlow({ organizationId, flowId, patch });
     } catch (err) {
       console.error('[FormSettingsView] save failed:', err);
       toast.error("Couldn't save setting.");
       setPending({}); // ground-truth-is-server on failure
     }
   };
   const saveSettings = (patch) => save({ settings: patch });
   const saveTheme = (patch) => saveSettings({ theme: patch });
   ```

   Note: `saveTheme` today spreads the old theme (`{ ...theme, ...patch }`) because it's writing the whole object. With the deep-merge pattern, we only need to send the patch — Firestore merge happens inside `updateFlow` via `applyFlowPatch`. Verify `applyFlowPatch` does a deep merge of `settings.theme` before simplifying; if it shallow-merges `settings.theme`, keep the current spread behavior for `saveTheme` (still cheap, still optimistic).

3. Replace every read of `form.*` / `s.*` / `theme.*` with reads off `view`:

   ```jsx
   const s = view?.settings || {};
   const flowType = view.flowType || 'form';
   const enabled = !!view.enabled;
   // ...same for completionAction, displayMode, allowGuest, guestAction,
   //       triggerWorkflow, theme, colorTheme, customPrimaryColor,
   //       logoPosition, showHeader, showLogo, autoCreateContact,
   //       welcomeEmail, welcomeEnabled
   ```

   Also: `<Input value={form.name} ... />` → `<Input value={view.name} ... />` and same for `view.description`. The existing local-state `Input` component (line 153) will still correctly sync from prop-change.

### Toggles/controls that benefit (all in `FormSettingsView.jsx`)

Boolean toggles (primary target):
- `enabled` — line 440
- `allowPreSignupQuiz` — line 447
- `autoCreateContactFromGuestQuiz` — line 474
- `triggerWorkflowEnabled` — line 532
- `welcomeEmail.enabled` — line 541
- `theme.showHeader` — line 427
- `theme.showLogo` — line 432

Segmented controls / selects (same path, come along free):
- `flowType` (line 363), `displayMode` (line 373), `completionAction` (line 495), `guestAction` (line 456), `welcomeEmail.triggerType` (line 552), `theme.logoPosition` (line 418), `theme.colorTheme`/`customPrimaryColor` (line 412).

Text inputs (Input component) already debounce via `onBlur`, so the perceived lag is smaller, but they still benefit — keep the same `view.*` binding for consistency.

## Non-goals

- No changes to other `/forms` tabs (Questions, Logic, Responses, Landing page) — user scoped this to Settings.
- No shared optimistic-update hook (e.g. `useOptimistic`) — one file, keep it local. If this pattern spreads, extract later.
- No change to `useOrgForms` or the service layer. `updateFlow` stays a coalesced array rewrite.
- Not touching `DeleteFormModal` button flow — delete already navigates away, no optimistic win.

## Edge cases

1. **`pending` never auto-clears on success.** Acceptable: `pending` values match server state once the snapshot catches up, so `deepMerge` is a no-op visually. If a different admin edits the form concurrently, our stale overlay would mask their change until we clear it. For single-user editing (the realistic case) this is fine. If concurrent editing becomes a real concern, add a `useEffect` that drops `pending` keys whose values already match `form`.
2. **In-flight write fails.** `setPending({})` wipes all optimistic state — the toggle snaps back to server truth and the toast surfaces the error. A narrower rollback (per-patch) is possible but not worth the complexity for a settings page.
3. **Navigating away mid-write.** `pending` is component-local, so it's discarded on unmount. The Firestore write still resolves in the background via the `updateFlow` promise; if it fails, we lose the error toast opportunity, but the write itself either succeeds or fails cleanly at the server.
4. **`Input`'s internal local state + `pending` overlay.** `Input` only syncs from `value` prop when unfocused (`FormSettingsView.jsx:160-162`), so our optimistic `view.name` won't clobber the user's in-progress typing.

## Critical files

- `src/pages/FormEditor/FormSettingsView.jsx` — the only file modified.

## Referenced for context (read-only)

- `src/pages/FormEditor/FormEditorLayout.jsx:19-41` — where `form` comes from.
- `src/hooks/useOrgForms.js:39-58` — the `onSnapshot` source of the echo delay.
- `src/services/formManagementService.js:236-248` — `updateFlow` (unchanged).

## Verification

1. `npm run dev` at the repo root.
2. Navigate to `/forms`, pick any form, then `/forms/:formId/settings`.
3. Toggle each switch in sections 02 (Branding), 03 (Access), 05 (Automation). Each should flip **immediately** on click with no visible delay.
4. Refresh the page — the new values persist (confirms Firestore write succeeded).
5. Open two browser tabs side by side on the same form settings, toggle in tab A, watch tab B update on the snapshot echo (~500ms). Confirms no regression to the real-time sync path.
6. Simulate a write failure: in DevTools, block network requests to Firestore (or temporarily throw in `updateFlow`). Click a toggle — it should flip, then snap back on error, with a toast `"Couldn't save setting."`.
7. `npm run lint` — zero new warnings (repo enforces `--max-warnings 0`).
