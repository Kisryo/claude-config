# Plan: Rewrite Real Estate Sales Emails as User Interview Requests

## Context

The sales outreach pipeline has ~120+ pending_review drafts, many targeting real estate and RE-adjacent companies. These are currently framed as cold sales pitches ("we build custom software and automation tools"). The goal is to rewrite all real-estate-related drafts to frame as **user interview requests** -- "we're building a startup in the real estate space and want to understand your workflow."

This makes the outreach feel less salesy and more like genuine product research, which tends to get better response rates from busy professionals.

## Approach: Script with Claude API Rewrites

Write a TypeScript script (`scripts/rewrite-re-to-interview.ts`) that:
1. Queries all `pending_review` sales drafts with company/prospect data
2. Filters to RE-related companies using keyword matching + manual overrides
3. Uses Claude Haiku API to rewrite each email preserving the personalized hook
4. Updates `body_text`, `body_html`, and `subject` directly in the database
5. Has dry-run and preview modes for safety

### Why Claude API (not mechanical replacement)

Each email has a unique research-based hook paragraph (specific company details, named tools, deal sizes, etc.). Mechanical find-and-replace can't smoothly reframe "Saw the news about X. Genuinely curious how your team handles Y; custom software could do Z" into interview-style curiosity without losing nuance. Claude Haiku at ~50-70 emails costs <$0.50 and takes ~15 seconds.

## Email Template Direction

### Initial emails (sequence 1)

**Before (sales pitch):**
```
Hey Craig,

Saw the news about Ongoing operations with 88+ agents listed; sold over 6,000 properties historically. 
Genuinely curious how your team handles Coordinating transaction fees and agent autonomy in 100% 
commission model for high-volume office -- whether it's mostly manual right now or if you've got systems.

I'm a CS student at Columbia, and my co-founder Alex and I (prev. Google, Capital One) build custom 
software and automation tools for companies running into exactly these kinds of bottlenecks...

Not pitching anything specific. Just trying to understand if there's a real problem worth solving here.

Johnathan Mo
Columbia University | CS
Co-founder, Outreach Machine
```

**After (user interview):**
```
Hey Craig,

Saw that Equity Real Estate has 88+ agents and has sold over 6,000 properties -- that's a lot of 
transaction volume to coordinate.

My co-founder Alex and I are CS students at Columbia building a startup in the real estate space. 
We're trying to understand how brokerages like yours actually handle things like transaction 
tracking and commission coordination day-to-day before we build anything.

Would you be open to a quick 15-30 min chat? No pitch -- genuinely just trying to learn from 
people doing this work.

Book a time here: https://booking.akiflow.com/johnathan-m-0da1

Best,
Johnathan Mo
Columbia University | CS | prev. Google, incoming SIG
linkedin.com/in/johnathan-mo
```

### Follow-up emails (sequence 2)

```
Hey {firstName},

Wanted to follow up on my last note -- still trying to understand how {aspect} works for 
teams like yours. If you have 15 mins to chat, would genuinely love to hear about it.

Book a time here: https://booking.akiflow.com/johnathan-m-0da1

Best,
Johnathan Mo
Columbia University | CS | prev. Google, incoming SIG
linkedin.com/in/johnathan-mo
```

### Subject lines

- Sequence 1: "Quick question about your workflow" / "15 min chat -- real estate startup research" / "Quick question about {company short name}"
- Sequence 2: Keep `Re:` prefix for threading

## Filtering Strategy

**Broad RE filter** -- include anything that could relate to real estate:
- Company name keywords: `real estate`, `realty`, `property`, `brokerage` (context-dependent), `homes`, `REALTOR`, `escrow`, `title`, `mortgage`, `housing`, `rental`, `PadSplit`, `SkySlope`, `Respage`, `STRATAFOLIO`, `Spaceflow`, `Brokermint`
- Include RE-adjacent: property tax, property inspection, vacation rentals, RE education, RE coaching, modular homes, senior living, investment RE
- **Exclude clearly non-RE**: funeral homes, insurance, logistics, transportation, cleaning, landscaping, law firms, engineering, marketing, energy, schools, BPO, shipping, roofing

The script will have a `MANUAL_EXCLUDE` array for false positives and `MANUAL_INCLUDE` for missed companies. The dry-run phase shows the full list for review before any DB writes.

## Script Structure

**File:** `scripts/rewrite-re-to-interview.ts`

### Phase 1: DRY_RUN (default)
- Query + filter all RE drafts
- Print table: `[id] [first_name] [company] [current_subject] [seq#]`
- Print count + any borderline companies for review
- **No DB changes**

### Phase 2: PREVIEW (flag)
- Rewrite the first draft via Claude API
- Print full before/after comparison
- **No DB changes**

### Phase 3: EXECUTE (flag)  
- Loop through all filtered drafts
- Call Claude Haiku for each with rewrite prompt
- Update `subject`, `body_text`, `body_html` in DB
- 200ms delay between API calls
- Print summary: X updated, Y skipped, Z errors

### Claude Prompt Design
- System: You are rewriting cold emails from sales to user interview framing
- Include: current body_text, company name, company research, prospect job title
- Instruct: preserve company-specific facts, strip sales language, use interview template
- Output: JSON `{ subject, bodyText }` (script builds bodyHtml from bodyText)
- Constraints: keep booking link, use exact sign-off block, no em-dashes, under 120 words

## Key Files

| File | Role |
|------|------|
| `scripts/rewrite-re-to-interview.ts` | **New** - the migration script |
| `src/db/schema.ts` | Table definitions (emailDrafts fields) |
| `src/db/index.ts` | DB connection singleton |
| `scripts/draft-run-2026-03-28.ts` | Reference for `buildBodyHtml()` pattern |
| `scripts/followup-execute-2026-03-13.ts` | Reference for Anthropic SDK usage |
| `agent/company-brief.md` | Credentials info |

## Sign-Off Block

```
Book a time here: https://booking.akiflow.com/johnathan-m-0da1

Best,
Johnathan Mo
Columbia University | CS | prev. Google, incoming SIG
linkedin.com/in/johnathan-mo
```

## Verification

1. Run dry-run → review the list of targeted drafts (confirm no false positives like funeral homes)
2. Run preview → review one rewritten email for tone/quality
3. Execute → update all drafts
4. Spot-check 5-10 rewrites in the `/drafts` review queue UI
