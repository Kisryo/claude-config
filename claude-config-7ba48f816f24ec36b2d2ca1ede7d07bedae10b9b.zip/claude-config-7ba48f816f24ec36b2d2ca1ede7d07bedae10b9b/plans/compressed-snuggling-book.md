# Form fill-out is broken — diagnosis and fix

## Context

In the `/forms` editor, the **Share** button copies a localhost URL. Opening that URL in incognito lands on the FinDash root landing page, not the form. Anonymous form filling does not work end-to-end. Goal: identify the actual breakage and pick a fix.

## Root cause

There are two distinct bugs that interact:

### 1. Share URL falls back to the editor (private) route

`EmbedShareModal.buildLinkUrl()` (`src/components/forms/EmbedShareModal.jsx:19-24`) decides between two URL shapes:

```js
if (orgSlug) return `${base}/firm/${orgSlug}/onboarding/${formId}`;
return `${base}/forms/${formId}`;
```

`orgSlug` comes from `firmPageSlug || slug` on the org doc (`src/hooks/useOrgForms.js:48`). For a brand-new firm that hasn't visited `FirmSettingsPage`, this is `null` and the share URL falls back to `/forms/{formId}` — **which is the editor route protected by `<PrivateRoute>` (`src/App.jsx:1556-1567`)**. In incognito, `PrivateRoute` redirects to `/`, which is `RootLandingRedirect`. That is the "lands on the FinDash landing page" symptom.

### 2. Even with a valid public URL, the form doesn't open

The only public form-fill surface is `/firm/:firmSlug/onboarding/:flowId` (`src/App.jsx:1507`, served by `FirmLandingPage`). Filling a form there is gated by:

- The form's `enabled !== false` (`src/components/FirmLandingPage.jsx:849-862`). New forms are created `enabled: false` (`src/services/formManagementService.js:54, 109`), so the firm landing page treats them as if they don't exist.
- `settings.allowPreSignupQuiz` being `true` (`src/components/FirmLandingPage.jsx:882-893`).
- A `firmPages` doc with `active: true` for the slug — otherwise `setError('No firm identifier provided')` renders a "Page Not Found" with a "Go to FinDash Home" button (`src/components/FirmLandingPage.jsx:1647-1656`) — the second incarnation of "lands on the landing page."
- A CTA click. The URL alone does not auto-open the form. The single call site setting `setShowPreSignupQuiz(true)` is `src/components/FirmLandingPage.jsx:972`, wired to `handlePreSignupQuiz` — never to the `flowId` URL param.

### Not the cause

- `firebase.json:681` rewriting `/firm/**` → `/private-noindex.html` is fine. That HTML is the SPA shell with `noindex` meta and loads `/src/main.jsx` (`private-noindex.html:48-59`) — the router still resolves the path. Vite dev does not run Firebase Hosting in front of it locally.
- Firestore rules are fine. `publicFirmProfiles` is publicly readable (`firestore.rules:3093`); `firmPages` is publicly readable (`firestore.rules:618`). Submissions go through the `createLeadFromGuestQuiz` callable (`functions/src/index.ts:2421`), and `guestFormSubmissions` is correctly locked to server writes (`firestore.rules:1612`).
- The service-worker `navigateFallbackDenylist` already exempts `/firm/**/onboarding` (`vite.config.js:42-43, 70`).

## Fix (locked decisions)

The share URL stays canonical: `/firm/{slug}/onboarding/{formId}`. The reader keeps the firm-branded wrapper. Three coordinated changes:

### A. Auto-provision firmPageSlug + firmPages doc on first share

When the user clicks **Share** in the form editor and the org has no `firmPageSlug`:

1. Generate a slug from `organization.name` (slugify, lowercase, hyphens).
2. Probe `firmPages` collection for collisions — append a short suffix if taken.
3. Persist `firmPageSlug` on the org doc (`organizations/{orgId}`).
4. Create a `firmPages` doc with `{ slug, organizationId, active: true, createdAt, updatedAt }`. Mirror the minimal shape used today in `src/components/FirmSettingsPage.jsx:1850-1857`.
5. Open the share modal only after provisioning resolves; show a brief loading state.

This is idempotent — re-clicking Share on an already-provisioned org skips straight to step 5.

### B. Default new forms to `enabled: true`

Cut the `enabled: false` default (`src/services/formManagementService.js:54, 109`). A form created in the editor is implicitly meant to be shareable; the `enabled` flag predates the editor and was a guard for the firm landing page's CTA carousel. With auto-open (next change) the carousel-ordering use case is gone for direct-share URLs. Form authors who want to *hide* a form can still toggle it off in settings; the default flips.

### C. Auto-open the form when URL contains a flowId

In `FirmLandingPage` (`src/components/FirmLandingPage.jsx`), add a `useEffect` that fires `setShowPreSignupQuiz(true)` once these are all true:

- `flowId` is present in URL params.
- `flowRouteResolved` is `true` and `selectedOrgFlow` is non-null (the flow exists and is `enabled !== false`).
- `!user` (skip auto-open for authenticated firm admins previewing).
- `!hasReachedLimit` and `!error`.

Bypass the `isPreSignupQuizEnabled()` / `allowPreSignupQuiz` gate for the URL-driven path. A share URL means "open this form now" — that gate exists for the firm landing CTA carousel, not for direct deep links.

## Files to modify

- `src/services/formManagementService.js` — flip `enabled: false` → `enabled: true` on lines 54 and 109. Also touch line 99 if it appears in `createFormFromTemplate`'s flow object (verify on read).
- `src/components/forms/editor/EditorHeader.jsx` — make the Share onClick `async`. Before `setShareOpen(true)`, call a new `ensureFirmPageProvisioned({ organizationId, organizationName })` helper. Disable the button while pending.
- `src/components/forms/EmbedShareModal.jsx` — small: reread `orgSlug` from props every render (no behavior change to `buildLinkUrl` — once provisioning runs, `orgSlug` is always populated and the existing happy path takes over).
- `src/services/firmPageProvisioning.js` (new) — `ensureFirmPageProvisioned({ organizationId, organizationName })`. Reuses Firestore SDK already imported in the editor pages. Models on the existing creation logic in `src/components/FirmSettingsPage.jsx:1850-1857` to keep the doc shape consistent.
- `src/components/FirmLandingPage.jsx` — add the auto-open `useEffect` after the existing flow-resolution effects (around line 411-430 region for placement; new effect listens on `flowId, flowRouteResolved, selectedOrgFlow?.id, user, hasReachedLimit, error`).
- `src/pages/FormEditor/FormEditorLayout.jsx` — pass `organizationName` to `EditorHeader` so the provisioning call has it. Read it from the `useAuth` / `useOrgForms` data already in scope.

## Reused existing helpers

- `src/utils/firmUrlGenerator.js:158-169` — `generateAllFirmUrlVariants` already supports flowId-suffixed URLs and falls back to firmPage doc id when slug is missing. Worth using inside `EmbedShareModal` instead of the inline `buildLinkUrl` once provisioning lands, so URL shape stays consistent with the rest of the app's share surfaces.
- `src/components/FirmSettingsPage.jsx:1810-1857` — the firmPage default-doc creation pattern is the model for the new provisioning helper.
- `src/services/formManagementService.js` — already exposes `mutateFlows` and form helpers; no new infrastructure needed for the `enabled` default flip.

## Verification

1. **Local dev path:** start `npm run dev`. Sign in as a firm admin whose org has no `firmPageSlug` (or clear it on the org doc via the emulator). Open `/forms`, create a new form, hit **Share**. Confirm the modal shows a `/firm/{newly-generated-slug}/onboarding/{formId}` URL — not `/forms/{formId}`. Confirm `organizations/{orgId}.firmPageSlug` and `firmPages/{newSlug}` (with `active: true`) now exist in Firestore.
2. **Anonymous read path:** copy the URL, open in an incognito window. The form should auto-open over the firm landing chrome — no clicks required. Submit the form. Confirm the FormResponses tab in the editor (`/forms/{formId}/responses`) shows the new entry within ~10s.
3. **Edge cases:**
   - Re-click Share on the same form → no duplicate provisioning, URL stable.
   - Form with `enabled: false` (manually toggled off in settings) → URL still resolves, but `selectedOrgFlow` is null, auto-open does not fire, FirmLandingPage falls back to firm marketing chrome.
   - Authenticated user visits the share URL → auto-open is skipped, they see the firm landing page.
4. **Regression check:** existing share surface in `OnboardingFlowManager` (`src/components/OnboardingFlowManager.jsx:3595`) and `FirstActionStep` (`src/pages/Onboarding/FirstActionStep.jsx:89`) still produce working URLs — they pass `linkUrl`/`embedUrl` overrides and don't depend on the fallback branch, so they're unaffected.
