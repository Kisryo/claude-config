# PDF + DOCX citation preview card

## Context

Citation chips in the chat render as interactive pills for every `[[cite: ...]]` the agent emits. Today the hover popover (`src/components/CitationChip.tsx` — `PreviewCard`) renders:
- **.txt / .md**: the full file text is fetched (via the Rust `read_file_preview` IPC added last session), the quoted passage is located, and the surrounding ±6 lines are shown with the quote highlighted. Works well.
- **.pdf / .docx / .xlsx / .pptx**: the file is in `BINARY_EXTS`, the loader short-circuits, and the card shows either the quoted text (if the agent supplied one) or a "Click the chip to open in the system viewer" CTA. Dead end.

The user cites a lease PDF or an interview docx far more often than a markdown file. The current hover is worthless for the common case, and "open in system viewer" breaks the inline-verification UX that citations were built for.

This plan ships rendered-content previews for pdf and docx. User picked `react-pdf` + `docx-preview` after landscape check (my first recommendation of "Python text extraction" was rightly rejected — see `~/.gstack/projects/23jmo-local-cowork/ceo-plans/2026-04-13-pdf-docx-preview-card.md`).

## Goal

Hovering a pdf or docx citation chip shows the actual rendered cited page inline, with the quoted text highlighted where possible. No Python shellout, no external viewer, no page reload. Under SELECTIVE EXPANSION: core + 4 accepted cherry-picks (lazy-load, console-only error logging, text-layer highlight, copy-quote). xlsx, pptx, and chip-level mini thumbnails explicitly deferred.

## Architecture

```
                       ┌──────────────────────────────────────┐
                       │  CitationChip.tsx (hover popover)    │
                       └──────────────┬───────────────────────┘
                                      │
               ┌──────────────────────┼─────────────────────────┐
               │                      │                         │
         ext = txt/md            ext = pdf                 ext = docx
               │                      │                         │
               ▼                      ▼                         ▼
    read_file_preview      read_file_bytes  (NEW)    read_file_bytes  (NEW)
      (existing, text)    path, max=20MiB → Vec<u8>   path, max=20MiB → Vec<u8>
               │                      │                         │
               ▼                      ▼                         ▼
      extractContext            <PdfPreview/>              <DocxPreview/>
      highlight+show             (LAZY IMPORT)             (LAZY IMPORT)
                            react-pdf Document+Page    docx-preview renderAsync
                            text-layer highlight         → sanitized HTML
                            overlay                     → DOMPurify first
                                                        → container mounted
                                                        → find+scroll+<mark>
```

## Plan

### 1. Rust — new IPC `read_file_bytes`

`src-tauri/src/commands.rs`, parallel to existing `read_file_preview`. Signature:

```rust
#[command]
pub fn read_file_bytes(path: String, max_bytes: Option<u64>) -> Result<Vec<u8>, CommandError>
```

- `~` expansion identical to `read_file_preview` (share a helper — new `fn expand_home(path: &str) -> Result<PathBuf, CommandError>` to DRY both commands).
- Default cap: 20 MiB. Hard cap: 50 MiB. Above hard cap → `Err("File too large for preview: {N} bytes")`. Between default and hard → truncate to default.
- `std::fs::metadata` → reject non-files (symlinks to non-files, dirs).
- Register in `src-tauri/src/lib.rs` `generate_handler![]` next to `read_file_preview`.
- Tauri's IPC serialization handles `Vec<u8>` as array of numbers in JSON — works but wasteful. Prefer: use `tauri::ipc::Response::new(bytes)` or accept the JSON encoding cost (20MB array → ~80MB JSON). For MVP: JSON encoding is acceptable since typical cited docs are 1-5 MB. Flag for optimization if profiling shows hover latency spikes.

### 2. Frontend — file byte loader

`src/components/CitationChip.tsx` — add loader mirroring `loadFileContent`:

```ts
async function loadFileBytes(path: string): Promise<Uint8Array | null> {
  if (bytesCache.has(path)) return bytesCache.get(path)!;
  if (!isTauri()) return null;
  try {
    const { invoke } = await import("@tauri-apps/api/core");
    const bytes = await invoke<number[]>("read_file_bytes", { path });
    const arr = new Uint8Array(bytes);
    bytesCache.set(path, arr);
    return arr;
  } catch (err) {
    console.warn(`[CitationChip] failed to read bytes for ${path}:`, err);
    return null;
  }
}
```

Module-level `bytesCache: Map<string, Uint8Array>` alongside existing `fileCache`. Cache by path only — we'll consider mtime invalidation in v2. Bound to an 8-entry LRU per Section 1 finding.

### 3. Frontend — `<PdfPreview />` component (new file)

`src/components/PdfPreview.tsx`:

```ts
// Dynamically import react-pdf INSIDE this file (lazy) so the parent
// PreviewCard bundle stays flat.
const { Document, Page, pdfjs } = await import("react-pdf");
// PDF.js worker: use Vite's module URL resolution. Fallback is to copy
// pdf.worker.min.mjs to public/ and set workerSrc = "/pdf.worker.min.mjs".
pdfjs.GlobalWorkerOptions.workerSrc = new URL(
  "pdfjs-dist/build/pdf.worker.min.mjs",
  import.meta.url,
).toString();
```

Props: `bytes: Uint8Array`, `pageNumber: number | null` (default 1 if missing), `quotedText: string`, `onError?: (e: Error) => void`.

Renders `<Document file={{ data: bytes }} onLoadError={onError}>` + `<Page pageNumber={page} width={360} renderTextLayer={true} onRenderSuccess={highlightQuote} />`.

`highlightQuote` queries `.react-pdf__Page__textContent span` elements, concatenates their textContent, finds the quote via `indexOf` (fall back to fuzzy prefix match, same 80-char logic used in `extractContext`), computes bounding box from matching spans, overlays an absolute-positioned highlight div inside the page container.

Wrap the whole thing in `<React.Suspense fallback={<LoadingState />}>` + a top-level Error Boundary that calls `console.warn` and renders the existing "click to open" CTA.

### 4. Frontend — `<DocxPreview />` component (new file)

`src/components/DocxPreview.tsx`:

```ts
const [{ renderAsync }, { default: DOMPurify }] = await Promise.all([
  import("docx-preview"),
  import("dompurify"),
]);
```

Props: same shape as PdfPreview minus `pageNumber`.

Flow:
1. Create a detached `<div>` as render target.
2. `await renderAsync(bytes, tempDiv, null, { inWrapper: false, ignoreFonts: true, ignoreLastRenderedPageBreak: true })`.
3. Sanitize the detached div's markup via DOMPurify with a strict policy (`FORBID_TAGS: ["script", "iframe", "object", "embed", "form"]`, `FORBID_ATTR: ["onerror", "onload", "onclick", ...]`). Use `DOMPurify.sanitize(tempDiv)` passing the element directly, which replaces mutation-safe assignment with sanitized node appends.
4. Move sanitized children into the visible container via `container.replaceChildren(...sanitized.childNodes)`.
5. For highlight: `findQuoteAndMark(containerRef.current, quotedText)` — `document.createTreeWalker` for TEXT_NODE, accumulate textContent, find quote offset, wrap the matching Range with a `<mark>`, scrollIntoView({ block: "center" }).

**SECURITY:** This is the critical path. `csp: null` in `tauri.conf.json` means zero defense-in-depth. The DOMPurify step is not optional — it's the whole moat against a malicious .docx dropping a `<script>` into IPC-powered JavaScript. Passing the element (not a string) keeps the round-trip inside the DOM rather than re-parsing, removing one class of parser-confusion bugs.

### 5. Frontend — wire into PreviewCard

`src/components/CitationChip.tsx` `PreviewCard`:

```ts
const ext = fileExt(sourceFile);
const isPdf = ext === "pdf";
const isDocx = ext === "docx";
const isInlineRenderable = isPdf || isDocx;
```

Remove the `if (isBinary) { setLoading(false); return; }` short-circuit for pdf/docx. Replace with a branch: if `isInlineRenderable`, load bytes via `loadFileBytes` and render `<PdfPreview />` or `<DocxPreview />` inside the body slot. Other binary exts (xlsx, pptx, png, etc.) keep the existing CTA path.

Loading state: reuse the existing "Loading preview…" pulse.

### 6. Dependencies

```bash
npm install react-pdf dompurify docx-preview
npm install --save-dev @types/dompurify
# react-pdf bundles pdfjs-dist so no separate install needed
```

Expected size impact (gzipped): react-pdf ~150KB + pdfjs-dist ~400KB + docx-preview ~200KB + dompurify ~25KB = ~775KB. All lazy-loaded — initial bundle unchanged, first preview hover pays it.

### 7. Error handling (console-only, per user direction)

Every failure path calls `console.warn` with:
- Component name: `[PdfPreview]` or `[DocxPreview]`
- Source path
- Error class + message

No user-visible error UI. If rendering fails, the card falls back to the existing "Click chip to open in system viewer" CTA. User-tested recovery: click-through always works.

Specific cases to handle by name (not `catch (e)`):
| Component | Error class | When | Fallback |
|-----------|-------------|------|----------|
| PdfPreview | `PasswordException` (from pdf.js) | Encrypted PDF | CTA fallback, console.warn "password-protected" |
| PdfPreview | `InvalidPDFException` | Corrupt header | CTA fallback |
| PdfPreview | `MissingPDFException` | File gone mid-read | CTA fallback |
| DocxPreview | Thrown from `renderAsync` (various) | Corrupt/non-docx zip | CTA fallback |
| Both | `read_file_bytes` rejection | Path validation, size cap, missing file | CTA fallback |
| Both | File size > 50 MiB hard cap | Rust returns error | CTA fallback, console.warn "too large" |

## Critical files

- `src-tauri/src/commands.rs` — add `read_file_bytes` + `expand_home` helper (refactor `read_file_preview` to use it, keeping behavior identical)
- `src-tauri/src/lib.rs` — register `read_file_bytes` in `generate_handler![]`
- `src/components/PdfPreview.tsx` — **new**, lazy-loaded
- `src/components/DocxPreview.tsx` — **new**, lazy-loaded
- `src/components/CitationChip.tsx` — extend `PreviewCard` to branch pdf/docx into new components; add `loadFileBytes` loader + `bytesCache`
- `package.json` — add react-pdf, dompurify, docx-preview, @types/dompurify
- `vite.config.ts` — verify no worker/wasm config changes needed. If pdf.js worker fails to resolve, copy `node_modules/pdfjs-dist/build/pdf.worker.min.mjs` to `public/` and set `workerSrc = "/pdf.worker.min.mjs"` as fallback.

## Review Sections

### Section 1: Architecture
- New components `<PdfPreview />` and `<DocxPreview />` are isolated — no cross-component coupling beyond PreviewCard composition. Good.
- Coupling added: `CitationChip → PdfPreview/DocxPreview → react-pdf/docx-preview → pdfjs-dist`. Acceptable — lazy-loaded, upstream-stable libs.
- New Rust command is a clean sibling of `read_file_preview`. No new state machines.
- Dependency graph is a simple tree. No circular imports.
- **Scaling:** At 100x load (very large PDF, hundreds of chips in one message): pdf.js workers are per-Document instance, cached internally. Memory concern is the Uint8Array bytes cache — capped entries at ~20MB each, module-level Map grows unbounded. **Finding:** add an LRU bound of 8 entries on `bytesCache` (evict least-recently-used). 20MB × 8 = 160MB worst-case is tolerable; without eviction, long sessions could leak.
- **SPOF:** pdf.js worker script fails to load → every PDF preview breaks. Fallback: copy worker to `public/`.
- **Rollback:** Pure frontend + one new Rust IPC. Revert the commit, delete node_modules, rebuild. Zero data migration. Rollback time: minutes.

### Section 2: Error & Rescue Map

| Codepath | What can go wrong | Exception class | Rescued? | Rescue action | User sees |
|----------|-------------------|-----------------|----------|---------------|-----------|
| `read_file_bytes` | Path doesn't exist | `std::io::Error` via `metadata` | Y | CommandError returned | CTA fallback |
| `read_file_bytes` | Not a regular file | (synthetic) | Y | CommandError returned | CTA fallback |
| `read_file_bytes` | File > 50MiB | (synthetic) | Y | CommandError "too large" | CTA fallback |
| `read_file_bytes` | I/O error mid-read | `std::io::Error` | Y | CommandError returned | CTA fallback |
| `loadFileBytes` | IPC rejection | JS Error | Y | `console.warn` + `null` return | CTA fallback |
| `PdfPreview` Document load | Password-protected | `PasswordException` | Y | `onLoadError` → console.warn "encrypted" | CTA fallback |
| `PdfPreview` Document load | Corrupt/invalid | `InvalidPDFException` | Y | `onLoadError` → console.warn "invalid" | CTA fallback |
| `PdfPreview` Page render | Page number > page count | (pdf.js internal) | Y | React error boundary | CTA fallback |
| `PdfPreview` worker | Worker script 404 | (pdf.js internal) | Y | Document `onLoadError` | CTA fallback |
| `PdfPreview` highlight | Text layer not ready when highlight runs | (TypeError on null) | Y | `onRenderSuccess` callback gates it | No highlight, page still shown |
| `DocxPreview` | `renderAsync` throws (bad zip) | Various | Y | try/catch → console.warn | CTA fallback |
| `DocxPreview` | DOMPurify strips everything | (empty sanitized tree) | N | — | Empty card ← **FINDING** |
| `DocxPreview` | Highlight text not found | (indexOf = -1) | Y | Skip highlight, render plain | Content shown, no highlight |
| `DocxPreview` | Highlight spans multiple runs | Range setStart on wrong node | Y | try/catch → render plain | Content shown, no highlight |

**CRITICAL GAP (S2.1):** If DOMPurify strips all content (pathological hostile docx), `<DocxPreview />` mounts empty. Fix: detect `sanitized.textContent.trim() === ""`, console.warn "sanitization removed all content," fall back to CTA.

### Section 3: Security & Threat Model

**Threat 1 — Malicious .docx executes JS in webview (HIGH severity).** Attacker convinces user to attach a hostile .docx to a task. Agent cites it. User hovers citation. docx-preview produces a DOM containing `<script>` or `<img onerror=...>`. Without defense, those nodes execute in the webview context, which has full Tauri IPC access. From there: read arbitrary files via `read_file_bytes`, write via agent tools, exfiltrate via `fetch`.

Mitigation: DOMPurify with `FORBID_TAGS: [script, iframe, object, embed, form]` + `FORBID_ATTR: [onerror, onload, onclick, ...]`. OWASP-standard, Cure53-maintained. Critically: pass the DOM element (not a string) to `DOMPurify.sanitize` so the sanitizer walks the live tree rather than re-parsing — removes one class of parser-confusion bugs.

Tauri CSP is `null` (verified in `tauri.conf.json`) — no defense-in-depth. DOMPurify is the only line. **Do not skip. Do not unit-test-mock out.**

Residual risk: DOMPurify CVE. Mitigation: keep the lib on its latest minor version; subscribe to advisories.

**Threat 2 — Path traversal via `read_file_bytes` (LOW severity).** The IPC takes an arbitrary path. A compromised frontend could enumerate the filesystem. But: the frontend is already trusted (it already has `read_file_preview`, `open_path`, and agent tools with broader reach). `read_file_bytes` doesn't expand the threat model — the frontend-compromise threat already exists. No additional mitigation needed beyond the existing architecture.

**Threat 3 — File size DoS (LOW severity).** Hovering a citation to a 10GB file would OOM the webview. Mitigation: 50MiB hard cap in `read_file_bytes`, rejected before allocation. The Rust side caps before reading into memory.

**Threat 4 — PDF.js CVEs (LOW severity).** pdf.js is a large C-like codebase; historical CVEs exist. Mitigation: react-pdf pins a recent pdfjs-dist; subscribe to Mozilla security advisories.

### Section 4: Data Flow & Interaction Edge Cases

**Data flow — PDF happy path:**
```
hover chip → load bytes → Uint8Array → <Document file={{data}}>
  → pdf.js parses → <Page number=N> → canvas render + text layer
  → onRenderSuccess → highlightQuote → find span → overlay rect
```

**Shadow paths:**
- nil path: `bytes === null` → fall to CTA (tested by "file missing" case)
- empty path: 0-byte PDF → pdf.js throws InvalidPDFException → CTA
- upstream error: IPC rejection → null → CTA

**Interaction edge cases:**
| Interaction | Edge case | Handled? | How |
|-------------|-----------|----------|-----|
| Hover chip | User navigates away mid-render | Y | Existing `cancelled` flag in useEffect cleanup |
| Hover chip | Page number in cite > actual page count | Partial | pdf.js error → caught by error boundary → CTA. **Finding:** could silently render page 1 instead as fallback. |
| Hover chip | Quote not found on rendered page | Y | Skip highlight, still render page |
| Hover chip | Quote crosses PDF text-span boundaries | Partial | Exact indexOf fails, fuzzy prefix fallback handles it partially. Spanning > 80 chars and crossing spans: unhandled, falls through silently. |
| Hover chip | Same file, multiple citations in one message | Y | `bytesCache` returns same Uint8Array instance, pdf.js internally caches Document |
| Hover chip | Hover repeatedly (mouseenter/leave spam) | Y | Existing `clearDismiss` + 300ms debounce |
| Copy-quote | Clipboard API unavailable (edge case) | N | **Finding:** wrap in try/catch, console.warn, silent no-op |

**Finding (S4.1):** page-number-out-of-bounds should silently render page 1 instead of CTA fallback. User intent is "show me this document," and page 1 is better than nothing.

### Section 5: Code Quality

- Two new components, clear single responsibility each.
- `expand_home` helper DRYs the `~` expansion logic (currently in `read_file_preview`, about to be duplicated in `read_file_bytes` if not extracted).
- No new abstractions beyond the components themselves. No provider, no context, no hook beyond what's needed.
- **Cyclomatic complexity check:** `highlightQuote` is the most branchy function (span iteration + fuzzy fallback + bbox math). Keep under 8 branches or split into `findSpans` + `drawOverlay`.
- No `catch (e)` catch-alls. Every handler names the exception.

### Section 6: Tests

No test suite exists in this repo (per CLAUDE.md). Verification is by CI gates (tsc, cargo check, cargo clippy) + manual smoke test.

If we were testing:
- **Unit:** `expand_home(~/foo)` → expanded path; `read_file_bytes` with oversize file → error.
- **Integration:** Render `<PdfPreview bytes={fixturePdf} quotedText="foo" />`, assert text layer rendered + highlight span present.
- **Security:** Render `<DocxPreview bytes={hostileDocx} />` where hostileDocx contains `<script>`, assert no `<script>` in the rendered DOM.
- **The 2am test:** Hover a 500-page contract with a cite to page 347. Should render page 347 with the quote highlighted, not freeze the webview.

### Section 7: Performance

- **First-hover latency:** ~300ms = ~100ms IPC + ~150ms pdf.js worker spin + ~50ms render. Acceptable for a hover card with a 300ms dismiss debounce already in place.
- **Subsequent hovers same file:** ~20ms (bytesCache + pdf.js Document cache).
- **Memory:** Bounded `bytesCache` at 8 × 20MiB = 160MB worst case (with LRU eviction per S1 finding). Without bounding, unbounded leak over session.
- **N+1:** None — bytesCache dedupes per path.
- **No DB queries added.**

### Section 8: Observability

- Every failure path calls `console.warn("[PdfPreview] ...", err)` or `[DocxPreview]`.
- Log taxonomy: `[PdfPreview] failed to load`, `[PdfPreview] password-protected`, `[PdfPreview] page out of bounds`, `[DocxPreview] render failed`, `[DocxPreview] sanitization removed all content`, `[CitationChip] failed to read bytes`.
- No metrics, no alerts — this is a client-side feature, there's no telemetry channel in the app today. If one is added later, preview failure rate would be worth tracking.
- **Debuggability:** Logged errors include path + exception class + native message. Enough to reproduce in a dev session.

### Section 9: Deployment & Rollout

- Pure feature addition. No DB migration. No flags.
- `npm install` picks up new deps at `tauri:dev` / `tauri:build`.
- Deploy risk window: none — old code and new code coexisting means old users see the old CTA, new users see the new preview. No protocol change.
- Rollback: revert the commit. `~/.local/share/kuse-cowork` data unaffected.
- Post-deploy verification: open a task with a pdf citation and a docx citation, hover each, confirm rendered preview + quote highlight.

### Section 10: Long-Term Trajectory

- Debt introduced: minimal. Two new components, one new IPC, three new deps.
- Path dependency: the `loadFileBytes` + `read_file_bytes` pair is reusable for xlsx/pptx preview in v2. Future-compatible.
- **Adjacent risk (not this plan's debt):** `src/components/MarkdownMessage.tsx` has six module-level `CITATION_*_G` regexes with the `/g` flag. Prior learning logged April 13 flagged this as a React 18 concurrent-mode landmine (shared `lastIndex`). This plan doesn't touch those regexes, but any future citation-pipeline work should fix them. Adding to TODOS.md as a separate item.
- Reversibility: 5/5. Trivially revertable.
- 1-year question: a new engineer reading `PdfPreview.tsx` sees a dynamic import, a react-pdf component, a highlight function. Obvious.

### Section 11: Design & UX

This plan has UI scope (new visual element in the hover card). Evaluation:

- Information hierarchy: header (filename + page/section) → rendered page → footer ("Click chip to open"). Correct — filename first, content second, affordance last.
- States covered:
  | State | LOADING | EMPTY | ERROR | SUCCESS |
  |-------|---------|-------|-------|---------|
  | PdfPreview | "Loading preview…" pulse | (0-page pdf = error) | silent fallback to CTA | rendered page + highlight |
  | DocxPreview | "Loading preview…" pulse | empty docx → sanitization-empty fallback to CTA | silent fallback to CTA | rendered content + highlight |
- AI-slop risk: low — this isn't a generic UI pattern, it's a specific citation-preview artifact.
- Responsive: the popover is fixed-width (380px) per existing CitationChip styling. Rendered page scaled to 360px width. Good.
- Accessibility: the chip is already `role="button"` + keyboard-activated. The popover is hover-only — no keyboard entry into the rendered preview (deferred). Rendered pdf pages are `<canvas>` → not screen-reader friendly; the text layer provides accessible text. Acceptable for MVP.

Recommendation: run `/plan-design-review` before implementation if you want a visual pass on the loading/failure states. Not required.

## NOT in scope

- **xlsx preview** — different library (luckyexcel), separate effort. TODOS.md.
- **pptx preview** — different library (pptx renders via LibreOffice thumbnail or dedicated viewer), separate effort. TODOS.md.
- **Chip-level mini thumbnail** — 24x32 thumbnail rendered inside the chip itself, not the hover card. Perf risk with dense chat transcripts. TODOS.md.
- **Keyboard navigation inside preview** — page-flip via arrow keys. Complex interaction model for a hover popover.
- **Visible UI error states** — user explicitly chose console-only logging. Chip-click fallback is the recovery path.
- **Fix for module-level `/g` regexes in MarkdownMessage.tsx** — known landmine from prior learning; adjacent but not in this PR's scope. TODOS.md.
- **`read_file_bytes` mtime-based cache invalidation** — v2. Today's cache is path-keyed; if a user replaces a file during a session and hovers the same cite, they see stale bytes until app restart. Edge case.
- **Binary transport optimization for IPC** — `Vec<u8>` over JSON is wasteful for large files. Optimize if profiling shows hover latency spikes.

## What already exists

- `PreviewCard` 4-tier body logic (CitationChip.tsx:160–215) — reusable; pdf/docx just populate a new body tier.
- `read_file_preview` IPC + `~` expansion helper — `read_file_bytes` is a sibling; extract common `expand_home`.
- `fileCache` module-level Map + `loadFileContent` — `bytesCache` + `loadFileBytes` mirror the shape.
- `extractContext` + `splitContext` fuzzy-match logic — reused philosophically in `findQuoteAndMark` for docx.
- `BINARY_EXTS` Set — updated to leave pdf/docx out (they're now inline-renderable, not bottom-out-to-CTA).
- Hover dismiss debounce (300ms) + mouseenter/leave bridge — no changes.

## Dream state delta

```
CURRENT STATE                      THIS PLAN                        12-MONTH IDEAL
────────────────                   ─────────                        ──────────────
txt/md: inline text excerpt   →   txt/md: unchanged                 every file type:
pdf/docx: CTA only            →   pdf/docx: rendered page +         inline rendered
xlsx/pptx: CTA only           →   xlsx/pptx: unchanged (v2)         preview with
                                                                    quote highlight
                                                                    and hybrid
                                                                    text-search mode
```

This plan advances the pdf+docx cases by the full delta. xlsx and pptx are the remaining gaps; they sit in TODOS.md.

## Error & Rescue Registry

See Section 2 table. **CRITICAL GAPS:** 1 (S2.1 — DOMPurify-empty output).

## Failure Modes Registry

```
  CODEPATH                   | FAILURE MODE          | RESCUED? | TEST? | USER SEES?      | LOGGED?
  ---------------------------|-----------------------|----------|-------|-----------------|--------
  read_file_bytes            | oversize file         | Y        | N/A   | CTA fallback    | Rust
  read_file_bytes            | missing file          | Y        | N/A   | CTA fallback    | Rust
  PdfPreview Document        | password-protected    | Y        | N/A   | CTA fallback    | console
  PdfPreview Document        | corrupt/invalid PDF   | Y        | N/A   | CTA fallback    | console
  PdfPreview Page            | page > count          | PARTIAL  | N/A   | CTA (finding)   | console
  PdfPreview highlight       | quote not in text     | Y        | N/A   | page w/o hl     | no log
  DocxPreview renderAsync    | corrupt docx          | Y        | N/A   | CTA fallback    | console
  DocxPreview sanitize       | all content stripped  | N←GAP    | N/A   | empty card ←BAD | no log
  DocxPreview highlight      | quote spans runs      | PARTIAL  | N/A   | no hl, plain    | no log
  CopyQuote                  | clipboard unavail     | N←GAP    | N/A   | nothing happens | no log
```

**CRITICAL GAPS to fix before merge:**
1. `DocxPreview sanitize` empty-output → add textContent length check, CTA fallback, console.warn.
2. `CopyQuote` clipboard unavailable → try/catch, console.warn.

**Finding to address:**
3. `PdfPreview Page` out-of-bounds → silently render page 1 instead of CTA.

## TODOS.md updates (proposed)

Each would be a separate item:
1. **xlsx inline preview** (P2, M effort) — luckyexcel or similar, extend PreviewCard path. Depends on: this PR shipping.
2. **pptx inline preview** (P2, M effort) — LibreOffice thumbnail or dedicated viewer. Depends on: this PR shipping.
3. **Chip-level mini thumbnail** (P3, S effort) — 24x32 preview in the chip itself, perf test with many chips first.
4. **MarkdownMessage.tsx `/g` regex leak** (P1, S effort) — prior learning, React 18 concurrent-mode landmine. Move regexes to per-call `new RegExp` or `matchAll`.
5. **`read_file_bytes` mtime invalidation** (P3, S effort) — invalidate bytesCache when file mtime changes.
6. **IPC binary transport optimization** (P3, S effort) — only if profiling shows hover-latency spikes on large files.

## Diagrams

System architecture diagram: see "Architecture" section above.

Data flow diagram (pdf happy path):
```
Chip hover → loadFileBytes(path) → IPC read_file_bytes → Vec<u8>
           → Uint8Array → <Document file={{data}}>
           → pdf.js worker parse → <Page number=N>
           → canvas render + text layer
           → onRenderSuccess → highlightQuote
           → find matching span → overlay div
```

State machine: PreviewCard states:
```
     idle ──(hover)──▶ loading ──(bytes ok)──▶ rendering ──(ok)──▶ shown
                          │                         │
                          │(bytes err)              │(render err)
                          ▼                         ▼
                        cta                       cta
```

Rollback flowchart: trivial — `git revert <commit>`, `npm install`, rebuild. No data.

## Stale Diagram Audit

No existing ASCII diagrams in touched files (`CitationChip.tsx`, `commands.rs`, `lib.rs`, `MarkdownMessage.tsx`). Nothing to audit.

## Verification

### CI gates (required):
```bash
npx tsc --noEmit                                   # TypeScript type check
cd src-tauri && cargo check                        # Rust compile
cd src-tauri && cargo clippy -- -D warnings        # Rust lints
```

### Smoke test (required):
1. `npm run tauri:dev`
2. Open a task with an attached .pdf and an attached .docx. Ask the agent a question that cites both.
3. Hover the pdf citation chip — confirm: filename + page header, rendered page at ~360px width, quote highlighted (orange box overlay on text layer).
4. Hover the docx citation chip — confirm: filename + section header, rendered content, quote marked and scrolled into view.
5. Click the chip — confirm system viewer still opens (regression check).
6. Hover a txt citation — confirm unchanged (regression check).
7. **Hostile-docx test:** craft a .docx whose XML body contains literal `<w:r><w:t>&lt;script&gt;alert('pwn')&lt;/script&gt;</w:t></w:r>`. Hover. Confirm no alert fires, content renders as literal text.
8. Open devtools console — confirm console.warn entries for any failed preview (force by renaming a cited file between task creation and hover).

### Adversarial test:
- Cite a 50MiB+ PDF → confirm card falls to CTA without OOM.
- Cite a 0-byte PDF → confirm CTA fallback with `[PdfPreview] invalid PDF` in console.
- Cite a password-protected PDF → confirm CTA fallback + `[PdfPreview] password-protected`.

## Completion Summary

```
+====================================================================+
|          MEGA PLAN REVIEW — COMPLETION SUMMARY                     |
+====================================================================+
| Mode selected         | SELECTIVE EXPANSION                         |
| System Audit          | 608 lines uncommitted on main, 3 stashes;   |
|                       | Python infra present but not needed; prior  |
|                       | regex landmine in MarkdownMessage.tsx flagged|
| Step 0                | Landscape check changed approach from       |
|                       | Python extraction → in-webview rendering    |
| Section 1  (Arch)     | 1 finding (bytesCache LRU bound)            |
| Section 2  (Errors)   | 14 paths mapped, 1 CRITICAL GAP (S2.1)       |
| Section 3  (Security) | 1 High (docx XSS via null CSP) → DOMPurify  |
|                       | mitigation is required, not optional         |
| Section 4  (Data/UX)  | 2 partial edges (page bounds, copy fallback)|
| Section 5  (Quality)  | expand_home DRY extraction recommended       |
| Section 6  (Tests)    | No test suite in repo; CI gates + manual     |
| Section 7  (Perf)     | OK, bound bytesCache                        |
| Section 8  (Observ)   | Console-only logging per user direction     |
| Section 9  (Deploy)   | Pure feature; trivial rollback               |
| Section 10 (Future)   | Reversibility 5/5; adjacent regex debt noted|
| Section 11 (Design)   | UI states mapped; /plan-design-review opt.  |
+--------------------------------------------------------------------+
| NOT in scope          | 8 items listed                               |
| What already exists   | 6 reuse points identified                    |
| Dream state delta     | pdf/docx gap closed; xlsx/pptx remain        |
| Error/rescue registry | 14 paths, 1 CRITICAL GAP                     |
| Failure modes         | 14 total, 2 CRITICAL GAPS                    |
| TODOS.md updates      | 6 items proposed                             |
| Scope proposals       | 4 proposed, 3 accepted, 1 modified, 1 def. |
| CEO plan              | written (~/.gstack/...ceo-plans/2026-04-13…)|
| Outside voice         | skipped (feature size; recommended later)    |
| Lake Score            | 7/8 (ticked complete options except visible |
|                       |  error UI, which user explicitly overrode)   |
| Diagrams produced     | 4 (architecture, data flow, state, rollback)|
| Stale diagrams found  | 0                                            |
| Unresolved decisions  | 0                                            |
+====================================================================+
```

## Unresolved Decisions

None — all open questions resolved in 0A/0C-bis/0D.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|--------|---------|-----|------|--------|----------|
| CEO Review | `/plan-ceo-review` | Scope & strategy | 1 | clean | SELECTIVE mode, 4 proposed / 3 accepted / 1 modified / 1 deferred |
| Codex Review | `/codex review` | Independent 2nd opinion | 0 | — | — |
| Eng Review | `/plan-eng-review` | Architecture & tests (required) | 0 | — | — |
| Design Review | `/plan-design-review` | UI/UX gaps | 0 | — | — |
| DX Review | `/plan-devex-review` | Developer experience gaps | 0 | — | — |

**UNRESOLVED:** 0

**VERDICT:** CEO CLEARED — run `/plan-eng-review` next (required shipping gate) before implementation.
