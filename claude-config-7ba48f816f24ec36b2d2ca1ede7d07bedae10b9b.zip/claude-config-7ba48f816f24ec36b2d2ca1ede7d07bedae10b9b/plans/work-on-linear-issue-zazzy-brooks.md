# FIN-2 — Default form templates

## Context

The `/forms` route today has a single "Create Form" button in the hero that calls `createBlankForm()` and opens the new form in a new tab. Users start from zero every time. This change introduces two pre-built templates — **Client Intake Form** and **Interest Form** — surfaced through a popover that anchors under the Create button, alongside a **Blank** card that preserves today's behavior. Goal: shorter time-to-first-value for advisors setting up intake/lead capture without adding any Firestore schema churn.

Linear: FIN-2. Branch: `jym2117/fin-2-add-default-templates-for-the-forms`. Base: `main`.

## Locked decisions (from interview)

| Area | Decision |
|---|---|
| Trigger UX | Anchored popover below the Create button (Headless UI `<PopoverPanel anchor>`) |
| Mobile (< 640px) | Bottom sheet — cards stack vertically |
| Template storage | Hardcoded JS constants in `src/data/formTemplates.js` (no Firestore changes) |
| Client Intake scope | **Standard** — 12 questions across Identity / Household / Financials / Goals |
| Interest Form scope | **Lean** — 5 questions |
| New form name | `${template.name} — Apr 24, 2026` (localized short date) |
| Post-create | Popover stays open with per-card spinner; closes on write success; new tab opens |
| Dismiss | ESC + click-outside. No arrow-key roving focus. No auto-close-before-write |
| Card anatomy | Image + title only. No description, no field count, no hover preview |
| Card imagery | Pre-generated 3D clay illustrations via Nano Banana (Gemini 2.5 Flash Image), committed as `.webp` |
| Popover chrome | No header, no close button — just the 3 cards |
| Empty-state CTA | Same popover anchors to it (reuse single component) |
| Out of scope | Analytics, "New" badge, user-saved templates, registry-style extensibility |

## Files

### Create

- `src/data/formTemplates.js` — exports `CLIENT_INTAKE_TEMPLATE`, `INTEREST_FORM_TEMPLATE`, `BLANK_TEMPLATE`, and a `TEMPLATES` array. Each template shape:
  ```js
  {
    id: 'client-intake',                 // stable slug
    name: 'Client Intake Form',          // used as base for the created form's name
    imageSrc: clientIntakeImg,           // imported .webp
    questions: [ /* question objects */ ] // applied to settings.customQuestions
  }
  ```
  Each question is built with `getDefaults(type)` from `src/components/forms/editor/questionTypes.js` and shaped `{ id, label, type, required, ...getDefaults(type) }`.

- `src/components/forms/CreateFormPopover.jsx` — Headless UI `<Popover>` + `<PopoverPanel anchor="bottom end">`. Children take a `trigger` render prop (so both `FormsPageHero` and the empty-state CTA can mount it). Handles:
  - Desktop: anchored panel, 3 cards in a row.
  - Mobile (`window.matchMedia('(max-width: 640px)')`): fixed bottom sheet, cards stacked.
  - Framer Motion transition: `initial={{ opacity: 0, y: -4, scale: 0.98 }}` → `animate={{ opacity: 1, y: 0, scale: 1 }}`, 180 ms `cubic-bezier(0.2, 0.8, 0.2, 1)` (matches DESIGN.md motion bracket).
  - Per-card `creatingId` state; disables other cards during write; shows spinner over the clicked card's image.
  - On success: close popover first, then `window.open(`/forms/${newId}`, '_blank', 'noopener')`.

- `src/assets/formTemplates/client-intake.webp`, `interest-form.webp`, `blank.webp` — 512×512 transparent-background 3D clay illustrations (see prompts below).

### Modify

- `src/services/formManagementService.js` — add `createFormFromTemplate({ organizationId, userId, userDisplayName, template })`. Mirrors `createBlankForm` (`mutateFlows` + `newFlowId` + `stampTime` — all reused unchanged) but:
  - `name` = ``${template.name} — ${new Intl.DateTimeFormat('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).format(new Date())}``
  - `settings.customQuestions` = `template.questions.map((q) => ({ ...q, id: newQuestionId() }))` (regenerate IDs so multiple instantiations don't collide)
  - Everything else identical to `createBlankForm` — `flowType: 'form'`, `enabled: false`, `isDefault: flows.length === 0`, same `DEFAULT_FORM_SETTINGS` spread.

- `src/components/forms/FormsPageHero.jsx` — wrap the existing `<button>` (lines 117–128) in `<CreateFormPopover>` as its trigger. Keep the gradient/teal styling, the PlusIcon, and the `creating` state semantics. The `onCreateForm` prop is replaced by a template-selection handler passed down from `FormsPage`.

- `src/pages/FormsPage.jsx` — replace the direct `createBlankForm` call site with a `handleTemplateSelect(template)` that invokes `template.id === 'blank' ? createBlankForm(...) : createFormFromTemplate({ ..., template })`, then opens the editor tab. If the page has an empty-state CTA, wrap it in `<CreateFormPopover>` with the same handler. (Inspect file before editing — confirm empty-state shape; if absent, only the hero is wired up.)

## Question content (source of truth)

### Client Intake Form — 12 questions

Identity
1. Full name — `full_name`, required
2. Email — `email`, required
3. Phone — `phone`, required
4. Date of birth — `date`, required
5. Mailing address — `address`

Household
6. Marital status — `dropdown` [Single, Married, Divorced, Widowed, Partnered]
7. Dependents — `number`

Financial snapshot
8. Employment status — `dropdown` [Employed, Self-employed, Retired, Unemployed, Student]
9. Annual income range — `dropdown` [Under $50k, $50k–$100k, $100k–$250k, $250k–$500k, $500k+]
10. Investable assets — `dropdown` [Under $100k, $100k–$500k, $500k–$1M, $1M–$5M, $5M+]
11. Risk tolerance — `rating`, scale 1–5

Goals
12. Primary goals — `checkbox` [Retirement, Tax strategy, Estate planning, College savings, Other]

### Interest Form — 5 questions

1. Full name — `full_name`, required
2. Email — `email`, required
3. Phone — `phone`, optional
4. What are you interested in? — `checkbox` [Retirement planning, Tax strategy, Estate planning, Investment management, Other]
5. Tell us more — `long_text`

### Blank

No seeded questions. Keeps calling `createBlankForm`.

## Image generation (Nano Banana prompts)

Base style — run once per image, enforce consistency across all three:

> Soft 3D clay illustration, pastel cream clay with muted deep-teal (#0F2D26) accents, smooth matte finish, subtle soft shadow, warm rim lighting, 3/4 angle, centered on transparent background, 512×512, no text, no logos.

Per-image subject:
- `client-intake.webp` — "clipboard with a pen resting on top, a single rounded checkmark visible on the paper"
- `interest-form.webp` — "sealed envelope with a small rounded heart icon on the flap, slightly tilted"
- `blank.webp` — "plus sign inside a rounded-square tile, lifted slightly off the surface"

Post-process: export `.webp` at quality 85, drop to `src/assets/formTemplates/`, import with Vite's static asset import.

## Verification

1. `npm run dev` — open `/forms`.
2. Click **Create Form** → popover anchors below button, 3 cards visible.
3. ESC → popover closes. Re-open. Click outside → closes.
4. Click **Client Intake** → spinner on that card, other cards disabled → popover closes on success → new tab opens → editor shows 12 questions in the right sections; title = `Client Intake Form — <today>`.
5. Click **Interest Form** → 5 questions; title = `Interest Form — <today>`.
6. Click **Blank** → identical to today: `Untitled form`, empty question list.
7. Shrink viewport < 640px → trigger popover → panel now a bottom sheet, cards stacked vertically; dismiss still works.
8. If `FormsPage` empty state has a CTA, repeat steps 2–6 from there.
9. `npm run lint` — zero warnings (eslint `--max-warnings 0` is enforced in this repo).
10. `npm run build` — clean build, images chunked correctly.

## Risks / watch-outs

- **Empty state unknown** — `FormsPage.jsx` empty state shape wasn't inspected yet. Inspect before wiring; if it hand-rolls its own CTA, factor the trigger into `CreateFormPopover`'s render-prop shape so both sites stay in sync.
- **`settings.customQuestions` vs `settings.defaultQuestions`** — template questions go into `customQuestions`. `defaultQuestions` is a separate, opinionated object for built-in onboarding prompts; do not touch it.
- **Question ID collisions** — template constants get fresh IDs per instantiation; don't share IDs between template and created form.
- **Logic tab is intentionally hidden** (per prior decision). Do not restore or reference it while editing FormsPage.
- **New-tab `window.open` + popup blockers** — the tab must open in direct response to the click handler, not after an `await`. Do the Firestore write first, then open inside a `.then()` handler synchronously from the user gesture is impossible — accept this is a known constraint of the current blank flow, and mirror exactly what `createBlankForm` does today (which already works because the blank write is fast and is followed by `window.open`). If popup blockers become an issue, a follow-up can open an `about:blank` tab synchronously and redirect it post-write.
