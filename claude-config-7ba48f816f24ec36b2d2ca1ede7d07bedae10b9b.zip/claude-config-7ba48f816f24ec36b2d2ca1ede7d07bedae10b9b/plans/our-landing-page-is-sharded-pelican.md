# Landing Page Fixes — argue-landing

## Context

The marketing page at `argue-landing.vercel.app` (Next.js, source in `Mojo/argue-landing/`) has three issues that undercut its pitch:

1. **Animation tells half the story.** The hero plays a single negotiation that ends with "15 min granted," then loops. The intended narrative is two sequences: (a) Argo grants 15 min after a back-and-forth, then (b) "15 minutes later" the user tries TikTok again, Argo *remembers* the prior promise, and access is denied. That second sequence is the actual punchline — that Argo has memory — and it's missing.
2. **Layout shifts during the animation.** When the typing indicator appears between Argo turns, everything below the chat (testimonials, CTA, footer) jumps. Caused by toggling `display: none` on the shared `#typing` element.
3. **Testimonial marquee shows empty space mid-loop.** The "infinite" scroll has a visible seam (the gap between the two duplicate sets is off by 8px from `-50%`), and on viewports wider than ~1336px the track simply isn't wide enough — past the last card the user sees blank background until the loop resets.

Goal: ship the second sequence, eliminate layout shift entirely, and make the marquee genuinely seamless on any viewport up to 1920px+.

## Files to modify

- `Mojo/argue-landing/app/page.jsx` — tighter mobile section padding, add sticky mobile CTA
- `Mojo/argue-landing/app/components/HeroChat.jsx` — add second sequence, restructure typing slots, mobile-responsive bubble sizing
- `Mojo/argue-landing/app/components/Testimonials.jsx` — duplicate cards more, swap gap → margin, smaller mobile cards
- `Mojo/argue-landing/app/globals.css` — drop `gap-4` on `.marquee-track`, add `.glass-denied`, extend `prefers-reduced-motion` block

## Recommended approach

### 1. Second sequence in HeroChat.jsx

Add new DOM nodes after `#granted`, in this order:

- `#divider-15min` — flex row with two `flex-1 h-px bg-white/10` lines flanking text "15 minutes later" in `text-sm font-medium text-txt-secondary`. Always rendered, starts `opacity-0`, fades in via simple `transition-opacity duration-500`.
- `#msg-6` (you, blue bubble): "yo open tiktok again real quick"
- `#typing-7` — typing slot before msg-7 (see §2)
- `#msg-7` (argo): "lol no. you literally just used your 15. I told you that was it for today and I meant it"
- `#msg-8` (you, blue bubble): "bro just 5 more mins pleaseee"
- `#typing-9` — typing slot before msg-9
- `#msg-9` (argo): "nope. tomorrow. go touch grass champ"
- `#denied` — same shape as `#granted` but uses `glass-denied` class and `border-red-400/30 bg-red-500/[0.08]`. Icon `✕`, text "access denied".

In `globals.css`, add `.glass-denied` mirroring `.glass-granted` structure but with red tones (radial-gradient `rgba(255,90,90,0.12)` and red-shifted inset highlights). Add `#denied` and `#divider-15min` to the `prefers-reduced-motion` selector list alongside `.granted-badge`.

### 2. Eliminate layout shift

Root cause: `#typing` toggles `display: none` ↔ `display: ''`, pushing later siblings down. `opacity-0` elsewhere already preserves layout, so messages don't shift — only typing does.

Fix: replace the single shared `#typing` element + `moveTypingAfter()` logic with **four dedicated typing slots**, one immediately before each Argo response that uses the typing animation:

- `#typing-3` before `#msg-3`
- `#typing-5` before `#msg-5`
- `#typing-7` before `#msg-7`
- `#typing-9` before `#msg-9`

(`#msg-1` and `#msg-6` open their sequence — no typing slot needed.)

Each typing slot is identical to the current `#typing` markup but:
- Always rendered in DOM (no `display: none`, ever)
- Starts `opacity-0`
- Reserves its full bubble height permanently — so the chat container's height is fixed from first paint

The animation script becomes a flat linear sequence — fade in / fade out via `opacity` only, no DOM mutation, no `moveTypingAfter` helper. Delete `moveTypingAfter` and the `typing.style.display` lines entirely.

Side benefit: this also stabilizes layout for the new sequence's typing pauses.

### 3. Fix the marquee

In `globals.css`:
- `.marquee-track`: change `@apply flex gap-4 w-max` → `@apply flex w-max`

In `Testimonials.jsx`:
- Card root className: add `mr-4` so every card (including duplicates) carries its own 16px right gutter. Now one set's width = `N × (320 + 16) = N × 336`, and `translateX(-50%)` lands exactly at the start of the second copy — perfect seam.
- Render **4 copies** of `TESTIMONIALS` instead of 2: `[0,1,2,3].flatMap((copy) => TESTIMONIALS.map(...))`. Track width = `16 × 336 = 5376px`, so half-track is 2688px — comfortably exceeds 1920px viewports, no empty space at any animation position. Mark `ariaHidden={copy > 0}` so screen readers only see the first copy.

Keyframe stays `0 → -50%`.

### 5. Mobile compactness + easier CTA access

The hero animation now has 9 messages (up from 5) plus a divider and two badges. On mobile, this pushes the CTA far below the fold and bubble text at `text-2xl leading-[34px]` is oversized.

**Bubble sizing in `HeroChat.jsx`** — apply Tailwind `sm:` breakpoint (640px) for desktop sizes:

- Bubble text: `text-lg leading-[26px] sm:text-2xl sm:leading-[34px]`
- Bubble padding: `px-4 py-3 sm:px-6 sm:py-4`
- User-side and Argo-side bubbles both
- Typing slot bubbles: `px-4 py-3 sm:px-5 sm:py-4`
- Granted/denied badges: `text-base px-5 py-3 sm:text-2xl sm:px-8 sm:py-4`
- Username labels (`argo`/`you`): keep `text-sm` (already small)

**Hero section in `page.jsx`** — tighten on mobile:

- Section: `pt-8 pb-12 gap-6 sm:pt-16 sm:pb-20 sm:gap-10` (currently `pt-16 pb-20 gap-10`)
- "meet argo." label: keep `text-lg` (fine)
- `<nav>`: `py-3 px-6 sm:py-5 sm:px-10` (currently `py-5 px-10`)

**"get argue" CTA section in `page.jsx`** — tighter mobile padding:

- `pt-8 pb-24 sm:pt-12 sm:pb-20` (extra `pb-24` mobile to clear the sticky CTA)
- Button height: `h-14 sm:h-16` (currently fixed `h-16`)

**Sticky mobile CTA** — most important fix for "easier access to the CTA." Add a fixed-bottom CTA shown only below `sm:`. In `page.jsx`, append before the `<footer>`:

```jsx
<a
  href="https://testflight.apple.com/join/7EpKtqWA"
  target="_blank"
  rel="noopener noreferrer"
  className="sm:hidden fixed bottom-0 inset-x-0 z-40 mx-4 mb-[max(1rem,env(safe-area-inset-bottom))] h-14 inline-flex items-center justify-center gap-2 bg-brand-orange text-white rounded-button font-bold text-lg btn-3d cta-glow"
>
  <svg width="18" height="22" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.81-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z" />
  </svg>
  Try TestFlight
</a>
```

Notes on the sticky CTA:
- `sm:hidden` — only visible on mobile; desktop keeps the existing in-flow CTA
- `mb-[max(1rem,env(safe-area-inset-bottom))]` — respects iPhone home-indicator safe area
- `mx-4` — leaves 16px gutter so it doesn't touch viewport edges (less harsh visually)
- `z-40` — above content, below any future modals
- The main `<FadeInSection>` CTA gets `pb-24` on mobile (above) so the sticky doesn't cover the in-flow CTA when scrolled to the bottom

**Testimonials mobile compactness in `Testimonials.jsx`** — slightly smaller cards on mobile so more fit per scroll-screen:

- Card: `w-[280px] mr-3 sm:w-[320px] sm:mr-4` (smaller width + tighter gap on mobile)
- Section vertical padding: `py-8 sm:py-12` (currently `py-12`)

### 4. Loop timing

After the existing 5-message sequence ends with `show(granted)`, append:

```
wait(1500)                 // hold "15 min granted" alone
show(divider-15min)        // fade in via opacity
wait(1000)
show(msg-6); wait(1700)
fadeIn(typing-7); wait(900); fadeOut(typing-7); wait(250)
show(msg-7); wait(2200)    // Argo's callback gets extra dwell — the punchline
show(msg-8); wait(1500)
fadeIn(typing-9); wait(900); fadeOut(typing-9); wait(250)
show(msg-9); wait(2000)
show(denied); wait(4000)   // hold denied
// loop top: hide all messages, divider, both badges; wait(800)
```

Add `denied` and `divider-15min` to:
- The hide-everything pass at the top of the loop
- The reduced-motion fast-path (show statically alongside `granted`)

Approximate cycle length: ~32s. Existing `prefers-reduced-motion` early-return must show msg-1..9, both badges, and the divider all at once.

## Verification

1. **Run dev server:**
   ```bash
   cd /Users/johnathanmo/Documents/XCode/Mojo/Mojo/argue-landing
   npm run dev
   ```
   Open `http://localhost:3000`.

2. **Animation correctness:** Watch one full loop. Confirm sequence 1 plays (msg-1..5 → granted), then "15 minutes later" divider fades in, then sequence 2 plays (msg-6..9 → denied), then everything resets.

3. **Layout shift:** Pin the page so the CTA button ("Try TestFlight") is in the viewport while the hero animation is playing. The CTA must not move pixel-for-pixel across the entire loop, including during typing dots. Confirm via DevTools Performance tab → Layout Shift entries should be near zero after first paint.

4. **Marquee seamlessness:**
   - Resize the browser to 1920px wide. Marquee should never show empty background — cards must always be visible across the full viewport at every animation phase.
   - Watch one full marquee cycle (48s) — no visible jitter or jump at the loop seam.
   - Hover the marquee — animation pauses (existing behavior).

5. **Reduced motion:** In macOS System Settings → Accessibility → Display, enable "Reduce motion." Reload. Confirm both sequences' messages, the divider, and both badges (granted + denied) are all visible statically, and the marquee is not animating.

6. **Mobile (375px wide, iPhone SE):**
   - Bubbles wrap correctly; no horizontal scroll
   - Both sequences and the divider read naturally at the smaller text size
   - Sticky "Try TestFlight" CTA visible at bottom from first paint, doesn't overlap the in-flow CTA when scrolled to bottom (the `pb-24` on the CTA section preserves clearance)
   - Sticky CTA respects safe-area-inset on iPhone with home indicator
   - Hero section feels tighter — less wasted vertical padding around "meet argo."

7. **Mobile (≥640px, `sm:` breakpoint):** Sticky CTA disappears; layout returns to the original desktop sizes for bubbles, CTA button, and section padding.
