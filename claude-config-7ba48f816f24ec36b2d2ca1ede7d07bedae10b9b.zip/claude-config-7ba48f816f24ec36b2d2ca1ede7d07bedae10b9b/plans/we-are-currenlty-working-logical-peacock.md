# Plan: Bring `/forms` redesign to functional parity with `SPECS/form-feature.md`

## Context

`SPECS/form-feature.md` is the authoritative functional spec for the legacy form/onboarding-flow feature. The redesigned surface under `src/components/forms/**` (plus the unchanged legacy components still powering `/firm/:slug` public flows) has wide gaps against the spec. This plan catalogs the gaps and sequences the work to close them without regressing anything already working.

**Audit summary (from parallel Explore agents):**
- Editor: basic authoring works; **no** profile-field-mapping UI, routing authoring UI, landing-page editor, or advanced type configs.
- Renderer (`FormRenderer`): 14/16 question types render; verification, account linking, multi-sig signatures, document upload, YouTube video are missing or stubs; custom completion actions do not fire.
- Assignment + post-submit: assignment/CRM opportunity/workflow trigger work; welcome email stubbed; auto-tags, lead-dedup pointer, e-sig PDF email, advisor alerts, due-date UI, JSON export all missing.
- Public/guest path still renders through legacy `QuizFlow` (not `FormRenderer`) — changes to one surface do not automatically reach the other.

**Decision baseline:** hold `FormRenderer` on the authenticated path and keep legacy `QuizFlow` on the public path until Phase 3; don't try to unify renderers inside Phase 1.

---

## Guiding rules

1. **Preserve the spec's "legacy quirks" call-outs (§19) as open product questions.** For auto-tags, requires-approval, and due-date dormancy, do not ship legacy-identical behavior — bring each up for a product decision before coding.
2. **Every shipped gap-closing change needs a spec-section reference in its commit message.** Keeps the spec → code traceability tight.
3. **Ship in vertical slices per phase.** Each phase must leave `/forms` demonstrably better end-to-end, not half-implemented across many surfaces.
4. **Do not touch legacy `QuizFlow.jsx` except to fix regressions.** The public/guest migration off QuizFlow is Phase 3; until then, legacy is the source of truth for guests.

---

## Phase 1 — Editor parity for the happy path (unblocks authoring)

**Goal:** An advisor can build every in-scope question type from scratch with every legacy config option, using only the redesigned `/forms` editor.

### 1.1 Per-question basic fields
- Add `description` and `placeholder` inputs to `QuestionCard.jsx` (both are in the legacy data model; already written on save). Spec §4.3, §5.
- Add question-card collapse/expand toggle. Spec §4.3.
- Add question search within a form (filter by label). Spec §4.3.

### 1.2 Profile-field mapping UI
- Add "Map to profile field" selector per question in `QuestionCard.jsx` meta editor.
- Populate options from the full catalogue in spec §5.3 (grouped: identity, contact, address, employment, family/legal, spouse, planning, referral, social).
- For phone, email, address, full-name types: expose the type-specific mapping targets (spec §5.2) rather than the generic catalogue.
- Store as `question.profileField` (legacy field name) so existing `personalInfo` mapping at submit keeps working.

### 1.3 Type-specific config for missing/partial types
- **Phone** (QuestionCard meta): country list (15 per spec), default country, mapping target. Spec §5.2, §13.2.
- **Full name** (meta): per-component enable/require/label/placeholder (prefix, first, middle, last, suffix). Spec §5.2.
- **Address** (meta): per-component enable/require; mapping target. Spec §5.2.
- **Multiple choice / dropdown** (meta): "Allow Other" toggle that reveals a free-text input at runtime. Spec §5.4, §13.2.
- **Rating** (meta): optional labels at each end of the scale. Spec §5.4.
- **E-signature** (meta): disclosure text, require-typed-name, show-date-field, allow-type-to-sign, multi-signature slots (each with role label, pre-filled-by-advisor flag, required flag), email-to-client, email-to-advisor. Spec §5.7.
- **Document upload** (meta): category, document-type label, allowed extensions, max file size. Spec §5.6.
- **Information card** (meta): style (info/warning/success/disclaimer), body, optional URL (promotes to link-card). Spec §5.5.
- **YouTube video** — add as a new question type to the registry with URL input + ID extraction. Spec §5.5.
- **Account linking** — add as a new question type to the registry with "show net worth shortcut" toggle and "at least N accounts required" control. Spec §5.6. (Renderer work for it is Phase 2.)

### 1.4 Flow-level settings parity
- In `FormSettingsView.jsx`:
  - Add theme block: color preset (indigo/blue/green/purple/teal/orange) + custom hex, logo position (top-left/center), show/hide header, show/hide logo. Spec §4.5, §9.1.
  - Add welcome message, header text, survey header text inputs. Spec §4.5, §18.1.
  - Add completion-opportunity editor: enable, type, pipeline, stage, projected close date (static or answer-derived), projected value (amount + classification + period), notes, referred-by. Spec §10.1, §18.1.
  - Add scheduler completion action: Nylas scheduler picker, feeds `completionAction: 'scheduler'`. Spec §11.1.
  - Add Nylas-hosted guest completion action. Spec §11.2.
  - Add "set as default flow" on the form catalog row (not inside settings). Spec §4.1.

### 1.5 Form-catalog surface
- Add "set default" button on `FormRow.jsx` with visual indicator. Spec §4.1.
- Add "copy URL / copy embed URL / copy share message" menu (email / LinkedIn / SMS / social templates). Spec §4.7.
- Add JSON and CSV export actions on each form row (config + all responses). Spec §4.8, §12.3.

### 1.6 Legacy onboarding questions block
- Resurrect the six legacy first-class questions (monthly freedom, target calculation, DOB, tax info, current income, current investable assets, legal address) as an opt-in block with per-question enable + label override. Spec §4.5, §19.10.
- **Product decision required** before coding: keep as a first-class block or fold into regular custom questions? Ask user before implementing.

**Exit criteria for Phase 1:** an advisor can open the editor, create a new form with any combination of the 16 legacy question types, configure every per-question and flow-level setting the spec lists (except routing — that is Phase 4), and save without error.

---

## Phase 2 — Renderer parity on the authenticated path

**Goal:** When an advisor assigns a legacy-style form to a client, the client completes it with full behavior parity against the spec.

### 2.1 Missing/stub question-type renderers
- **YouTube video** — `VideoInput.jsx`; add `case 'youtube_video'` in `FormQuestionRenderer`. Spec §5.5.
- **Document upload** — replace `FileUploadPlaceholder` with real uploader that enforces category/type/size and files into the client vault. Spec §5.6, §8.2.
- **Account linking** — new renderer component that opens Plaid in a modal and updates linked-account count. Integrate with existing `PlaidContext` in the app. Spec §5.6, §8.2, §15.6.
- **E-signature** — full mode with disclosure text, typed-name, date field, type-to-sign, multi-sig slot rendering (advisor's pre-filled slot shown alongside the client's empty slot). Generate PDF on submit + optional email to client/advisor. Spec §5.7, §8.2, §14.4.

### 2.2 Verification UI inside `FormRenderer`
- Port the inline 6-digit SMS code entry (Twilio) for phone questions. Spec §8.2, §14.5.
- Port the inline 6-digit email code entry for email questions. Spec §8.2, §14.5.
- Include the 10-second timeout auto-recovery the spec calls out. Spec §8.2.

### 2.3 "Other" free-text on choice inputs
- Add "Other" option handling in `MultipleChoiceInput` and `DropdownInput` that reveals a free-text field at runtime; validation requires non-empty text when selected. Spec §5.4, §13.2.

### 2.4 Card-mode display
- Add one-question-per-screen presentation mode alongside the existing scroll mode, driven by flow's `displayMode`. Spec §4.5, §8.2.

### 2.5 Progress bar visual
- `FormProgressBar.jsx` currently renders structure only — add animated fill and percent text. Spec §8.2.

### 2.6 Custom completion-action routing
- In `AccountFormExperiencePage` submit handler, honor the full list of authenticated completion actions: dashboard, net worth, cashflow, investments, custom URL (same/new tab), scheduler (Nylas). Currently only dashboard is wired. Spec §11.1.

**Exit criteria for Phase 2:** every spec-§5 question type renders and validates correctly on the authenticated path; verification works end-to-end; completion actions route the respondent to the firm-configured destination.

---

## Phase 3 — Move the public/guest path off legacy `QuizFlow`

**Goal:** The same `FormRenderer` powers both authenticated and guest paths; legacy `QuizFlow.jsx` is retired (or frozen) except for historical compatibility.

### 3.1 Shared renderer surface
- Extract `FormRenderer` branching to support both authenticated (with `assignmentId`) and guest (`organizationId + flowId`, no auth) modes.
- Preserve the logo-refresh behavior (`autoRefreshLogosIfNeeded`) in the shared renderer. Spec §8.2.
- Mount the shared renderer on `FirmLandingPage` in place of the lazy-loaded `QuizFlow`.

### 3.2 Guest-specific behaviors
- Pre-signup quiz gating from flow's `allowPreSignupQuiz`. Spec §3, §9.4.
- Auto-save for net-worth / cashflow sub-steps during signup funnel (spec §8.3 — porting this is optional; confirm with user before implementing).
- Signup-handoff: on guest completion with action `signup`, open firm-branded signup modal pre-populated with responses. Spec §11.2.
- Guest completion actions: `signup`, `success_message`, `custom_url`, `nylas_hosted` — route each correctly. Spec §11.2.

### 3.3 Guest submission + lead creation
- Call the guest-quiz lead creation path with name/email/phone/responses.
- Maintain the `latestGuestFormSubmissionId` pointer on the lead so dedup works on re-read. Spec §9.5.

### 3.4 Embed mode
- `FirmLandingPage` already supports `isEmbed`; confirm the shared renderer preserves iframe-safe chrome suppression. Spec §3, §9.3.

**Exit criteria for Phase 3:** `/firm/:slug` and `/embed/firm/:slug` paths render through the shared `FormRenderer`; legacy `QuizFlow` can be deleted (or at minimum removed from the bundle) without breaking the public path.

---

## Phase 4 — Routing authoring UI (first-class, new capability)

**Goal:** Advisors can author conditional routing rules in the editor; the runtime already supports them (§6).

### 4.1 Per-question rule editor
- Add "Logic" tab or expandable section on `QuestionCard.jsx`.
- For each rule: pick condition type (18 options from spec §6.2), configure condition parameters (value, list, range, threshold), pick action (skip-to, end-quiz, redirect, continue), configure action parameters (target question, URL, defer-to-question).
- Support adding any number of rules plus a fallback action. Spec §6.1.

### 4.2 Flow-level logic view
- Add a "Logic overview" screen that shows all rules as a directed graph (or at least a list grouped by source question).
- Detect unreachable questions and warn.

### 4.3 Validation
- Prevent saving rules that reference deleted questions.
- Warn when rules would form a cycle beyond the 10-iteration safety cap. Spec §6.4.

**Exit criteria for Phase 4:** an advisor can build, from scratch in the editor, a flow with a knockout path, a skip-ahead, an external redirect, and a deferred end — and the runtime executes every path correctly.

---

## Phase 5 — Landing-page editor

**Goal:** Advisors configure the firm-wide landing page and per-flow overrides from the redesigned surface.

### 5.1 Per-flow landing-page override editor
- Enabled/inherit toggle.
- Page mode: landing vs. create-account.
- Hero: title, subtitle, message, video URL.
- Button text, theme color, header sign-in visibility.
- Section visibility toggles.
- Custom sections (drag-reorderable, title + body + video + images with width/alignment/text-size/background).
- Custom CSS textarea.
- Live side-by-side preview with 2-second auto-save. Spec §4.6.

### 5.2 Firm-wide landing-page editor
- URL slug + slug-history handling.
- URL format: full vs. short.
- Hero, theme color, CTA button style, layout/logo controls.
- Section visibility, header sign-in default, custom sections, testimonials, feature-video selections.
- Signup capacity with capacity-warning CTA swap. Spec §9.1, §18.3.

**Exit criteria for Phase 5:** advisor can configure and preview per-flow and firm-wide landing pages without touching legacy `FirmPageSettings` UI.

---

## Phase 6 — Post-submit pipeline gaps

**Goal:** Every side-effect listed in spec §10, §14 fires correctly.

- **Welcome email** — wire the send on submission (or specific-answer trigger). Honor Nylas sender identity when configured. Spec §10.3, §14.2.
- **Test welcome email** — firm-admin test send. Spec §14.6.
- **Advisor-question-answered alert** — fire on high-priority answers. Spec §14.3.
- **E-signature signed-PDF email** — generate PDF, email to client and/or advisor per settings. Spec §14.4.
- **Auto-tag application** — **requires product decision** (spec §19.7). If confirmed, apply captured auto-tags to client (or lead) on submission.
- **Lead dedup pointer** — actively maintain `latestGuestFormSubmissionId` on the lead record on every guest submission. Spec §9.5, §19.11.
- **JSON export** — flow config + responses as downloadable JSON. Spec §4.8, §12.3.
- **CSV export** — complete the existing framework. Spec §4.8, §12.3.

---

## Phase 7 — Admin-only & assignment polish

- PDF-to-flow import (Claude-backed) with support for multiple-choice, single-choice, text, number, date. Spec §4.2, §15.10.
- Assignment due-date UI — **product decision required** (spec §19.15). If confirmed, expose existing data-model field.
- Quick-assign modal parity with full-assign (if any gaps remain).
- Reserved-slug enforcement (authorize/mcp/token/register). Spec §9.2.
- Old-slug redirect handling (slug history). Spec §9.2.

---

## Phases at a glance

| Phase | Scope | Blocks later phases? |
|---|---|---|
| 1 | Editor parity (no routing, no landing page) | Yes — Phase 2/4 depend on type configs being author-able |
| 2 | Renderer parity on authenticated path | No — independent of Phase 3 |
| 3 | Unify renderer on guest path | Depends on Phase 2 |
| 4 | Routing authoring UI | Depends on Phase 1 |
| 5 | Landing-page editor | Independent |
| 6 | Post-submit pipeline | Partially depends on Phase 1 (completion-opportunity editor) |
| 7 | Admin polish | Independent |

---

## Open product questions (must answer before coding affected items)

1. **Legacy onboarding questions block (§19.10)** — preserve as a first-class block or fold into custom questions?
2. **Auto-tags (§19.7)** — what does the firm expect to happen when a flow completes? Apply to client/lead record? Surface in reporting?
3. **Requires-approval (§19.8)** — keep as no-op, remove, or actually implement an approval gate?
4. **Assignment due date (§19.15)** — keep dormant, expose UI, or remove from the data model?
5. **Single submission per assignment (§19.9)** — enforce one submission (upsert) or allow and link multiple?
6. **Guest auto-save (§8.3)** — port to FormRenderer or drop as a legacy quirk?
7. **`pharoftiolfi` repair utility (§12.4)** — confirm redesign ignores this historical bug.

---

## Critical files to modify (grouped by phase)

- **Phase 1**: `src/components/forms/editor/QuestionCard.jsx`, `src/components/forms/editor/questionTypes.js`, `src/components/forms/editor/FormSettingsView.jsx`, `src/components/forms/editor/FormsListView.jsx`, `src/components/forms/editor/FormRow.jsx`, `src/services/formManagementService.js`, any per-type meta-editor files under `src/components/forms/editor/**`.
- **Phase 2**: `src/components/forms/renderer/FormRenderer.jsx`, `src/components/forms/renderer/FormQuestionRenderer.jsx`, new type renderers under `src/components/forms/renderer/**`, `src/components/AccountFormExperiencePage.jsx`, `src/utils/formExperience.js`, `src/utils/validation.js`.
- **Phase 3**: `src/components/FirmLandingPage.jsx` (replace `LazyQuizFlow` → `FormRenderer`), new guest-mode branches in `FormRenderer`.
- **Phase 4**: new `src/components/forms/editor/LogicEditor.jsx`, extended `questionTypes.js` schema for rules, validation helpers in `src/utils/conditionalLogic.js`.
- **Phase 5**: new `src/components/forms/editor/LandingPageEditor.jsx`, integrate `landingPageResolver.js`.
- **Phase 6**: cloud function wiring (`functions/src/email/**`, `functions/src/formCompletionOpportunity.ts`), export code in `FormResponsesView.jsx`.
- **Phase 7**: assignment-modal updates, slug-history utility in routing.

---

## Verification

For each phase, verification is end-to-end through the UI on the dev server, checked against the spec's user-visible behavior. No unit test alone proves a phase complete.

- **Phase 1 verification:** create a new form from scratch; add one of every question type; configure every per-type option; save; reload; every config persists.
- **Phase 2 verification:** assign the Phase 1 form to a test client; complete it; every type validates correctly; verification codes work; completion action routes to the configured destination.
- **Phase 3 verification:** open the firm's public landing page; complete a pre-signup flow end-to-end; lead appears in the firm's leads with responses; re-submit as same guest and confirm dedup pointer advances.
- **Phase 4 verification:** author a knockout flow with 3+ conditions and 2+ actions entirely in-UI; respondent walks the intended path.
- **Phase 5 verification:** edit a firm's landing page and a flow's override; preview updates live; auto-save fires every 2s; changes persist after reload.
- **Phase 6 verification:** submit a form that has welcome email + opportunity + workflow + auto-tags enabled; every side-effect fires.
- **Phase 7 verification:** import a 10-question PDF; draft flow generated; advisor can polish and publish without manual data entry.

---

## Recommended first step

Do **not** start coding. First, get product decisions on the seven open questions above. Some of them (especially #1 and #2) change the Phase 1 scope materially. Once answered, execute Phase 1 as a single focused engineering push (est. 3–5 days with CC+gstack).
