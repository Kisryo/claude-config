# Plan: `bach-feature` skill (local to this repo)

## Context

User wants a one-shot skill that, given a feature name, will:

1. Deep-analyze user-facing behavior of the feature in the current repo
2. Write `SPECS/[Feature]_SPEC.md`
3. Spawn parallel subagents (the user's "/batch" — they mean a single message with multiple `Agent` tool calls; no literal `/batch` skill exists) to build a brand-new redesigned route under entirely new files. The old route/code stays alive and untouched.
4. Reference `DESIGN.md` tokens, cut dead code, follow best practices
5. Test/QA via lint, build, and the existing `/qa` skill
6. Write `docs/<feature>.md` — a user-facing guide

This skill does NOT exist today. The closest existing skill, `/feature-spec`, only does steps 1+6 (and uses lowercase `<feature>.md` for the spec filename, not `[Feature]_SPEC.md`), so we re-implement the spec writing inline rather than composing.

## Skill design

**Path:** `.claude/skills/bach-feature/SKILL.md` — **local to this repo**, resolved as `/Users/johnathanmo/.superset/worktrees/SAMWEALTH-new/23jmo/task-redesign/.claude/skills/bach-feature/SKILL.md`. Directory tree must be created (`.claude/` exists at the repo root for settings, but `.claude/skills/` does not yet — verify before writing).

The name "bach-feature" reflects the workflow's parallel-voice character — many subagents writing simultaneously into disjoint directories, then resolving into a single integrated route.

**Frontmatter:**

```yaml
---
name: bach-feature
argument-hint: [feature name, e.g. "tasks"]
description: Deep-analyze an existing feature, write SPECS/[Feature]_SPEC.md, then spawn parallel subagents to build a brand-new redesigned route at /<feature>-v2 (or user-chosen path) using DESIGN.md tokens, leaving the old route untouched. Runs lint + build, invokes /qa for browser dogfooding, and writes a user guide at docs/<feature>.md. Use when asked to "redesign X", "rebuild X", or "v2 of X".
allowed-tools: Read, Write, Edit, Grep, Glob, Bash, Agent, AskUserQuestion, Skill
---
```

## Phase structure (8 phases, each with explicit exit gate)

### Phase 0 — Bootstrap & detection
- Read `$ARGUMENTS`; if empty, `AskUserQuestion` for feature name.
- Detect spec dir: prefer `SPECS/`, fall back to `specs/`.
- Detect docs dir: prefer `docs/`, fall back to `DOCS/`.
- Confirm `DESIGN.md` exists at repo root; halt if missing.
- Compute `$FEATURE_NAME` (lowercase-dashed), `$FEATURE_PASCAL`, `$FEATURE_UPPER`, `$SPEC_FILENAME = ${FEATURE_UPPER}_SPEC.md` (matches user's literal `[Feature]_SPEC.md`).
- Read `src/App.jsx` lines 1–200 and ~1450+ to capture the lazy-import + `<LazyRoute>` + `<Route>` patterns for Phase 5.
- **Exit gate:** all variables resolved; `DESIGN.md` exists; route patterns located.

### Phase 1 — Confirm scope (single batched `AskUserQuestion`)
Three questions in one call:
1. Confirm feature name.
2. Pick new route: `/<feature>-v2` / `/<feature>-redesigned` / `/<feature>-new` / Custom.
3. Pick new directory under `src/pages/`: `<FeaturePascal>V2` / `<FeaturePascal>Redesigned` / `<FeaturePascal>New` / Custom (default PascalCase per repo convention — `FormEditor/`, `Onboarding/`).

**Exit gate:** `$NEW_ROUTE` and `$NEW_DIR` set; user did not cancel. If `$SPEC_DIR/$SPEC_FILENAME` already exists, ask once whether to overwrite/append-version/skip.

### Phase 2 — Parallel spec exploration → main-thread spec write
- Spawn ~5 `Agent` calls (`subagent_type: Explore`) in a single message, sharded by topic:
  - A: surfaces (every screen/modal/drawer/route the feature touches)
  - B: business rules (validation, role gates, branching)
  - C: data flow described as user impact (NOT collection names)
  - D: integrations & notifications (emails, webhooks, downstream effects)
  - E: permissions & roles
- Each agent: "Return user-facing behavior, not file paths or collection names."
- **Main thread reconciles and writes `$SPEC_DIR/$SPEC_FILENAME`.** Section list: Overview, Roles, Entry points, Author/respondent experiences, Alternate paths, Variants, Conditional logic, Lifecycle, Post-action effects, Reporting, Validation, Notifications, Integrations, Permissions, Settings, Constraints/quirks. Top of file gets a **Redesign target** block: `$NEW_ROUTE`, `src/pages/$NEW_DIR/`, "old route untouched."
- **Exit gate:** spec file present with ≥ 8 `## ` sections.

### Phase 3 — Design token extraction
- Read `DESIGN.md` once on the main thread.
- Synthesize an **in-memory token cheat-sheet** (palette hexes, gradients, shadow recipes, font stacks, motion easings) — passed verbatim to every Phase 4 subagent so they paste-copy rather than re-read or invent. Repo CLAUDE.md rule reinforced: "do not invent hexes, gradients, easing curves, or shadow recipes."
- **Exit gate:** token sheet ready in memory (no file written).

### Phase 4 — Parallel redesign build (the "/batch" step)
Single message with N parallel `Agent` calls (`subagent_type: general-purpose`). **Sharded by directory disjointness, not by concept** — this is the parallel-safety invariant: collisions are impossible by construction.

Default 5 shards (prune to 2–4 if spec is simpler — heuristic: count surfaces in Phase 2 spec):

| Shard | Owns (write boundary) |
|---|---|
| A — Page shell | `src/pages/$NEW_DIR/index.jsx` + `${NEW_DIR}Layout.jsx`: outer layout, sub-header, internal Suspense, role/auth wrappers, nested `<Routes>` |
| B — List/table view | `src/pages/$NEW_DIR/list/**` |
| C — Detail/drawer view | `src/pages/$NEW_DIR/detail/**` |
| D — Forms/edit view | `src/pages/$NEW_DIR/edit/**` |
| E — Shared internal components | `src/pages/$NEW_DIR/_components/**` |

Each agent's prompt includes verbatim:
1. Spec filename → "Read this first."
2. The DESIGN.md token cheat-sheet from Phase 3.
3. **Hard write boundary block:**
   > You may only create or edit files matching `src/pages/$NEW_DIR/<your-shard>/**`. You may READ any file. You must NOT modify: `src/App.jsx`; `src/pages/<OldDir>/**`; any sibling shard's directory; any file outside `src/pages/$NEW_DIR/`. If your task seems to require modifying any of those, return early and report.
4. Best-practice rules: cut dead code, no commented-out blocks, no TODO stubs, may read old feature for reference but must not import from it.

**Exit gate:** every shard's directory is non-empty (`find src/pages/$NEW_DIR -name "*.jsx"`); `git diff --name-only` shows zero modifications outside `src/pages/$NEW_DIR/`.

### Phase 5 — Route wiring (sequential, single-thread)
- Single `Edit` to `src/App.jsx`:
  - Add `const ${NEW_DIR} = lazy(() => import('./pages/$NEW_DIR'));` near the existing lazy-import block (~lines 21–73).
  - Add `<Route path="$NEW_ROUTE/*" element={<LazyRoute><${NEW_DIR} /></LazyRoute>} errorElement={<ErrorBoundary />} />` near the route block (~line 1456+), before any catch-all.
- Sequential because `App.jsx` is a shared file; concurrent edits would clobber.
- **Exit gate:** both lines present in `App.jsx`; no other files touched.

### Phase 6 — Lint + build gates
- `npm run lint` (project enforces `--max-warnings 0`). On failure: spawn one repair `Agent` scoped to the failing path, re-run. Cap: 3 attempts.
- `npm run build` (use `npm run build:lowmem` if memory pressure shows). Same loop, cap 3.
- **Exit gate:** both pass exit code 0. After 3 failed attempts on either, halt and report — do not proceed to QA.

### Phase 7 — QA via `/qa` skill
- Start `npm run dev` in background (Vite, default port 5173).
- Wait for `http://localhost:5173/$NEW_ROUTE` to return 200 with a sane timeout.
- Invoke `Skill { skill: "qa" }` directing it to test the new route. `/qa` itself uses `/browse` and `/gstack` for headless dogfooding — no need to call those directly.
- **Failure policy:** `/qa` is already a fix-and-verify loop. If it gives up, halt and report — do NOT auto-recurse from this skill (would just thrash).
- **Exit gate:** `/qa` reports zero critical/high bugs.

### Phase 8 — Write `docs/$FEATURE_NAME.md`
Sections: What this feature is (2–3 sentences, user language) · Who it's for · How to access (single bullet pointing to `$NEW_ROUTE`) · Key flows (numbered, top 3–5) · What's new vs. old · Where to learn more (link to spec). ~80–120 lines, no implementation terms. Match tone of existing `docs/forms.md`-style files.

### Final report (terminal output)
Absolute paths to all four artifacts (spec, new code root, modified `App.jsx`, doc), the new route URL, lint/build pass status, QA summary, and any "Open questions" surfaced during Phase 2.

## Files to be created/modified

- **New:** `.claude/skills/bach-feature/SKILL.md` (local to this repo) — the only file the skill-creation task itself writes. Parent directories `.claude/skills/bach-feature/` need to be created first.
- **At runtime, when invoked:** `SPECS/[FEATURE]_SPEC.md`, `src/pages/<NewDir>/**`, `docs/<feature>.md`, single insertion-only edit to `src/App.jsx`.

## Existing references the SKILL.md should call out

- `~/.claude/skills/feature-spec/SKILL.md` — shape reference for frontmatter style and phase prose; do NOT delegate spec-writing to it (different filename convention).
- `/Users/johnathanmo/.superset/worktrees/SAMWEALTH-new/23jmo/task-redesign/src/App.jsx` lines ~21–73 (lazy imports) and ~1456+ (routes) — Phase 5 edit targets.
- `/Users/johnathanmo/.superset/worktrees/SAMWEALTH-new/23jmo/task-redesign/DESIGN.md` — Phase 3 reads this; project CLAUDE.md mandates copy-paste-only usage of its tokens.
- `/Users/johnathanmo/.superset/worktrees/SAMWEALTH-new/23jmo/task-redesign/SPECS/FORMS_REDESIGN_SPEC.md` — exemplar spec structure.

## Verification (after the skill is written)

1. **Static check:** confirm `.claude/skills/bach-feature/SKILL.md` exists at the repo root with valid frontmatter (`name`, `description`, `argument-hint`, `allowed-tools`) and 8 numbered phases.
2. **Skill discovery:** start a fresh session in this repo and confirm `/bach-feature` appears in the available skills list (local skills are picked up automatically from `.claude/skills/` — no global registration needed).
3. **Dry-run smoke test:** invoke `/bach-feature` with a small known feature (e.g. `notes` or `documentation`) and watch:
   - Phase 0 detects `SPECS/` correctly
   - Phase 2 produces a spec file with ≥ 8 `## ` sections
   - Phase 4 spawns multiple Agent calls in a single message and writes only inside `src/pages/<NewDir>/`
   - Phase 5 inserts (does not overwrite) the lazy import + route in `App.jsx`
   - Phase 6 runs `npm run lint` and `npm run build`
   - Final report lists all four artifacts with absolute paths
4. **Boundary check (most critical):** after a real run, `git diff --name-only` should show exactly: `src/App.jsx` (insertion-only), all-new files under `src/pages/<NewDir>/`, the spec file, the doc file. Nothing else. If anything else is touched, the do-not-touch rules in Phase 4 weren't enforced strongly enough.
