# Big Lift: Threshold-event reblock + ReblockArmer + observability

## Context

After commit `a3165d3` (persisted token JSON) and the follow-up 5-part fix that's already merged, short-grant reblocking still has one open hole: when iOS 26 fails to fire `intervalDidEnd` for a 16-min-floored schedule, there is no other path to wake the `DeviceActivityMonitor` extension. Web research (10 parallel agents) and Apple Feedback threads confirm `intervalDidEnd` reliability is a "known issue" on iOS 26.3.x — `deviceactivityd` produces zero logs in some cases.

The user's bug: grant 5 min, stay on Twitter, force-quit Mojo → shield never reblocks. Steps 1, 2, 4, 5 of the wake chain are now fixed; **Step 3 (iOS wakes the extension at the boundary) is the remaining single point of failure.**

This plan adds a second, independent way for iOS to wake the extension — `DeviceActivityEvent` threshold-based callbacks, which fire on accumulated *usage* (different code path inside `deviceactivityd` than time-based intervals). It also restructures arming into a shared value type and adds path-level observability so future iOS regressions are diagnosable from telemetry, not anecdote.

## Scope: Option A (Mojo-flavored, threshold + refactor + observability)

Picked over B (UX-shift, shield-extension arming) because B doesn't strengthen Step 3 — it only changes WHO arms, not whether iOS fires the callback. Picked over C (threshold only) because C re-creates the same observability gap that made this bug hard to triage in the first place.

## Why threshold-events fix Step 3

`DeviceActivityEvent(applications: [token], threshold: DateComponents(second: N))` fires `eventDidReachThreshold(_:activity:)` when the user accumulates `N` seconds of usage on the monitored app *within the schedule interval*. Two properties matter:

- **Different callback than `intervalDidEnd`.** Different code path in iOS, so when one path is buggy on a given OS version, the other often still fires. Industry pattern: Opal, Jomo, ScreenZen, Habit Doom all lean on threshold events.
- **Tied to actual user activity.** In our scenario the user IS using the app (that's why they granted). If they close the app early, the in-process `Task.sleep` already covers that case — Mojo is still alive when not foregrounded *into* the granted app.

After this change there are **5 independent reblock wake paths**, ranked by reliability for the user's bug:

1. In-process `Task.sleep` — Mojo alive
2. `BGAppRefreshTask` — Mojo backgrounded, iOS opportunistic wake
3. `eventDidReachThreshold` — **NEW**, fires on usage, primary path for the bug
4. `intervalDidEnd` — 16-min floor, slow-path safety net
5. `.timeSensitive` notification at T+1s — repaint nudge (kept; per project memory `project_screentime_timesensitive_reblock.md` TAB-111, empirically does cause shield repaint on iOS 26.x; the comment in `TimedAccessManager.swift:329-339` calling this "folklore" must be reverted as part of this work — that change was made on the prior turn against codex's a priori reading and contradicts our own empirical evidence)

## Changes

### 1. NEW — `MojoiOS/Core/ScreenTime/ReblockArmer.swift`

Value type that owns all out-of-process arming for one grant. Pulls the four arming methods currently scattered in `TimedAccessManager` (`grantAccess` lines 78-80) into one place so the contract is "construct + call `arm()`" and the call site is one line.

```swift
@MainActor
struct ReblockArmer {
    let appToken: ApplicationToken
    let expiryDate: Date
    let appName: String              // for notification body
    let sharedDefaults: UserDefaults?
    let slug: String                 // "t-\(abs(token.hashValue))"

    func arm() {
        persistTokenForExtension()
        scheduleExpiryWarningNotification()
        scheduleExpiryNotification()
        scheduleDeviceActivityReblock()  // schedule + threshold event
        ReblockTelemetry.increment(.armed)
    }

    func cancel() {
        cancelExpiryWarningNotification()
        cancelExpiryNotification()
        cancelDeviceActivityReblock()
    }

    // private methods moved verbatim from TimedAccessManager:
    //   - scheduleExpiryWarningNotification (lines 290-321)
    //   - scheduleExpiryNotification        (lines 341-371)
    //   - scheduleDeviceActivityReblock     (lines 405-456) — modified to add threshold event
    //   - cancel*                           (lines 323-327, 373-377, 458-468)
}
```

The in-process `Task.sleep` timer stays in `TimedAccessManager` because the `Task` handle is per-process state that has to outlive `arm()`'s scope.

### 2. MODIFIED — `MojoiOS/Core/ScreenTime/TimedAccessManager.swift`

- **Replace lines 78-80 + 90-92** with `ReblockArmer(...).arm()` and `.cancel()` calls. `grantAccess` and `revokeAccess` collapse to a few lines each.
- **Add threshold event** to `scheduleDeviceActivityReblock` (now in `ReblockArmer`). The actual grant duration goes into the threshold; the schedule's intervalEnd stays floored to 16 min for iOS acceptance:

  ```swift
  let actualGrantSeconds = max(60, Int(expiryDate.timeIntervalSinceNow))
  let event = DeviceActivityEvent(
      applications: Set([appToken]),
      threshold: DateComponents(second: actualGrantSeconds)
  )
  let eventName = DeviceActivityEvent.Name(ScreenTimeConstants.reblockEventPrefix + slug)

  do {
      try center.startMonitoring(activityName, during: schedule, events: [eventName: event])
  } catch DeviceActivityCenter.MonitoringError.intervalTooShort {
      // log + leave in-process timer + BGTask + .timeSensitive as remaining paths
  } catch { /* same */ }
  ```

- **Telemetry increments** at `armed` (in `ReblockArmer.arm`), `inProcessFired` (in `handleExpiry`), `bgTaskFired` (in `handleBackgroundRelock`).
- **Comment revert** at lines 329-339: restore acknowledgment that `.timeSensitive` notifications empirically cause shield repaint on iOS 26.x per TAB-111. Drop the "folklore" framing — empirical evidence on the actual deployment OS outranks codex's a priori SDK-header analysis.

### 3. MODIFIED — `MojoDeviceActivity/DeviceActivityMonitorExtension.swift`

- **Refactor `eventDidReachThreshold`** (lines 45-49). Currently calls the blanket-reapply `applyShieldsFromSharedData()` for every event — same destructive-fallback hazard that the `intervalDidEnd` path fixed in the prior turn. Route by event name prefix:

  ```swift
  override func eventDidReachThreshold(_ event: DeviceActivityEvent.Name, activity: DeviceActivityName) {
      super.eventDidReachThreshold(event, activity: activity)
      NSLog("[MojoActivity] eventDidReachThreshold: %@ (activity: %@)", event.rawValue, activity.rawValue)

      if event.rawValue.hasPrefix(ScreenTimeConstants.reblockEventPrefix) {
          let slug = String(event.rawValue.dropFirst(ScreenTimeConstants.reblockEventPrefix.count))
          reapplyShieldForExpiredBreak(slug: slug)
          incrementTelemetry(.thresholdFired)
      } else {
          // existing screen-time threshold path (st-* prefix, currently unused)
          applyShieldsFromSharedData()
      }
  }
  ```

- **`intervalDidEnd` reblock branch** (line 39-42) gets `incrementTelemetry(.intervalEndFired)` after the existing per-token reapply. The "no token, bail" branch in `reapplyShieldForExpiredBreak` (lines 64-69) gets `incrementTelemetry(.extensionNoOp)`.
- **Telemetry shared helper**: a tiny `incrementTelemetry(_:)` private method that does the same App-Group counter write `ReblockTelemetry.increment` does. Cannot import the host-target file from the extension target, so duplicate ~5 lines or move both into a target-shared file. (See change #5.)

### 4. MODIFIED — `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift`

Add at end:
```swift
static let reblockEventPrefix = "reblock-event-"
static let telemetryCountersKey = "reblock.telemetry.counters.v1"
```

The existing `eventPrefix = "st-"` (line 32) is reserved for a different feature (screen-time threshold) — keep it, route by prefix discrimination.

### 5. NEW — `MojoiOS/Core/ScreenTime/ReblockTelemetry.swift`

Add this file to **both** targets (host + `MojoDeviceActivity` extension) so it's importable from both processes. App-Group-backed counter store; both processes can increment.

```swift
import Foundation

enum ReblockTelemetry {
    enum Path: String, CaseIterable, Codable {
        case armed
        case inProcessFired
        case bgTaskFired
        case thresholdFired
        case intervalEndFired
        case extensionNoOp
    }

    private static var defaults: UserDefaults? {
        UserDefaults(suiteName: ScreenTimeConstants.appGroupID)
    }

    static func increment(_ path: Path) {
        guard let d = defaults else { return }
        var counters = (d.dictionary(forKey: ScreenTimeConstants.telemetryCountersKey) as? [String: Int]) ?? [:]
        counters[path.rawValue, default: 0] += 1
        d.set(counters, forKey: ScreenTimeConstants.telemetryCountersKey)
    }

    static func snapshot() -> [Path: Int] {
        guard let d = defaults,
              let raw = d.dictionary(forKey: ScreenTimeConstants.telemetryCountersKey) as? [String: Int] else {
            return [:]
        }
        var out: [Path: Int] = [:]
        for (k, v) in raw {
            if let p = Path(rawValue: k) { out[p] = v }
        }
        return out
    }

    static func reset() {
        defaults?.removeObject(forKey: ScreenTimeConstants.telemetryCountersKey)
    }
}
```

Surface in a small dev-only debug section (gated `#if DEBUG`) in `ProfileView` or a hidden `SettingsView` row. Two-line table: path name + counter, plus a "Reset" button.

## Critical files

- `MojoiOS/Core/ScreenTime/TimedAccessManager.swift` (refactor + comment revert + telemetry hooks)
- `MojoiOS/Core/ScreenTime/ReblockArmer.swift` (NEW)
- `MojoiOS/Core/ScreenTime/ReblockTelemetry.swift` (NEW, target-shared)
- `MojoiOS/Core/ScreenTime/ScreenTimeConstants.swift` (constants)
- `MojoDeviceActivity/DeviceActivityMonitorExtension.swift` (threshold routing + per-token discipline + telemetry)

## Verification

End-to-end on a real device (simulator doesn't simulate FamilyControls):

1. **Smoke**: `xcodebuild -scheme MojoiOS -configuration Debug build`. Compile clean.
2. **The user's bug** (force-quit case):
   - Cold-launch Mojo → ensure Twitter is shielded.
   - Tap shield → grant 5 min via Argo.
   - Stay on Twitter. Force-quit Mojo.
   - At ~T+5 min: threshold fires → console `[MojoActivity] eventDidReachThreshold: reblock-event-<slug>` then `Re-applied shield for expired break`. Twitter reshielded immediately.
   - If threshold misses (iOS bug): `intervalDidEnd` at ~T+16 min as the safety net.
3. **Background-but-alive case**:
   - Grant 5 min, switch to Twitter, do NOT force-quit.
   - At T+5 min: in-process `Task.sleep` should win the race. `inProcessFired` increments. Threshold fire becomes a no-op (token data already cleaned up by `handleExpiry`); `extensionNoOp` increments.
4. **Concurrent grants** (regression check for the destructive blanket-fallback the prior turn fixed):
   - Grant 5 min for Twitter, then 30 min for Instagram.
   - At T+5 min Twitter reblocks, Instagram remains unblocked. The `eventDidReachThreshold` routing must be per-token, not blanket.
5. **BGTask** (already validated in the prior fix):
   - In Xcode debugger: `e -l objc -- (void)[[BGTaskScheduler sharedScheduler] _simulateLaunchForTaskWithIdentifier:@"com.mo.MojoiOS.relockExpiredGrants"]` while a grant is active. `bgTaskFired` increments; expired grants reapply.
6. **Telemetry sanity**: After running #2-#5, open the debug section in ProfileView. Counters should reflect actual paths fired. If `armed` > 0 but no `*Fired` paths fire across multiple runs of #2, that's the diagnostic signal that iOS is broken — file an Apple FB and rely on path 5 (`.timeSensitive` notification repaint) until it's resolved. Without this telemetry, the next regression is invisible until users complain again.

## Out of scope

- Moving arming into `MojoShieldAction` extension (Option B). UX redesign + doesn't fix Step 3.
- Replacing `.timeSensitive` notification path. TAB-111 confirms it works empirically as a compositor nudge; keep it and revert the misleading "folklore" comment.
- Refactoring the host-process in-process timer into `ReblockArmer`. The `Task` handle is per-process state and the simplification isn't worth the lifetime headache.
- Persisting `TimedAccessGrant.startDate` across cold launches. Already intentionally not persisted; tokens are opaque so rehydration is impossible regardless. Shield survival via `ManagedSettingsStore` covers the gap.
- Productionizing telemetry for end-user analytics. The counters are dev-diagnostic only.

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|--------|---------|-----|------|--------|----------|
| Codex Review | `/codex review` | Independent 2nd opinion (prior turn) | 1 | CLEAR | Caught missing `UIBackgroundModes=fetch` and the activity-slot leak in `handleExpiry`. Both fixed and merged. |
| Web Research | parallel agents | Industry pattern check | 10 | CLEAR | Confirmed threshold-event reblock is the canonical OSS pattern across Opal/Jomo/ScreenZen/Habit Doom. iOS 26 `intervalDidEnd` reliability is publicly known broken. |
| Eng Review | `/plan-eng-review` | Architecture | 0 | NOT RUN | Optional — refactor is localized, contract is small. |

**VERDICT**: ready to implement. Path #3 (threshold) is the bug fix; #1, #5 are structure/observability that pay off the next time iOS regresses.
