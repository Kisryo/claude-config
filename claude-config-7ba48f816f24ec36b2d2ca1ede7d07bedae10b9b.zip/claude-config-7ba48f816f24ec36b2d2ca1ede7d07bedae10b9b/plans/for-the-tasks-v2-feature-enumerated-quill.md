# TasksV2 — spec-match audit and "training wheels off" plan

## Context

The user asked whether `/tasks-v2` matches `SPECS/TASKS_SPEC.md`. Three parallel audits agree: **the redesign is a visual prototype only.** All data lives in an in-memory `MOCK_TASKS` array in `src/pages/TasksV2/_components/useTasks.js`. No Firestore reads, no Firestore writes, no Cloud Function calls, no audit log, no email — every mutation is a `setTimeout(250ms)` against a module-level array. The author's own `docs/tasks-v2.md:40-43` acknowledges this is intentional pending "a deliberate next step" of wiring to live data.

The user has chosen:

1. **Full data-layer wiring + missing-UI gap closure** (not just a punch list).
2. **Mirror legacy Firestore paths exactly** so `/tasks` and `/tasks-v2` share the same data store; tasks created in either page show up in both.

The spec is the source of truth for behavior; the legacy implementation in `src/components/ToDoDropdown.jsx` (37,391 lines) is the source of truth for **data shape** and integration glue (audit log helper, three Cloud Function callables, recurring-instance subcollection).

---

## Verdict at a glance

| Surface | State | Severity |
|---|---|---|
| Data persistence (all of it) | Mock in-memory only | Critical |
| Cloud Function notifications (3 callables) | Not wired | Critical |
| Audit log writes | Not wired | Critical |
| Recurring instance generation | Client-side preview only | Critical |
| File attachments | UI shows "Pending upload (mocked)" literal | High |
| Comments + @-mentions | Local only, no autocomplete, no notify | High |
| Subtask persistence | Local only | High |
| Templates picker | Hardcoded 5+4 array | High |
| Impersonation read-only enforcement | Banner exists; no enforcement | High |
| Column visibility drawer | Missing | Medium |
| Column highlight color picker (5 swatches) | Missing | Medium |
| About Client column (firm admin) | Missing | Medium |
| Audit History modal w/ Restore | Tab exists, no restore | Medium |
| Reporting / CSV export / PDF export | Missing | Medium |
| Simple Task Creation Modal | One unified modal exists (intentional per docs) | OK — spec lists as open question |
| "Create & Add Another" | Missing | Low |
| Workflow "Start Full" vs "Copy First Step" | Single workflowId field only | Low |
| Concurrent-edit warning | Missing | Low |
| 10-tag cap, recurring start-date error copy | Not enforced | Low |

The full enumerated punch list lives at the bottom of this plan.

---

## Strategy

Two streams of work, runnable in parallel:

- **Stream A — Data wiring** (8 phases below). Replaces `MOCK_TASKS` and per-mutation no-ops with real Firestore + the same callables legacy uses. Each phase is a shippable PR.
- **Stream B — Spec-gap UI** (3 batches below). Adds the surfaces the prototype never built: column visibility, color picker, About Client, audit modal, reporting/export, etc.

Stream A blocks **shipping** /tasks-v2 to real users. Stream B doesn't block shipping but does block "fully matches the spec."

---

## Stream A — Data wiring (8 phases)

### Phase A1 · Extract `src/services/tasksService.js`

Lift integration glue out of `ToDoDropdown.jsx` so both /tasks and /tasks-v2 import from one place. **No behavior change in legacy** — this PR ships invisibly.

Lift these regions:

- `logTaskAuditChange` body — `ToDoDropdown.jsx:36237-36346`. Currently a `useCallback` closure passed as a prop (received at line 7288). Convert to a plain function that accepts `(changeType, details, context, currentUser)` and reconstruct the `useCallback` wrapper inside legacy with `userData` closed over.
- The three email callables — `sendFirmTaskAssignmentEmail` (`ToDoDropdown.jsx:20954`, `23332`), `sendFirmTaskCompletionEmail` (`22079-22087`), `sendTaskAssignmentEmail` (`22639-22646`). Wrap each as a named export taking a normalized payload.
- Path resolvers — there is no helper today; collection refs are reconstructed inline at lines 1686-1698, 9814, 9845, 22580, 22628, 36247-36269. Add `resolveTaskCollectionRef({ scope, organizationId, clientId, effectiveUserId })` and `resolveTaskDocRef(...)`.
- Status-patch builder — centralize the dual `completed` boolean + `status` write plus `completedAt`/`dateCompleted`/`inProgressAt` clearing (legacy pattern at `21516-21536`) as `buildStatusUpdatePatch(status, currentUser)`.

Verification: run /tasks (legacy) end-to-end; nothing should look or behave different.

### Phase A2 · Read-only listings

Replace `MOCK_TASKS` with three Firestore listeners (personal / firm / client-assigned) keyed on `effectiveUserId`. Keep mutations on the mock until A4. The hook's exposed API does **not change**.

Reference listeners: personal at `ToDoDropdown.jsx:20486-20630` (already shows the `orderBy('createdAt', 'desc'), limit(30)` pattern + warm-cache); firm at `17310, 17434-17442, 19402-19518`; client-assigned at `9844-9858`.

**Field-shape mismatch (critical):** legacy doc shape is `text` (not `title`), `deadline` (not `dueDate`), `assignedTo` (string id, not object), `clientId`, `clientName`, `completed` boolean alongside `status`. TasksV2 expects `title`, `dueDate`, `assignee` (object), `client` (object), `subtasks: { items, total, completed }`. Add a normalizer `firestoreToTaskV2(raw, scope)` in `tasksService.js`. Add the reverse `taskV2ToFirestore(patch)` here too — it'll be used in A4.

### Phase A3 · `useTask(id)` + scope plumbing

Replace the in-memory lookup with `onSnapshot(docRef)` keyed by `(scope, id)`. Pass `scope` from the parent route context to `pages/TasksV2/detail/index.jsx:42` (currently passes only `taskId`).

### Phase A4 · Core mutations

Wire `createTask`, `updateTask`, `updateStatus`, `archive`, `deleteTask`. Reference shapes:

- **createTask** — firm-task create canonical write at `ToDoDropdown.jsx:22595-22625`; personal at `~20648` (`addDoc(todosCol, ...)`). Use `serverTimestamp()` for `createdAt`. Include `enteredByType`/`enteredByUid`/`enteredByName` metadata via `buildManualUserTaskEntryMetadata`.
- **updateStatus** — use the `buildStatusUpdatePatch` helper from A1. Audit-log + recurring trigger live at `21558-21593`.
- **deleteTask** — `deleteDoc(taskRef)` for the simple case; for recurring detach use `buildDetachedRecurringTaskUpdate` (search legacy for that name).

**Optimistic updates:** do *not* mirror the legacy `setTodos(prev => prev.map(...))` pattern. The V2 store gets the snapshot back in 50–200ms via `onSnapshot`. A short pending-overlay (`pendingPatchById`) merged on read keeps the UI snappy without write-vs-snapshot races.

### Phase A5 · Bulk + CSV

`bulkUpdateStatus` and `bulkDelete` need `writeBatch` (max 500 ops/batch). Recurring-aware grouping: extract `executeRecurringAwareBulkDeleteForTaskCollection` (called at `ToDoDropdown.jsx:9815-9821`) into the service in this phase. `importTasksFromCSV` per-row creates inside one or more batches.

### Phase A6 · Comments / subtasks / attachments

- **Subtasks** — array on task doc. Patterns at `ToDoDropdown.jsx:2303, 2333, 2354, 2384, 5579, 6262`. Always `updateDoc(docRef, { subtasks: nextArray, updatedAt: serverTimestamp() })`.
- **Attachments** — array on task doc (`5890`). The V2 hook does **not currently expose `addAttachment`** — add it now. Replace the literal "Pending upload (mocked)" copy at `detail/AttachmentsTab.jsx:118,145` with real upload to Firebase Storage.
- **Comments** — legacy has no first-class comments subcollection on tasks; the V2 mock's `commentItems` array is invented. Recommend keeping it as an array on the task doc (matches existing V2 consumer expectations in `detail/CommentsTab.jsx`). Add @-mention autocomplete by reading org members from existing context (`useAccount` already exposes the org member directory).

### Phase A7 · Recurring

Read instances from `{taskPath}/recurrenceInstances` (`ToDoDropdown.jsx:1746`). On status → completed, call the `completeRecurringTask` callable (`21585-21589`). **Remove** the local "spawn child task" code at `useTasks.js:601-623` — the cloud function is now authoritative.

### Phase A8 · Audit + notifications

Wire fire-and-forget calls into every mutation. Never block the mutation on an audit/email failure (`.catch(console.warn)`). Reference shapes:

- `updateStatus` → `logTaskAuditChange('status_change', { oldStatus, newStatus, taskTitle }, ...)` (`21559-21567`).
- `updateTask` → `'field_change'` per field changed (`22189, 22248, 22315, 22356, 23250, 23310, 23624`).
- Firm-task assignment changes → `notifyFirmTaskAssignment` + per-recipient `users/{uid}/notifications` doc write (`20932`).
- Firm-task completion → `notifyFirmTaskCompletion` (`22081`).

---

## Stream B — Spec-gap UI (3 batches)

### Batch B1 · Table polish & permissions

- **Column visibility drawer** with "Reset to Default" — new `list/ColumnVisibilityDrawer.jsx`. Persist selection to `localStorage` per user.
- **Column highlight color picker** (5 swatches: Amber, Mint, Sky, Rose, Slate) — small popover above the table; persist to localStorage.
- **About Client column** — render only when `auth.firmRole === 'admin'`. Source from existing `client.name` on the row.
- **Impersonation enforcement** — `ImpersonationBanner` exists at `_components/ImpersonationBanner.jsx` but the page is not actually filtering by `effectiveUserId` or hiding advisor's own tasks. Wire `useImpersonation()` into the hook keying.
- **Client view mode** — read `ClientViewModeContext`; when active, hide advisor-only columns and disable mutation buttons. Spec §35.

### Batch B2 · Workflow + audit + integrations

- **Audit History modal** with chronological list + "Restore" on prior states. The `detail/HistoryTab.jsx` already renders entries; promote the firm-task case to a full modal (spec §74). Restore = re-apply the captured patch via `updateTask`.
- **Workflow "Start Full Workflow" vs "Copy First Step"** — split the single workflowId select in `edit/CreateForm.jsx` into a workflow picker with two action buttons. Reference legacy workflow integration in `ToDoDropdown.jsx` (search `workflowInstance`).
- **Service-meeting `dateCompleted` defaulting** — when `workflowStepId` references a service-meeting step, default `dateCompleted` to the meeting date instead of today. Spec §123.
- **Concurrent-edit warning** — detect via doc `updatedAt` mismatch; show "this task was changed" with merge / override / cancel. Spec §153.

### Batch B3 · Reporting, validation, settings

- **Reporting surface** — in-page panel: status counts, completion rate per assignee, overdue list, per-assignee load, recurring series overview. Computed client-side from current view.
- **CSV export of current view** + **PDF report** of filtered list — reuse existing `pdf-generation-server` integration if present.
- **Validation** — enforce 10-tag cap; emit the exact spec error string for recurring without start date: *"Start Date (first occurrence due) is required for recurring tasks."*; default `dateCompleted` to today when marked complete without explicit date.
- **User settings** — toggles for assignment / digest / overdue / comment emails and in-app alerts; default tab on page load (Personal / Firm / Client). Persist under user prefs.
- **"Create & Add Another"** — secondary button on creation modal that submits + resets fields without closing.
- **Templates** — replace hardcoded arrays in `edit/TemplatePickerModal.jsx:14-81` with a Firestore-backed user/firm template collection.

---

## Risks (top 5)

1. **Scope detection on read.** TasksV2 hardcodes `scope: 'personal' | 'firm' | 'client'`, but legacy infers scope from a mix of `organizationId`, `clientId`, `assignedByAdvisor`, and active-account context. Misclassifying routes a write to the wrong collection (silent data loss). Always derive scope from doc *location*, never from doc fields.
2. **Impersonation / `effectiveUserId`.** The hook today has zero awareness of impersonation; legacy uses `effectiveUserId = isViewingOtherAccount ? activeAccount.id : user.uid` (`TasksPage.jsx:18-21,113`). Without this, /tasks-v2 reads your tasks while you're impersonating a client.
3. **Optimistic-update vs. snapshot races.** V2's `useSyncExternalStore` model means a stale optimistic write can flicker over a fresh snapshot. Use a pending-overlay rather than mutating store state.
4. **Dual `completed` boolean + `status` field drift.** Easy to leave `completedAt`/`dateCompleted`/`inProgressAt` set after un-completing. Centralize in `buildStatusUpdatePatch`.
5. **`tasks_cache_*` sessionStorage poisoning.** `TasksPage.jsx:29-36` clears it only on impersonation. /tasks-v2 mutations would otherwise leave a stale cache; either drop the cache when V2 is the primary route or have V2 mutations clear it on every write.

---

## Critical files

**Modify**

- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/_components/useTasks.js` — primary swap target (801 lines of mock).
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/_components/useTaskMutations.js` — currently a 1-line re-export; will absorb mutation hooks.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/list/index.jsx`, `list/FilterBar.jsx`, `list/TasksTable.jsx` — column visibility, highlight color, About Client.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/detail/AttachmentsTab.jsx` — remove "Pending upload (mocked)" literals at lines 118, 145.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/detail/HistoryTab.jsx` — promote to firm-task audit modal w/ Restore.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/edit/TemplatePickerModal.jsx` — replace hardcoded arrays at lines 14-81.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/edit/CreateForm.jsx` — workflow split, "Create & Add Another", recurring start-date error copy, 10-tag cap.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/TasksV2Layout.jsx` — wire `useImpersonation()`, `useClientViewMode()`.
- `/Users/johnathanmo/SAMWEALTH-new/src/components/TasksPage.jsx` — cache invalidation parity (lines 29-36).

**Create**

- `/Users/johnathanmo/SAMWEALTH-new/src/services/tasksService.js` (Phase A1).
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/list/ColumnVisibilityDrawer.jsx`.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/list/ColumnHighlightPicker.jsx`.
- `/Users/johnathanmo/SAMWEALTH-new/src/pages/TasksV2/reporting/` (B3).

**Reference only (do not edit broadly)**

- `/Users/johnathanmo/SAMWEALTH-new/src/components/ToDoDropdown.jsx` (37,391 lines). Key regions: `7288-7352`, `17310-19518`, `20486-20630`, `21500-21606`, `22580-22650`, `22079-22087`, `22639-22646`, `23332-23336`, `36237-36346`.

---

## Verification

End-to-end smoke test after each phase:

1. **A1** — open /tasks (legacy); create, complete, comment, delete, recurring task. All flows behave identically to before. No console errors. Audit entries still appear; emails still fire.
2. **A2** — open /tasks-v2 in two windows side by side with /tasks; the same tasks appear under each tab (personal / firm / client). Filters and search behave on real data. Listings update live when /tasks creates a task.
3. **A3** — clicking a row in either /tasks or /tasks-v2 opens the same task; edits made in legacy reflect in V2's drawer in real time.
4. **A4** — every mutation persists across page refresh and across the two routes. `tasks_cache_*` invalidation works.
5. **A5** — bulk-complete 100 tasks; CSV import 200 rows; both succeed within Firestore batch limits.
6. **A6** — add a subtask, comment with @-mention, upload an attachment; all three persist and appear at /tasks too. Mentioned user gets a notification.
7. **A7** — complete a recurring task; the next instance shows up at /tasks (proves cloud function ran).
8. **A8** — assign a firm task; assignee receives email; audit log shows the change at /tasks.
9. **B1–B3** — work through the spec section-by-section using `SPECS/TASKS_SPEC.md` as a checklist; compare /tasks-v2 against the spec text line-by-line.

Test commands:

```bash
npm run dev                # local Vite
npm run lint               # eslint --max-warnings 0 (must stay clean)
npm run test:rules         # firestore.rules.test.cjs (security gate)
```

For each PR also run /tasks (legacy) flows to confirm the extraction in Phase A1 (and any reference-only edits to `ToDoDropdown.jsx`) didn't regress.

---

## Punch list (full)

Cross-reference for `SPECS/TASKS_SPEC.md`:

| Spec section | TasksV2 status | Phase to fix |
|---|---|---|
| §27-35 Roles | Partial — only firm-staff vs client; no admin/super-admin/impersonation/client-view enforcement | B1 |
| §40-44 Entry points | `/tasks-v2` route exists; deep links from notifications missing | A8 |
| §52-63 Main page | Most surfaces present; column visibility drawer, color picker, About Client column missing; CSV/PDF export missing | B1, B3 |
| §65-78 Modals & drawers | Most present; Audit Modal w/ Restore missing; Column Visibility Drawer missing; Simple Modal intentionally collapsed (per docs) | B2, B1 |
| §82-89 Author flow | Recurrence preview + scheduling + templates present; "Create & Add Another" missing; workflow Start-Full-vs-Copy-First-Step missing | B3, B2 |
| §93-98 Alternate paths | CSV present (mock-persistence); from-workflow / AI / notes missing | A5, B2 |
| §102-110 Variants | All variants present in data shape | — |
| §114-124 Conditional logic | Recurrence preview present; scheduled→pending activation missing; service-meeting `dateCompleted` defaulting missing; skipIfOpenInstance missing; parent/subtask completion confirm missing | A7, B2 |
| §128-141 Lifecycle | Statuses defined; dual `completed` boolean coexists in mock; centralize in service | A1, A4 |
| §145-153 Post-action | Animations present; concurrency warning missing; recurring on-completion handled by cloud function only after A7 | A7, B2 |
| §157-167 Reporting | All missing | B3 |
| §171-177 Validation | Title required ✓; 10-tag cap not enforced; recurring start-date error copy wrong; completion-date defaulting missing | B3 |
| §181-196 Notifications | All missing (Mailgun, in-app, prefs, auto-alert read-only) | A8, B3 |
| §200-208 Integrations | Workflows light; AI Notetaker / AI Chat / Notes / Vault / org-level audit missing; Mailgun missing | A8, B2 |
| §212-225 Permissions | hasEditAccess gating missing; impersonation rules missing; client view mode missing | B1 |
| §229-236 Settings | All missing except theme inheritance | B3 |

---

## What success looks like

When this plan is fully executed:

- `MOCK_TASKS`, `SAMPLE_USERS`, `SAMPLE_CLIENTS`, the literal `"Pending upload (mocked)"` copy, and the hardcoded template arrays are all gone from `src/pages/TasksV2/`.
- A grep for `mock|fake|placeholder|TODO|stub` inside `src/pages/TasksV2/` returns zero results outside of comments explaining what *was* mocked.
- A user can create a task at /tasks, refresh, open /tasks-v2, and see the same task with full history, comments, recurring status, and attachments.
- Every spec section in `SPECS/TASKS_SPEC.md` either has a corresponding implementation in `src/pages/TasksV2/` or is explicitly listed as deferred under the spec's own "Open questions."
