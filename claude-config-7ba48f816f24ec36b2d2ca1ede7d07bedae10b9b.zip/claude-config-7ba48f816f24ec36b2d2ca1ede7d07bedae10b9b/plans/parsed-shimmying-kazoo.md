# Backtest Visualizer — Interactive Strategy Replay

## Context

The user is iterating on trading strategies for IMC Prosperity 4 and has no way to evaluate performance locally — only by uploading to the IMC simulator. The CSV backtest data (3 days of order book snapshots + market trades) exists but there's no tool to visualize it or replay the strategy against it. The CHAMPION_TAKEAWAYS.md explicitly says: "Step through EVERY timestamp in the visualizer — find where you left money on the table."

**Goal:** Build an interactive plotly dashboard that replays `trader_pepper_ash.py` on the CSV data, tracks simulated position and P&L, and visualizes everything needed to debug and improve the strategy.

---

## Implementation: Single file `ROUND1/visualizer.py`

### Step 1: Install plotly

```bash
pip3 install plotly
```

### Step 2: Data loading functions

**`load_prices(round_dir) -> pd.DataFrame`**
- Read all 3 `prices_round_1_day_*.csv` files (semicolon-delimited, `na_values=['']`)
- Concatenate, compute: `spread`, `wall_bid` (deepest non-null bid), `wall_ask` (deepest non-null ask), `wall_mid`, `total_bid_depth`, `total_ask_depth`

**`load_trades(round_dir) -> pd.DataFrame`**
- Read all 3 `trades_round_1_day_*.csv`, add `day` column from filename
- Drop useless `buyer`, `seller`, `currency` columns

### Step 3: Strategy simulation engine

**`simulate_day(day_prices: pd.DataFrame, day_trades: pd.DataFrame) -> pd.DataFrame`**

This is the core. For each timestamp in the day:

1. Build `OrderDepth` from CSV row (bid_price_1-3 / bid_volume_1-3, ask_price_1-3 / ask_volume_1-3)
2. Build `TradingState` with current timestamp, order_depths, position, and traderData
3. Call `Trader().run(state)` — import the actual strategy class from `trader_pepper_ash.py`
4. Match returned orders against the order book:
   - **Buy orders** at price >= best_ask: filled at ask price (aggressive take)
   - **Sell orders** at price <= best_bid: filled at bid price (aggressive take)
   - Passive orders (inside the spread): assume NOT filled for conservative estimate
5. Update position based on fills
6. Compute mark-to-market P&L: `realized_pnl + (position * mid_price - position * avg_entry)`

Track per-timestep: timestamp, position (per product), orders placed, fills, realized P&L, unrealized P&L, total P&L, fair value, reservation prices, and strategy signals.

**Key design decision — use the actual Trader class:**
- Import `Trader` from `trader_pepper_ash.py` directly (the fallback dataclasses make this work outside the simulator)
- This guarantees the simulation matches the real strategy exactly
- The `traderData` string flows between timesteps just like in the real simulator

**Fill simulation approach:**
- Walk our orders against the book levels. For each buy order at price P, fill against asks <= P. For each sell order at price P, fill against bids >= P.
- Cap fills at available volume at each level
- This is conservative (ignores passive fill probability) but accurate for aggressive takes, which is where most P&L comes from

### Step 4: Signal extraction

After simulation, extract per-timestep columns for plotting:
- **PEPPER**: `fair`, `buy_reservation`, `sell_reservation`, `target_position`, `remaining_drift`
- **ASH**: `wall_mid`, `ash_ema`, `take_buy_threshold`, `take_sell_threshold`, `inv_shift`

These come from re-computing the strategy's internal variables (or capturing them during simulation by instrumenting the Trader class — add a `_last_signals` dict that the plot code reads after each `.run()` call).

### Step 5: Plotly dashboard layout

**Interactive HTML** saved to `ROUND1/dashboard.html`, auto-opened in browser.

Use `plotly.subplots.make_subplots()` with **6 rows, 2 columns** (PEPPER left, ASH right).

| Row | PEPPER (left) | ASH (right) |
|-----|--------------|-------------|
| 1 | Price + Fair Value + Fills | Price + Fair Value + Fills |
| 2 | Position (actual vs target) | Position (actual vs soft limit) |
| 3 | Cumulative P&L | Cumulative P&L |
| 4 | Spread + Edge Opportunities | Spread + Edge Opportunities |
| 5 | Book Depth (bid vs ask volume) | Book Depth (bid vs ask volume) |
| 6 | Day Comparison (all 3 days P&L) | Day Comparison (all 3 days P&L) |

Row heights: `[2, 1, 1, 1, 1, 1]` — price panel is tallest.

**Row 1 — Price + Fills (most important):**
- Shaded bid-ask band (bid_price_1 to ask_price_1)
- Mid price line (thin gray)
- Strategy fair value line (blue dashed)
- Buy/sell reservation lines (green/red dashed) — PEPPER only
- Simulated fills: green up-triangles (buys) and red down-triangles (sells), sized by quantity
- Market trades: small gray circles for reference
- PEPPER: vertical lines at ts=900k (unwind) and ts=975k (force exit)

**Row 2 — Position:**
- Actual position line (blue)
- Target position line (orange dashed) — PEPPER: ramp from 50→0; ASH: soft limit ±20 bands
- Fill markers at the timestamps where fills change position

**Row 3 — Cumulative P&L:**
- Total P&L line (black)
- Realized P&L (green fill)
- Unrealized P&L (blue fill, can go negative)
- This directly answers "what's doing well and what's not"

**Row 4 — Spread + Edge:**
- Spread width as stepped line
- Overlay: "edge" = distance between our reservation and best opposing price (positive = opportunity). Green bars for buy edge, red for sell edge.

**Row 5 — Book Depth:**
- Bid depth (green, below zero) vs ask depth (red, above zero) as area charts
- Shows liquidity availability — thin books mean slippage risk

**Row 6 — Day Comparison:**
- Overlay cumulative P&L curves for all 3 days on same axes
- Quick visual: is the strategy consistently profitable? Which day is best/worst?

**Plotly interactivity features:**
- Shared x-axis zoom (zoom on one panel zooms all)
- Hover tooltips showing exact values at each timestamp
- Legend toggles to show/hide traces
- Range slider on the bottom for quick navigation

### Step 6: Day selector

Add a dropdown to switch between viewing day -2, -1, or 0 for rows 1-5. Row 6 always shows all 3 days overlaid. Default to day 0 (most recent).

### Step 7: Summary stats

Print a text summary to the terminal when the script runs:
```
=== Day 0 Summary ===
PEPPER: P&L = +4,521  |  Fills: 87 buys, 42 sells  |  Max position: 50
ASH:    P&L = +1,230  |  Fills: 156 buys, 148 sells |  Max position: 32
TOTAL:  P&L = +5,751
```

---

## Files to create/modify

| File | Action |
|------|--------|
| `ROUND1/visualizer.py` | **Create** — single-file visualizer (~500 lines) |

No other files modified. The visualizer imports `Trader` from `trader_pepper_ash.py` directly.

---

## Verification

1. `pip3 install plotly` (if not already installed)
2. `cd /Users/johnathanmo/prosperity4 && python3 ROUND1/visualizer.py`
3. Confirm:
   - Terminal prints per-day P&L summary for both products
   - `ROUND1/dashboard.html` is created and auto-opens in browser
   - Dashboard has 12 panels (6 rows x 2 columns), all populated with data
   - Zoom, hover, and legend toggles work
   - Simulated fills appear on the price chart as colored triangles
   - Position chart shows accumulation → hold → unwind for PEPPER
   - P&L curves show cumulative profit over the day
   - Day comparison panel overlays all 3 days
