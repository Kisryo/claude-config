# Logic page: add graph view, lift edit affordances

## Context

`/forms/<flowId>/logic` today is **list-only**. `src/pages/FormEditor/FormLogicView.jsx` renders a narrow (`max-w-3xl`) page that delegates to `src/components/forms/editor/LogicGraphView.jsx`, which — despite its name — is an ordered `<ol>` of questions with inline rule summaries and warning badges. The flow-level cycle + reachability analysis in `src/components/forms/editor/logicAnalysis.js` is solid (DFS for cycles, BFS reachability from Q1) and already produces `edgesByIndex` — a fully formed edge list the list view currently throws away.

Three gaps the user called out:

1. **No graph view.** `reactflow@11.11.4` is already in `package.json` but unused. For any form with ≥ 5 questions or more than a handful of `skip_to` rules, the list representation loses the shape of the flow — you can't see fan-in, fan-out, or a cycle at a glance.
2. **Read-only.** The existing authoring UI (`src/components/forms/editor/LogicEditor.jsx`) lives as a popover on each question card inside `/forms/<flowId>/questions`. From the logic page there is no way to edit a rule — you have to switch tabs, find the question, open its popover. The popover body is already factored as a separate exported-style component (`LogicEditorBody` at `LogicEditor.jsx:292`), so reusing it is cheap.
3. **Cramped & low-affordance.** `max-w-3xl`, no summary counts, no way to jump from a `Skip to "X"` rule to X's card, `type` shown as raw slug (`short_text`), no filter/search, plain `<ol>` is the only scroll surface.

We keep the list view and **add a graph view as a toggle** — not a replacement. Graph for exploration, list for audit.

This change runs in a **new git worktree** and merges back to `ui/form-redesign`.

## Approach

### 0. Worktree

Execute under `isolation: "worktree"` so the editor's current branch stays clean. After the work is done and verified, merge back to `ui/form-redesign`.

### 1. Formalize the edge list in `logicAnalysis.js`

`analyzeFlow()` already computes `edgesByIndex`. Right now each edge is `{ kind, target?, source }` where `kind` is `'sequential' | 'skip_to' | 'end_quiz' | 'redirect'` and `source` is `{ kind: 'rule', index } | { kind: 'fallback' } | { kind: 'implicit' }`. The graph view needs one more thing: a stable edge id and a human-readable label so edges can be keyed in React and shown on hover.

Change `logicAnalysis.js` minimally: ensure every edge carries `{ id, from, kind, target?, source }` where `from` is the source question index and `id` is `${from}->${kind}:${target ?? terminal}:${source.kind}:${source.index ?? ''}`. The existing DFS / BFS code only reads `edge.target`, so adding fields is non-breaking.

### 2. `FormLogicView.jsx` — widen, add view toggle, thread context

- Drop `max-w-3xl`; use `max-w-[1240px]` to match the rest of the editor surfaces.
- Add a `view` state (`'list' | 'graph'`) via `useState`, default `'list'` (keeps current behavior for existing users). Persist across refreshes with `localStorage` key `forms.logic.view` — ~10 lines; nothing fancy.
- Pull `formId`, `organizationId` from `useOutletContext()` (already provided by the centralized layout from the previous change).
- Add a header row with:
  - Title + description (current copy).
  - Counts pill: `{questions} questions · {rules} rules · {warnings} warnings` (warnings = cycles + unreachable).
  - Segmented control: `List` / `Graph` (reuse the same `SegmentedControl` styling from `FormSettingsView.jsx:232`, *inline* — do not export it; it's 15 lines).
- Conditionally render `<LogicListView>` or `<LogicFlowGraph>`. Both receive `{ questions, onEditQuestion }`.
- A single `onEditQuestion(questionId)` handler opens a `LogicEditorDrawer` that wraps `LogicEditorBody`. On change, call `updateQuestion({ organizationId, flowId: formId, questionId, patch })` exactly like `FormQuestionsEditor.jsx:110` does. No optimistic overlay needed — the question-level overlay lives inside `FormQuestionsEditor` only; the logic page just saves and lets the Firestore snapshot rehydrate (the layout-level overlay from the previous task doesn't apply to `customQuestions` arrays).

### 3. Rename `LogicGraphView.jsx` → `LogicListView.jsx`, keep its render mostly as is

The existing name is misleading now that a real graph view exists next to it. File rename + import update; nothing more. Inside, three small improvements that don't bloat the diff:

- Replace the raw `q.type` slug with a humanized label (e.g., `short_text` → `Short text`). There's already a type-to-label map on question cards — grep `QUESTION_TYPE_LABELS` / similar in `src/components/forms/editor/` and reuse. If there truly isn't one, inline a 10-entry lookup in this file; do not create a new module.
- When an action is `skip_to`, make the label a button that calls `onEditQuestion(targetId)` so the drawer opens focused on the target — solves the "jump from rule to target" UX gap without implementing scroll-to-row anchors.
- Each question card gains a small `Edit logic` button (top-right of the card, next to the badges) that fires `onEditQuestion(q.id)`. Uses the same `BranchIcon` the card-based editor uses.

### 4. New `LogicFlowGraph.jsx` — ReactFlow canvas

File: `src/components/forms/editor/LogicFlowGraph.jsx`. Props: `{ questions, onEditQuestion }`.

- Import from `reactflow` (already installed). Import `reactflow/dist/style.css` **once** at the top of this file — it's tree-shake-safe and scoped.
- Compute nodes and edges in `useMemo`:
  - **Nodes**: one per question. Position at `{ x: (i % 3) * 280, y: floor(i / 3) * 140 }` — simple 3-column grid keyed by index. This is the "v1 auto-layout" — don't pull in `dagre`. Question order is the author's mental model already; respecting it produces a readable layout at the cost of not being optimal. If the form has >18 questions we can revisit.
  - **Edges**: reuse `analyzeFlow(list).edges` — each `edgesByIndex[i]` becomes outgoing ReactFlow edges. Hide `sequential` edges by default (they clutter; a toggle in the toolbar re-shows them). Render `skip_to` as a solid teal edge, `end_quiz` / `redirect` as terminal markers on a dashed grey edge stub to a synthetic "end" node (one per kind — so at most two terminal nodes total).
  - Nodes in a cycle get an amber border; unreachable nodes get the dashed/opacity-60 treatment (mirror list view).
- Custom node renderer: a small `QuestionNode` component that shows number badge, truncated label, humanized type, rule count badge, and warning badges. Keeps styling consistent with the list view (reuse the same Tailwind classes).
- Click a node → `onEditQuestion(node.id)`. Click an edge → open the drawer on the *source* question (editing the rule that produced the edge).
- Include `<Background />`, `<Controls />`, `<MiniMap pannable zoomable />` from reactflow. Fit canvas to `h-[70vh]` with a rounded border matching the rest of the page's glass cards.
- A small toolbar strip above the canvas: `Show sequential edges` checkbox, `Fit view` button (calls `useReactFlow().fitView()`). Keep it to ~6 lines of JSX.

### 5. New `LogicEditorDrawer.jsx`

File: `src/components/forms/editor/LogicEditorDrawer.jsx`. A slide-in right-side drawer (fixed positioned, `w-[560px]`, full height, `translate-x-full` when closed) hosting `LogicEditorBody` from `src/components/forms/editor/LogicEditor.jsx:292`.

- Props: `{ open, questionId, questions, onClose, onChange }` where `onChange(patch)` fires `updateQuestion(...)` in the parent.
- Export `LogicEditorBody` from `LogicEditor.jsx` (it's currently only used internally by the popover in the same file) — single-line change.
- Close on backdrop click, `Escape`, and an explicit X button. Match the liquid-glass look in `DESIGN.md` (`bg-white/90 backdrop-blur-xl`, the same shadow stack the popover already uses, already visible at `LogicEditor.jsx:446`).

### 6. Minor: humanize question types

Search for an existing type-label map:

```
rg -n "QUESTION_TYPE|questionTypeLabel|TYPE_LABEL" src/components/forms/editor src/services
```

Reuse if found. Otherwise inline a 10-entry map in `LogicListView.jsx` and `LogicFlowGraph.jsx` — duplicated for simplicity (3 call sites max; extraction is premature).

## Files to modify / add

- **Modify** `src/components/forms/editor/logicAnalysis.js` — add `id` and `from` to each edge; otherwise unchanged.
- **Modify** `src/pages/FormEditor/FormLogicView.jsx` — widen, add header + view toggle + drawer wiring, pull `formId`/`organizationId` from outlet context.
- **Rename + modify** `src/components/forms/editor/LogicGraphView.jsx` → `LogicListView.jsx`. Update its one consumer (`FormLogicView.jsx`). Add edit button and click-to-target affordances.
- **Modify** `src/components/forms/editor/LogicEditor.jsx` — export `LogicEditorBody`.
- **Add** `src/components/forms/editor/LogicFlowGraph.jsx` — ReactFlow canvas.
- **Add** `src/components/forms/editor/LogicEditorDrawer.jsx` — right-side drawer.

No new npm dependencies. No changes to Firestore schema. No changes to `conditionalLogic.js` runtime.

## Existing functions to reuse

- `analyzeFlow` — `src/components/forms/editor/logicAnalysis.js:44`. Both views consume its output; the graph view uses `edgesByIndex` directly.
- `LogicEditorBody` — `src/components/forms/editor/LogicEditor.jsx:292`. Re-exported, mounted inside the drawer.
- `updateQuestion` — `src/services/formManagementService.js`. Same call site pattern as `FormQuestionsEditor.jsx:110`.
- `describeCondition` / `describeAction` — currently local to `LogicGraphView.jsx`. Lift to a small `logicLabels.js` adjacent to `logicAnalysis.js` so both list and graph views share them. One new file, ~40 lines.
- `useOutletContext` form-editor contract — `{ form, formId, organizationId, applyLocalPatch, revertLocalPatch }` as set up in the previous task. Only `form`, `formId`, `organizationId` are needed here.
- Design tokens — follow `DESIGN.md`: primary `#0F2D26`, title font `'Space Grotesk'`, glass surfaces (`bg-white/70 backdrop-blur-xl`), shadow recipe `shadow-[inset_0_1px_0_rgba(255,255,255,0.9),_0_1px_2px_rgba(15,23,42,0.04),_0_8px_20px_-12px_rgba(15,45,38,0.12)]` — already used by the list cards.

## Verification

From the new worktree:

1. `npm install` (no-op if lockfile has reactflow already). `npm run dev`.
2. Open `/forms/<flowId>/logic` on a form with ≥ 4 questions and at least one `skip_to` rule.
3. **List view**: header counts match reality, humanized types render, clicking a `Skip to "X"` label opens the drawer focused on X, edit button next to each card opens the drawer focused on that question.
4. **Toggle to Graph view**: canvas renders, one node per question, `skip_to` edges visible, sequential edges hidden by default, toolbar toggle re-reveals them. Fit-view button recentres.
5. Cycles render with amber borders on nodes + amber edge highlighting; unreachable nodes are dashed and dimmed.
6. Click a node → drawer opens → edit a rule → save → drawer stays open, rule updates, graph re-renders on next Firestore snapshot. Close drawer via Escape, backdrop, and X.
7. Refresh page — last-selected view persists via `localStorage`.
8. `npm run lint` clean on changed files (pre-existing `react/prop-types` errors in unrelated files are not this PR's problem — baseline check by stash/lint/pop if in doubt).
9. Regression: `/forms/<flowId>/questions` still works; `LogicEditor` popover on question cards still works (we only *added* an export, didn't change the signature).
10. Mobile width (< 700 px) — header wraps, view toggle stays tappable, graph canvas scrolls horizontally. Not perfect, but not broken.

## Merge back

Once verified:

```
git checkout ui/form-redesign
git merge --no-ff <worktree-branch>
```

Delete the worktree with `git worktree remove`. No force-push, no rebase on main — this branch is still in active use.
