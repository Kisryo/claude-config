# Agentation Toolbar Setup

## Context

Install and wire the `agentation` npm package so the in-app annotation toolbar is available during local development. Agentation overlays a toolbar that lets the user click/drag on UI elements and leave annotations that sync back to Claude Code (via an MCP server) as actionable feedback — useful while redesigning forms on the `23jmo/form-redesign` branch.

The `/agentation` skill's instructions assume **Next.js** (App Router or Pages Router). This project is a **Vite + React 18 SPA** (`package.json:5` `"type": "module"`, `vite` dev/build scripts, `react: ^18.3.1`), so the insertion point and env gate differ — plan adapts accordingly.

## Current state (verified)

- `agentation` is **not** a dependency (`package.json:35-127`).
- No existing `Agentation` import in `src/` (grep returned no matches).
- Package manager is **npm** (`package-lock.json` at repo root; no yarn/pnpm lockfile alongside it).
- Render root is `src/main.jsx:679-683`:
  ```jsx
  ReactDOM.createRoot(document.getElementById('root')).render(
      <App />
  )
  ```
- React 18 is present — Agentation's peer requirement is satisfied.

## Approach

### 1. Install the package

```
npm install agentation
```

This will write to `package.json` and `package-lock.json`.

### 2. Mount the component in `src/main.jsx`

Edit `src/main.jsx` in two places:

**a. Add the import** near the existing `import App from './App'` on line 671:

```jsx
import App from './App'
import { Agentation } from 'agentation'
import './index.css'
```

**b. Render it as a sibling of `<App />` inside the existing `createRoot().render(...)` call at lines 679-683**, gated by Vite's `import.meta.env.DEV` so it is statically stripped from production bundles:

```jsx
ReactDOM.createRoot(document.getElementById('root')).render(
  <>
    <App />
    {import.meta.env.DEV && <Agentation />}
  </>
)
```

**Why `import.meta.env.DEV` instead of `process.env.NODE_ENV === 'development'`** (what the skill instructions show): Vite replaces `import.meta.env.DEV` at build time with a literal `true`/`false`, so dead-code elimination drops the `Agentation` import from prod output entirely. `process.env.NODE_ENV` works too (Vite shims it) but is less idiomatic and can leave the import dangling in some bundler configs.

**Why sibling-of-`<App />` instead of inside `App.jsx`**: keeps the toolbar outside the `BrowserRouter`/`AuthProvider`/etc. providers, so it never unmounts on route transitions, and avoids polluting `App.jsx` (which already has ~60+ imports).

**Why a Fragment wrapper**: `createRoot().render` accepts a single node; the fragment is the minimal change.

### 3. Verify

- `npm run dev` — app should boot on the usual Vite port with the Agentation toolbar visible as a floating overlay.
- Load any route (e.g. `/forms`) and confirm the toolbar does not unmount on navigation.
- `npm run build` — confirm build still succeeds. Optionally grep `dist/assets/*.js` for `Agentation` to confirm tree-shaking (should be absent since `import.meta.env.DEV` is `false` in production).
- Production-like preview: `npm run preview` should serve without the toolbar.

### 4. Recommend MCP server setup (verbal only, not part of this edit)

After the component is wired, tell the user that for annotations to flow back to Claude Code they need the companion MCP server. Two options:

- **Universal:** `npx add-mcp` → add `agentation-mcp`.
- **Claude Code only:** `npx agentation-mcp init`.

Then restart Claude Code so the MCP server is loaded. `npx agentation-mcp doctor` verifies setup. MCP runs on port 4747 by default. This step does not modify repo files — it writes to the user's Claude Code / MCP config.

## Files to change

| File | Change |
| --- | --- |
| `package.json` | `npm install agentation` adds dependency |
| `package-lock.json` | auto-updated by npm |
| `src/main.jsx` | add `Agentation` import + render sibling gated on `import.meta.env.DEV` |

No other files touched.

## Out of scope

- No changes to `App.jsx`, routing, or any providers.
- Not adding Agentation to the functions/ sub-packages or any of the sibling server packages — those have their own `package.json` files and are unrelated Node services.
- MCP server installation is a user-side configuration step, not a repo edit.
