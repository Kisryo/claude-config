# git-graph — Spec

A desktop app for visualizing a messy git repo: every branch, every commit, laid out horizontally with rich filtering, multi-branch highlight, and quick insights (merge base, ahead/behind). Read-only, local-first, light theme.

## Context

Johnathan has a repo with dozens of branches — some active, many forgotten, some with no common ancestor to `main`. Standard tools (GitHub, GitKraken) are either too busy, too slow on large local repos, or don't cluster unrelated branches. This tool exists to make a messy repo legible: cluster unrelated history, filter noise, and let him pick 2–5 branches and see exactly how they relate.

## Stack

- **Shell:** Tauri 2.x
- **Renderer:** React + TypeScript + Vite
- **Styling:** Tailwind + CSS variables (light-only palette, Linear/Height-inspired)
- **Backend:** Rust (`git2` via `libgit2`) in Tauri commands
- **Graph math:** Rust (topo sort, lane assignment, clustering, merge-base)
- **Graph render:** SVG components in React (medium-scale target; no canvas needed)
- **State:** Zustand (UI state) + Tauri invoke for data
- **Persistence:** Tauri plugin-store (JSON) for recent repos, pinned branches, saved views

## Data model (Rust → TS)

```ts
type Commit = {
  sha: string
  shortSha: string
  parents: string[]
  author: { name: string; email: string }
  timestamp: number        // unix seconds
  summary: string
  body?: string
  refs: string[]           // branch/tag names pointing here
}

type Branch = {
  name: string
  kind: 'local' | 'remote' | 'tag'
  tipSha: string
  upstream?: string
  lastActivity: number
  isMerged: boolean        // merged into default branch
  aheadOfDefault: number
  behindDefault: number
  clusterId: string        // id of the disjoint-history cluster it belongs to
}

type GraphLayout = {
  commits: Array<Commit & { x: number; laneY: number; clusterId: string }>
  edges: Array<{ from: string; to: string; color: string }>
  clusters: Array<{ id: string; rootSha: string; branchCount: number; label: string }>
  defaultBranch: string
}
```

## Repo sources (v1)

1. **Local filesystem path** — Tauri file-picker opens a dialog; validate `.git` exists; open with `git2::Repository::open`.
2. **Public GitHub URL** — paste a `github.com/owner/repo` URL; clone into `$APP_CACHE/clones/<owner>-<repo>` with **shallow filter** (`--filter=blob:none --no-checkout`). Reuse cached clone if present; manual refresh runs `git fetch --all`.

Private repos and other git hosts are **out of v1**.

## Git engine (Rust)

Single `GitReader` struct wrapping a `git2::Repository`. One Tauri command per read operation:

- `open_repo(path) -> RepoHandle`
- `clone_github(url) -> RepoHandle`  (shallow, cached)
- `list_refs(handle) -> { branches, tags }`
- `walk_commits(handle, since?: ts) -> Vec<Commit>`  (uses `Revwalk` with `TOPOLOGICAL | TIME`)
- `compute_layout(handle, filters) -> GraphLayout`
- `merge_base_many(handle, shas: Vec<String>) -> Option<String>`
- `ahead_behind(handle, a, b) -> { ahead, behind }`
- `dangling_commits(handle) -> Vec<Commit>`  (via `Odb` walk + reachability check)

All layout computation (lane assignment, clustering, coloring) happens in Rust; renderer receives final coordinates.

## Graph layout algorithm

1. **Enumerate tips** — all local branches, all remote branches, all tags, plus detached HEAD and dangling commit tips.
2. **Revwalk** from every tip; collect unique commits.
3. **Cluster** by weakly-connected components of the commit DAG (parent edges, undirected). Each WCC = one cluster; the cluster containing the default branch is cluster 0.
4. **Topological X-axis** — within each cluster, `x = topoIndex(commit)`. Clusters are laid out stacked (cluster 0 on top). Time labels shown on ticks + on hover. No real-time scaling (density > realism).
5. **Lane assignment (Y)** — greedy lane-reuse per cluster: walk commits in topo order; assign each commit to the lowest lane free at its X range. `main` (or cluster root) gets lane 0 and keeps it.
6. **Edges** — straight line for same-lane parent; diagonal for lane-switch (curve at parent.x).
7. **Coloring** — semantic:
   - `main` / default branch: **blue**
   - Active (activity <30d, unmerged): **green**
   - Stale (>90d, unmerged): **orange**
   - Merged: **gray/dashed**
   - User's commits (match `git config user.email`): **bolder stroke**
   - Tags: purple ribbon marker
8. **Dangling commits** rendered as a faint 'Unreachable' cluster at the bottom, collapsed by default.

## UI layout

```
┌──────────────────────────────────────────────────────────┐
│ Topbar: [Repo dropdown ▾] [🔍 search] [Cmd+K] [⚙ filters]│
├──────────┬───────────────────────────────────────────────┤
│ Sidebar  │  Selection chip-bar: [feat-a ✕][feat-b ✕]    │
│ Branch   ├───────────────────────────────────────────────┤
│ inventory│                                                │
│          │       Horizontal graph (SVG, pannable)         │
│ - filters│       ─────────────────────────────            │
│ - pins   │       ──╲────────╱──────────────               │
│ - list   │         ╲──────╱                               │
│          │                                                │
│          │                                    [minimap]   │
├──────────┴───────────────────────────────────────────────┤
│ Commit detail drawer (slides up on click)                │
└──────────────────────────────────────────────────────────┘
```

### Sidebar — branch inventory
- List every branch with: colored dot, name, last-activity relative date, ahead/behind vs default, merged pill, pin star.
- **Filters** (must-haves): merged/unmerged/any, author, name contains/regex. Stale-days is a stretch goal.
- **Pinned branches** float to top, persisted per repo.
- Clicking a branch selects it. Cmd/Ctrl-click adds to multi-selection.

### Graph canvas
- Pan (drag), scroll-to-zoom (semantic: zoom out hides labels first, then commit messages, then refs).
- Click a **ref label** or **lane** to toggle-select that branch.
- Cmd/Ctrl-click refs for multi-select.
- Hover a commit → tooltip (subject + author + relative date) + fade-highlight the commit's full ancestry path back to cluster root.
- Click a commit → opens commit detail drawer.
- Collapsible cluster headers above each cluster band: `▾ Cluster 2 · 8 orphan branches`.

### Highlight behavior
- **Dim mode** (default): unselected commits/edges → 15% opacity.
- **Isolate mode** (toggle, keyboard `H`): hide everything outside the union of selected branches' ancestries + their pairwise merge bases.
- Selection chip-bar above graph shows selected branches; each chip has color + X. Empty selection = normal view.
- When ≥2 branches selected, an **insight panel** docks to the right:
  - Common merge base (SHA + date + 'jump to' button).
  - Pairwise ahead/behind matrix.

### Commit detail drawer
- Subject, body, author, committer, date, parent SHAs (clickable), refs.
- Actions: **Copy SHA**, **Open in GitHub** (if origin is github.com), **Open in VS Code** (`vscode://file/<repoPath>?ref=<sha>`).
- **No in-app diff in v1.** 'Open in GitHub' deep-links to `https://github.com/<owner>/<repo>/commit/<sha>`.

### Command palette (Cmd+K)
- Fuzzy across: branches, commit messages, commit SHAs (prefix), authors.
- Top actions: **Open repo…**, **Recent repos** (from persistence), **Apply view: <name>**.
- `/` key focuses the inline search input in the topbar as an alternative.

### Keyboard
- `Cmd/Ctrl+K` — palette
- `/` — focus search
- `Cmd/Ctrl+Click` on branch — multi-select
- `H` — toggle dim/isolate
- `Esc` — clear selection
- `R` — manual refresh

## Persistence (tauri-plugin-store)

```json
{
  "recentRepos": [{ "path": "...", "displayName": "...", "lastOpened": 1714... }],
  "perRepo": {
    "<repoId>": {
      "pinnedBranches": ["main", "feat-big-refactor"],
      "savedViews": [
        { "name": "My WIP", "filters": { "author": "jmo@...", "merged": false }, "highlight": [] }
      ]
    }
  }
}
```

No filter state is auto-restored — only user-named saved views.

## Edge cases to render explicitly

- **Detached HEAD** — dedicated `HEAD` pill, distinct from branch labels.
- **Orphan branches** — natural fallout of cluster algorithm; each disjoint tree is its own collapsible cluster.
- **Dangling / unreachable commits** — bottom cluster labeled 'Unreachable (N commits)', collapsed by default.

## Out of scope for v1

- Write operations (checkout, rebase, merge, branch delete)
- Private repo auth
- Non-GitHub hosts (GitLab, Bitbucket)
- In-app diff viewer
- Auto-refresh / filesystem watchers
- Stash display
- Submodules
- Dark mode
- Export to PNG/SVG, shareable URLs, AI summaries

## File structure

```
git-graph/
├── src-tauri/
│   ├── src/
│   │   ├── main.rs
│   │   ├── commands.rs       # Tauri commands (open_repo, compute_layout, ...)
│   │   ├── git_reader.rs     # git2 wrapper
│   │   ├── layout/
│   │   │   ├── mod.rs
│   │   │   ├── cluster.rs    # WCC detection
│   │   │   ├── topo.rs       # topological X assignment
│   │   │   └── lanes.rs      # greedy lane reuse
│   │   ├── clone.rs          # shallow github clone + cache
│   │   └── persistence.rs    # wraps plugin-store
│   └── Cargo.toml
└── src/                      # React + TS
    ├── main.tsx
    ├── App.tsx
    ├── state/                # zustand stores
    ├── lib/ipc.ts            # typed Tauri invoke wrappers
    ├── components/
    │   ├── Topbar.tsx
    │   ├── CommandPalette.tsx
    │   ├── Sidebar/
    │   │   ├── BranchInventory.tsx
    │   │   ├── BranchRow.tsx
    │   │   └── InventoryFilters.tsx
    │   ├── Graph/
    │   │   ├── GraphCanvas.tsx       # SVG root, pan/zoom
    │   │   ├── ClusterBand.tsx
    │   │   ├── CommitNode.tsx
    │   │   ├── Edge.tsx
    │   │   ├── RefLabel.tsx
    │   │   ├── Minimap.tsx
    │   │   └── InsightPanel.tsx      # merge base + ahead/behind
    │   ├── CommitDrawer.tsx
    │   └── SelectionChips.tsx
    └── styles/tokens.css
```

## Implementation order

1. **Tauri + Rust skeleton** — `open_repo` + `list_refs` + `walk_commits` returning mock-serialized types; React renders a plain list of branches. End-to-end IPC works.
2. **Layout compute** — implement cluster → topo → lanes in Rust; ship `compute_layout`. Render a minimal SVG graph with straight edges.
3. **Branch inventory + filters** — sidebar with name/author/merged filters; pin toggle wired to plugin-store.
4. **Selection + highlight** — click branch in graph or sidebar; dim mode; chip-bar; isolate mode toggle.
5. **Insight panel** — merge base + pairwise ahead/behind when ≥2 branches selected.
6. **Commit drawer** — metadata + Copy SHA + GitHub link + VS Code link.
7. **Command palette + search** — Cmd+K, fuzzy across branches/commits/authors; `/` focus.
8. **GitHub clone flow** — shallow clone, cache, refresh.
9. **Polish** — minimap, semantic zoom, saved views, recent repos list.

## Verification

- [ ] `cargo tauri dev` launches the app; file-picker opens a local repo.
- [ ] Open the user's messy repo: graph renders all branches+tags; disjoint branches appear in separate collapsible clusters.
- [ ] Cmd-click two branches → insight panel shows correct merge base (verify against `git merge-base <a> <b>`) and correct ahead/behind (verify against `git rev-list --left-right --count <a>...<b>`).
- [ ] Toggle isolate mode (`H`) → only selected branches' ancestries + merge base visible.
- [ ] Sidebar filters: 'merged only' hides unmerged branches from list; 'author: me' shows only your branches.
- [ ] Search in palette: type a branch name prefix → matching branches rank first; type an author email → matching commits appear.
- [ ] Paste a `github.com/<owner>/<repo>` URL → shallow clone completes; graph renders; second open of same URL uses cache.
- [ ] Click a commit → drawer opens; 'Open in GitHub' opens the correct URL; 'Copy SHA' writes the full SHA.
- [ ] Close and relaunch → recent repos list shows prior repo; pinned branches and saved views restored.

## Critical files

- `src-tauri/src/layout/` — all three files are the heart of the app; correctness here determines whether the graph is readable.
- `src-tauri/src/git_reader.rs` — single source of truth for git reads; keep it thin and test it against real repos early.
- `src/components/Graph/GraphCanvas.tsx` — SVG root, pan/zoom math, selection event routing.
- `src/components/Graph/InsightPanel.tsx` — the payoff UI for the messy-repo use case; worth extra polish.
