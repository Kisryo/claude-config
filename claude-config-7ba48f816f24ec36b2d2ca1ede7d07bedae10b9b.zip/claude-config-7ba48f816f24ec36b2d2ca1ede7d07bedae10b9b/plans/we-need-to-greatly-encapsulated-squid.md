# Friends Feature Revamp

## Context

The Friends tab has four problems the user surfaced:

1. **Crash on tap** — opening a challenge crashes. **Root cause**: `FriendAvatarView.swift:62` does `palettes[index % palettes.count]`, and `ChallengeDetailView.swift:174,190` passes `displayName.hashValue` as `colorIndex`. Swift's `%` preserves the dividend's sign, so a negative `hashValue` → negative subscript → crash. **Compounding bug**: `ChallengesView.swift:171` constructs `ChallengeDetailView(challenge:)` for **history** rows without forwarding `challengeService`, so live progress never attaches even when the view opens. (Active rows at line 97 do pass it.)

2. **Empty activity feed** — `ActivityFeedService` has zero writers. The file (`Core/Social/ActivityFeedService.swift`) defines only `fetchFeed`/`performFetchFeed`/`configure`. Grep for the `activityEvents` collection finds exactly one reference — the read query at line 56. The empty state literally says "Start a challenge to see activity!" but no code path posts to the collection, so the feed will never populate regardless of what users do.

3. **Challenges feel pointless** — `behavioral` type always ties (`ChallengeService.swift:868` returns 0 from `computeProgress`). User-facing copy speaks in app-internal terms ("granted minutes" — meaning "minutes Argo allowed after a blocker conversation") instead of natural-language "screen time." No live "you're winning/trailing" feedback. Detail view is sparse and history rows lack the live observer.

4. **Leaderboard "click in" adds nothing** — `LeaderboardRowView` has no `NavigationLink` or `.onTapGesture` (file inspected end-to-end). `FullLeaderboardView` only has a Today/Week toggle and the same flat list. No friend detail surface exists at all — tapping a row is a literal no-op.

User wants: visual leaderboard match to the Figma reference (geometric podium with stepped 1/2/3 blocks, scope filter pills, rank badges, rounded list card for 4+); a real friend-detail screen on row tap; full challenge redesign with cleaner UX; and a populated activity feed driven by friend interactions.

User's confirmed scope (via AskUserQuestion):
- **Scope pills**: match the Figma look but pills become time-window filters (Today / Week / Month / All Time) — no geo data, no new permissions.
- **Friend detail**: stats + challenge CTA when row is tapped.
- **Challenges**: full redesign (drop behavioral, friendlier copy, live progress feedback, redesigned create flow + detail view).

## Approach

### 1. Crash fix (small, immediate)

**`MojoiOS/UI/Friends/FriendAvatarView.swift`** — Replace `AvatarPalettes.gradient(for:)` (lines 61–63) with a true mathematical modulo:

```swift
static func gradient(for index: Int) -> [Color] {
    let count = palettes.count
    let normalized = ((index % count) + count) % count
    return palettes[normalized]
}
```

`((x % c) + c) % c` is always in `[0, c)` for any `Int`, including `Int.min` — `abs(x % c)` would crash for `Int.min` because `abs(Int.min)` overflows. This is the canonical Swift workaround for `%` matching the dividend's sign.

**`MojoiOS/UI/Friends/ChallengesView.swift`** — line 171: forward `challengeService` so history rows also attach the live observer:

```swift
ChallengeDetailView(challenge: challenge, challengeService: challengeService)
```

### 2. Activity feed wiring

**`MojoiOS/Models/ActivityEvent.swift`** — extend `ActivityEventType`:

```swift
case challengeCreated, challengeAccepted, challengeCompleted, challengeDeclined
case goalMet            // new — under daily screen-time goal
case goalExceeded       // new — over daily screen-time goal
case dailyProgress, friendAdded
```

Add icon + `displayText` cases (`"checkmark.seal.fill"` / `"\(name) stayed under their goal"`, `"exclamationmark.triangle.fill"` / `"\(name) went over their goal today"`).

**`MojoiOS/Core/Social/ActivityFeedService.swift`** — add a single `postEvent` writer:

```swift
func postEvent(
    type: ActivityEventType,
    actorUserId: String,
    actorDisplayName: String,
    visibleTo: [String],
    challengeId: String? = nil,
    metadata: [String: Any]? = nil
) async {
    let docRef = db.collection("activityEvents").document()
    var data: [String: Any] = [
        "type": type.rawValue,
        "actorUserId": actorUserId,
        "actorDisplayName": actorDisplayName,
        "visibleTo": visibleTo,
        "timestamp": FieldValue.serverTimestamp()
    ]
    if let challengeId { data["challengeId"] = challengeId }
    if let metadata,
       let json = try? JSONSerialization.data(withJSONObject: metadata),
       let str = String(data: json, encoding: .utf8) {
        data["metadataJSON"] = str
    }
    do { try await docRef.setData(data) }
    catch { print("[ActivityFeedService] postEvent failed: \(error.localizedDescription)") }
}
```

Failures are logged, never thrown — feed posts must never block primary action paths.

**`MojoiOS/Core/Social/ChallengeService.swift`** — inject `ActivityFeedService` via init. Post events at four hook points (all fire-and-forget after the Firestore write succeeds):
- `createChallenge` after line 479: `.challengeCreated`, `visibleTo: [creatorId, opponentId]`
- `acceptChallenge` after line 524: `.challengeAccepted`
- `declineChallenge` after line 544: `.challengeDeclined`
- `evaluateCompletion` after line 967: `.challengeCompleted` with `metadata = ["winnerId": winnerId ?? ""]`

**`MojoiOS/Core/Social/StatsSyncService.swift`** — inject `ActivityFeedService` and the friend-id snapshot provider. After `syncScreenTime` writes today's value (line 174), compare to `UserProfile.goalScreenTime`:
- Use UserDefaults key `social.feed.goalEventDate.<userId>` to track the date the event was emitted; emit at most once per day per user (the type is fixed at first emission to avoid flip-flopping if usage crosses the threshold mid-day).
- `visibleTo = [myUserId] + friendIds` so friends see it.
- Friend IDs come from `SocialService.friends.map(\.firebaseUserId)` injected through `DependencyContainer`.

**`MojoiOS/Core/Social/SocialService.swift`** — `acceptFriendRequest`: post `.friendAdded`, `visibleTo: [acceptorId, requesterId]`.

**`MojoiOS/UI/Friends/ActivityFeedSection.swift`** — no change needed; it reads `event.displayText` + `event.type.icon` so new cases auto-render.

### 3. Leaderboard redesign

**`MojoiOS/Core/Social/LeaderboardService.swift`** — extend the period enum:

```swift
enum LeaderboardPeriod: String, CaseIterable {
    case today = "Today"
    case week = "Week"
    case month = "Month"
    case allTime = "All Time"
}
```

`fetchUserStats` adds two branches:
- `.month`: aggregate the last 30 daily docs (`for dayOffset in 0..<30`), following the existing weekly-fallback pattern at lines 240–276.
- `.allTime`: aggregate up to 365 daily docs (bounded). Backend rollup work is out of scope; client-side aggregation is fine for friend-scale.

**`MojoiOS/UI/Friends/LeaderboardPodiumView.swift`** — full visual rewrite to match Figma:
- Container background: `Color.Mojo.background` (Figma's dark BG matches our dark-mode token); drop the `surfaceCard` clamp.
- 3 `Rectangle` "podium step" blocks at heights `120 / 160 / 90 pt`, aligned to bottom, in `surfaceCard`/`surfaceElevated` with rendered "1 / 2 / 3" inside (large faint figtree black numerals, ~0.4 opacity).
- `FriendProfileAvatar`s float **above** the steps (`offset(y: -avatarSize/2)`), sized 64/76/64.
- Small circular rank badges anchored top-right of each avatar, gold/silver/bronze with white "1/2/3".
- Score chip below name in primaryFixed background, white text — formatted `"\(minutes)m"`.

**`MojoiOS/UI/Friends/FullLeaderboardView.swift`** — restructure:
- Replace 2-pill toggle with horizontal-scroll 4-pill row (`Today / Week / Month / All Time`); selected pill keeps the `matchedGeometryEffect` ID `"fullLeaderboardPeriod"` and renders white-on-dark to match Figma.
- Background: `Color.Mojo.background.ignoresSafeArea()` for Figma's dark-emphasis treatment.
- Below podium: `LeaderboardListView` ranks 4+ wrapped in a single `RoundedRectangle(cornerRadius: 24)` with `Color.Mojo.surfaceCard` fill, hairline `Divider`s between rows.

**`MojoiOS/UI/Friends/LeaderboardListView.swift`** + **`LeaderboardRowView.swift`** — wrap each non-self row in `NavigationLink { FriendDetailView(...) }`. Self rows stay non-tappable (return self with no link).

### 4. Friend detail view (new)

**Create `MojoiOS/UI/Friends/FriendDetailView.swift`**:

Init: `FriendDetailView(friend: FriendProfile, entry: LeaderboardEntry, dependencies: DependencyContainer)`.

Sections:
1. **Header** — `FriendProfileAvatar` 96pt, displayName, `@handle`, current streak via existing `XPBadge`.
2. **Stat cards** — two `MojoCard`s side-by-side: today (from `entry.screenTimeMinutes`) and this-week (re-fetch via `LeaderboardService.fetchUserStats(period: .week)` for this single user — extract `fetchUserStats` to internal access).
3. **Head-to-head challenges** — `challengeService.fetchChallengeHistory()` filtered to `challenge.opponentUserId == friend.firebaseUserId || creatorUserId == friend.firebaseUserId`; show last 5 with the existing `resultBadge` style from `ChallengesView.swift:214`.
4. **CTA** — `MojoPillButton(title: "Challenge \(firstName)", icon: "bolt.fill", style: .primary)` → presents `CreateChallengeSheet` with `initialFriend: FriendProfile?` pre-set (sheet skips step 2 when present).

### 5. Challenges full redesign

**`MojoiOS/UI/Friends/CreateChallengeSheet.swift`**:
- Add `initialFriend: FriendProfile? = nil` init param; when set, jump straight to step 3 with `selectedFriend` populated.
- Drop the `.behavioral` configuration step (line 283) and `behavioralConfig` block (lines 360–374). `presentablePresets` at line 32 already excludes it; this completes the cleanup.
- Friendlier preset copy in `presetDescription`:
  - `.timeTarget` → "Whoever spends less screen time wins."
  - `.appDetox` → "Avoid a specific app for 7 days."
- Title fix in `ChallengeService.swift:990`: `"Stay under \(target)min daily"` → `"Less screen time wins"` (when targetValue present, append `" — \(target)m daily"`).
- Description fix in `ChallengeService.swift:1013`: drop "of granted screen time" → "of screen time."

**`MojoiOS/UI/Friends/ChallengeDetailView.swift`** — restructure:
- Replace `colorIndex: challenge.creatorDisplayName.hashValue` (lines 174, 190) with stored `challenge.creatorAvatarColorIndex` / `opponentAvatarColorIndex` (added to model below). The crash fix in `AvatarPalettes` makes this safe regardless, but the stored value gives stable colors across launches and across users (`hashValue` is randomized per process).
- Add a "You're winning by Xm" / "You're trailing by Xm" / "Tied" badge near `statusBadge`, computed from `effectiveCreatorScore` vs `effectiveOpponentScore` and the current user's role (creator vs opponent).
- Daily breakdown rows: label by weekday ("Mon", "Tue") computed from `dateKey` rather than "Day 1/2/3". The `dateKey` is already in the snapshot.
- Add an "End early" button (calls `challengeService.abandonChallenge` after a confirmation dialog) — currently no in-detail action exists.

**`MojoiOS/Models/Challenge.swift`** — add two optional Int properties: `creatorAvatarColorIndex: Int?`, `opponentAvatarColorIndex: Int?`. SwiftData adds optionals safely; existing rows show `nil` and the view falls back to palette[0].

**`MojoiOS/Core/Social/ChallengeService.swift`**:
- Persist `creatorAvatarColorIndex` and `opponentAvatarColorIndex` in `createChallenge` (Firestore payload at line 459 + the `Challenge` init at line 444). Source: current user from `authService.avatarColorIndex` (or a new accessor); opponent from the `FriendProfile` (caller passes it through).
- Update `challengeFromFirestore` (line 795) to read both fields.
- Drop the `case .behavioral` branch in `evaluateCompletion` (lines 944–952) — unreachable once creation is gone; existing rows in `.behavioral` state stay tied which is the current behavior anyway.

### 6. Wiring (DependencyContainer)

**`MojoiOS/Core/DependencyContainer.swift`** — pass `activityFeedService` into `ChallengeService`, `StatsSyncService`, and `SocialService` constructors. Pass `socialService` into `StatsSyncService` so it can read friend IDs at goal-event time. Dependency direction stays one-way (services depend on `activityFeedService`, never the reverse).

**`MojoiOS/UI/Friends/FriendsTabView.swift`** — already wires every service into the tab; only the leaderboard row tap needs the new `FriendDetailView` plumbed through `LeaderboardListView`/`LeaderboardRowView`.

## Critical files to modify

- `MojoiOS/UI/Friends/FriendAvatarView.swift` — crash fix (safe modulo)
- `MojoiOS/UI/Friends/ChallengesView.swift` — forward `challengeService` to history NavigationLink
- `MojoiOS/UI/Friends/ChallengeDetailView.swift` — color-index from model, "winning by" badge, weekday labels, end-early action
- `MojoiOS/UI/Friends/CreateChallengeSheet.swift` — drop behavioral, `initialFriend`, friendlier copy
- `MojoiOS/UI/Friends/LeaderboardPodiumView.swift` — Figma stepped podium
- `MojoiOS/UI/Friends/FullLeaderboardView.swift` — 4-pill scope, dark BG, rounded list card
- `MojoiOS/UI/Friends/LeaderboardListView.swift` — NavigationLink wrap
- `MojoiOS/UI/Friends/LeaderboardRowView.swift` — NavigationLink wrap (skip self)
- `MojoiOS/UI/Friends/FriendDetailView.swift` — **NEW**
- `MojoiOS/Models/Challenge.swift` — `creatorAvatarColorIndex`, `opponentAvatarColorIndex`
- `MojoiOS/Models/ActivityEvent.swift` — `goalMet`, `goalExceeded` types
- `MojoiOS/Core/Social/ActivityFeedService.swift` — `postEvent` writer
- `MojoiOS/Core/Social/ChallengeService.swift` — 4 feed hook points + persist color indexes + drop behavioral evaluator
- `MojoiOS/Core/Social/StatsSyncService.swift` — goal events at sync, idempotent per day
- `MojoiOS/Core/Social/SocialService.swift` — `friendAdded` hook
- `MojoiOS/Core/Social/LeaderboardService.swift` — `.month` and `.allTime` cases
- `MojoiOS/Core/DependencyContainer.swift` — wiring

## Reused utilities (don't recreate)

- `MojoCard`, `MojoPillButton`, `MojoSpacing.*`, `MojoShape.*`, `Font.Mojo.figtree`, `Color.Mojo.*` — design tokens
- `FriendProfileAvatar` — already exists for the photo-data path; reused in podium
- `XPBadge` — reuse for streak badge in friend detail
- `ChallengeService.fetchProgressSnapshot` (line 324) — reuse for "winning by X" calc
- `ChallengeService.observeProgress` (line 229) — already streams winnerId + status, drives the live badge
- `StatsSyncService.dateKey(for:)` / `weekKey(for:)` (lines 236, 246) — used in monthly aggregation
- `LeaderboardEntry` (already has `screenTimeMinutes`, `streak`, `profilePhotoData`, `argoCustomization`) — passed straight into `FriendDetailView`
- Existing `resultBadge` styling pattern at `ChallengesView.swift:214` — reused in head-to-head section

## Verification

1. **Build**: `xcodebuild -scheme MojoiOS -configuration Debug build` (no warnings on new types).
2. **Crash fix**: tap any active challenge → detail opens. Tap any history challenge → detail opens with the live observer attached (status/winner refresh from Firestore mid-view). Confirm with a previously-crashing display name (string with negative `hashValue` — easy to seed via preview data).
3. **Activity feed**: two simulators, two accounts, friended. Sim A creates a challenge → Sim B pull-to-refreshes feed → sees `challengeCreated` row. Sim B accepts → both see `challengeAccepted`. Let it complete → both see `challengeCompleted`. Sim A goes over `goalScreenTime` and syncs → Sim B sees `goalExceeded`. Re-sync same day → no duplicate event. Cold launch + same-day sync → still no duplicate (UserDefaults persisted).
4. **Leaderboard**: open Friends → "View all" → 4 pills (Today/Week/Month/All Time) animate via `matchedGeometryEffect`; podium has stepped geometric blocks with "1/2/3" rendered; avatars float above with rank badges; ranks 4+ in single rounded `surfaceCard`. Switch to dark mode → Figma-faithful look.
5. **Friend detail**: tap any non-self leaderboard row → `FriendDetailView` opens with avatar + streak + today/week stats + head-to-head; self row is non-tappable. Tap "Challenge \(name)" → `CreateChallengeSheet` opens at step 3 with that friend pre-selected.
6. **Challenges UX**: `CreateChallengeSheet` shows only Less Screen Time + App Detox (no Behavioral). Copy reads "screen time" not "granted minutes". Detail shows "You're winning by 12m" / "You're trailing by 4m" badge live; daily breakdown shows "Mon / Tue / Wed".
7. **Tests**: `xcodebuild -scheme MojoiOS test` — existing suites must stay green. Add a unit test for `AvatarPalettes.gradient(for: Int.min)` proving no crash; add a `ChallengeService` mock-Firestore test verifying `postEvent` is called from each of the four hook points.
