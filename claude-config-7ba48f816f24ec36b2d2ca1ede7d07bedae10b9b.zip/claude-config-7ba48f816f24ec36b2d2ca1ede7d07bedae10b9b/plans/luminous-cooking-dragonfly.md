# Agent Sandboxing: Path Enforcement + Docker Bash + Permission Gates

## Context

The AI agent can currently read/write anywhere on the filesystem. The `bash` tool can execute arbitrary commands. There's no enforcement that the agent stays within the user's granted project folder. An adversarial review confirmed: regex-based bash path extraction is security theater. The only way to fully contain bash is process isolation.

**Requirements:**
1. Agent can only operate within paths actively granted by the user
2. If agent tries to access a path outside its grants, ask user for permission via popup
3. Any destructive actions (rm, sudo, kill) need explicit user permission via popup

**Approach:** Hybrid. Rust-layer path enforcement for file tools (read_file, write_file, edit_file, glob, grep, list_dir) + Docker containerization for bash commands. The Docker infrastructure already exists in `docker.rs` via bollard.

## Architecture

```
  User grants project_path ("/Users/me/project")
                │
                ▼
  tool_executor.rs ──── central gate
  ┌───────────────────────────────────────────────┐
  │                                               │
  │  FILE TOOLS (read/write/edit/glob/grep/ls):   │
  │  ┌─────────────────────────────────────────┐  │
  │  │  1. Extract path from tool input        │  │
  │  │  2. Resolve & normalize (canonicalize)  │  │
  │  │  3. Check against allowed_paths[]       │  │
  │  │     YES → dispatch to tool              │  │
  │  │     NO  → emit PathPermissionRequest    │  │
  │  │           wait for user grant/deny      │  │
  │  └─────────────────────────────────────────┘  │
  │                                               │
  │  BASH TOOL:                                   │
  │  ┌─────────────────────────────────────────┐  │
  │  │  1. Check for destructive patterns      │  │
  │  │     (rm, sudo, kill, etc.)              │  │
  │  │     → emit DestructiveActionConfirm     │  │
  │  │     → wait for user approve/deny        │  │
  │  │  2. Route to Docker container:          │  │
  │  │     - Mount project_path:/workspace     │  │
  │  │     - Mount /tmp:/tmp                   │  │
  │  │     - No other mounts                   │  │
  │  │     - Network: allowed (for pip/npm)    │  │
  │  │  3. Fallback: if Docker unavailable,    │  │
  │  │     run on host with cwd restriction    │  │
  │  │     + warning to user                   │  │
  │  └─────────────────────────────────────────┘  │
  │                                               │
  └───────────────────────────────────────────────┘
```

## Files to Modify

| File | Change |
|------|--------|
| `src-tauri/src/agent/tool_executor.rs` | Add `PathGrants`, central `validate_path()` for file tools, destructive action gate for bash, route bash to Docker |
| `src-tauri/src/agent/types.rs` | Add `PermissionKind::PathAccess`, `PermissionKind::DestructiveAction` variants |
| `src-tauri/src/tools/bash.rs` | Add `is_destructive()` classifier, no other changes (Docker routing happens in tool_executor) |
| `src-tauri/src/tools/docker.rs` | Add `SandboxContainer` (create/exec/destroy), only mount project_path, no /tmp |
| `src-tauri/src/commands.rs` or `src-tauri/src/agent/agent_loop.rs` | Destroy sandbox container on task end |
| `src/components/PermissionBubble.tsx` | Handle PathAccess (path + allow once/session/deny) and DestructiveAction (command + approve/cancel) |
| `src/stores/taskStore.ts` | Wire new permission event variants |

## Detailed Design

### 1. PathGrants in ToolExecutor (simplified per eng review)

Single allowed_paths list (no read/write split — Docker handles bash isolation, file tool names handle the read vs write distinction):

```rust
pub struct PathGrants {
    /// Paths the agent is allowed to access (read and write)
    allowed: Vec<PathBuf>,
    /// Paths that should never be granted (safety net)
    blocked: Vec<PathBuf>,
}

impl PathGrants {
    fn new(project_path: Option<&str>) -> Self {
        let mut allowed = vec![];
        
        if let Some(pp) = project_path {
            let p = std::fs::canonicalize(pp)
                .unwrap_or_else(|_| PathBuf::from(pp));
            allowed.push(p);
        }
        
        // Always allow temp dir for scratch
        allowed.push(std::env::temp_dir());
        
        // Never allow granting root system paths
        let blocked = vec![
            PathBuf::from("/"),
            PathBuf::from("/usr"),
            PathBuf::from("/etc"),
            PathBuf::from("/var"),
            PathBuf::from("/System"),
            PathBuf::from("/Library"),
        ];
        
        Self { allowed, blocked }
    }
    
    fn is_allowed(&self, path: &Path) -> bool {
        let canonical = std::fs::canonicalize(path)
            .unwrap_or_else(|_| ToolExecutor::normalize_path(path));
        self.allowed.iter().any(|a| canonical.starts_with(a))
    }
    
    fn grant(&mut self, path: PathBuf) -> Result<(), String> {
        let canonical = std::fs::canonicalize(&path)
            .unwrap_or_else(|_| path.clone());
        if self.blocked.iter().any(|b| canonical.starts_with(b) && canonical == *b) {
            return Err(format!("Cannot grant access to system path: {}", path.display()));
        }
        self.allowed.push(canonical);
        Ok(())
    }
}
```

Add to ToolExecutor alongside existing `project_path`:
```rust
path_grants: RwLock<PathGrants>,
```

### 2. Central path validation — applied to ALL file tools

In `execute()`, before the tool dispatch match:

```rust
// Path validation for ALL file tools
let file_tools = [
    "read_file", "write_file", "edit_file",
    "glob", "grep", "list_dir",
];

if file_tools.contains(&tool_use.name.as_str()) {
    if let Some(path_str) = Self::extract_path(&tool_use.input) {
        let resolved = Self::resolve_and_normalize(path_str, project_path_ref);
        
        let grants = self.path_grants.read().unwrap();
        if !grants.is_allowed(&resolved) {
            drop(grants); // release read lock before blocking
            
            // Emit permission request and block (uses generic request_permission)
            let kind = PermissionKind::PathAccess {
                path: resolved.to_string_lossy().to_string(),
                access: if matches!(tool_use.name.as_str(), "write_file" | "edit_file") {
                    "write".to_string()
                } else {
                    "read".to_string()
                },
                tool: tool_use.name.clone(),
            };
            
            if let Some(etx) = event_tx {
                match self.request_permission(kind, etx).await {
                    Ok(PermissionDecision::Granted { folder_path }) => {
                        // Add parent directory to grants for this session
                        if let Ok(mut g) = self.path_grants.write() {
                            let _ = g.grant(PathBuf::from(&folder_path));
                        }
                    }
                    Ok(PermissionDecision::Cancelled) | Err(_) => {
                        return ToolResult::error(
                            tool_use.id.clone(),
                            format!("Access denied to {}", resolved.display()),
                        );
                    }
                    _ => {}
                }
            }
        }
    }
}
```

### 2b. Generic `request_permission()` (DRY refactor per eng review)

Replace the existing `request_write_permission()` with a generic version:

```rust
async fn request_permission(
    &self,
    kind: PermissionKind,
    event_tx: &mpsc::Sender<AgentEvent>,
) -> Result<PermissionDecision, String> {
    let pending = self.pending_permissions.as_ref()
        .ok_or("Permission infrastructure not available")?;
    
    let request_id = uuid::Uuid::new_v4().to_string();
    let (tx, rx) = tokio::sync::oneshot::channel();
    
    {
        let mut map = pending.lock().await;
        map.insert(request_id.clone(), tx);
    }
    
    let _ = event_tx.send(AgentEvent::PermissionRequest {
        request_id,
        kind,
        suggested_filename: None,
        reason: String::new(), // frontend derives reason from PermissionKind
    }).await;
    
    rx.await.map_err(|_| "Permission request dropped".to_string())
}
```

The existing `request_write_permission` call sites get refactored to use this.

### 3. Bash routing to Docker

In `execute()`, replace the current bash dispatch:

```rust
"bash" => {
    let command = tool_use.input.get("command")
        .and_then(|v| v.as_str())
        .unwrap_or("");
    
    // Check for destructive patterns
    if let Some(action) = tools::bash::classify_destructive(command) {
        if let Some(etx) = event_tx {
            match self.request_destructive_permission(&action, command, "bash", etx).await {
                Ok(()) => {} // approved, continue
                Err(e) => return ToolResult::error(tool_use.id.clone(), e),
            }
        }
    }
    
    // Try Docker first, fall back to host
    match tools::docker::execute_sandboxed_bash(command, project_path_ref).await {
        Ok(result) => Ok(result),
        Err(_docker_err) => {
            // Docker not available — run on host with cwd restriction
            // (existing bash.rs behavior, cwd = project_path)
            tools::bash::execute(&tool_use.input, project_path_ref)
        }
    }
}
```

### 4. Sandboxed bash via Docker (container reuse per task, per eng review)

Reuse a single container per task for ~50ms latency instead of ~300ms per command.

**Lifecycle:** First bash call creates the container. Subsequent calls use `docker exec`. Task end destroys it.

New `SandboxContainer` struct in `docker.rs` manages the lifecycle:
- `create(project_path)` -> creates container with `sleep infinity`, mounts only project_path:/workspace (no /tmp, no home, no system dirs per eng review)
- `exec(command)` -> runs `sh -c <command>` via `docker exec`, collects stdout+stderr
- `destroy()` -> force-removes container

Add `sandbox: RwLock<Option<SandboxContainer>>` to ToolExecutor. On first bash call, create. On task completion, destroy.

The existing `docker_run` (for skills/manual use) stays as-is. `SandboxContainer` is separate, simpler, locked-down.

Key security properties:
- Only project_path mounted (no /tmp, no home, no system dirs)
- No privileged mode, no extra capabilities
- Network allowed (pip/npm need it)
- Container destroyed when task ends

### 5. Destructive action classifier

In `bash.rs`:

```rust
pub fn classify_destructive(command: &str) -> Option<String> {
    let patterns = [
        ("rm ", "Delete files"),
        ("rm -", "Delete files"),
        ("rmdir", "Remove directory"),
        ("sudo ", "Run with elevated privileges"),
        ("kill ", "Kill process"),
        ("pkill ", "Kill processes"),
        ("killall ", "Kill processes"),
        ("chmod ", "Change file permissions"),
        ("chown ", "Change file ownership"),
        ("dd ", "Raw disk operation"),
        ("mkfs", "Format filesystem"),
    ];
    
    let lower = command.to_lowercase();
    for (pattern, description) in &patterns {
        if lower.contains(pattern) {
            return Some(description.to_string());
        }
    }
    None
}
```

NOT destructive (normal agent operations):
- `npm install`, `pip install` — runs inside Docker, can't escape
- `write_file` overwrite — normal agent behavior
- `mv` inside project — normal
- `git` commands — normal

### 6. New PermissionKind variants

```rust
pub enum PermissionKind {
    NeedFolder,
    NeedFileWrite,
    PathAccess {
        path: String,
        access: String,    // "read" or "write"
        tool: String,
    },
    DestructiveAction {
        action: String,    // "Delete files", "Run with elevated privileges"
        command: String,   // the actual command
    },
}
```

### 7. Frontend: PermissionBubble updates

Two new popup variants:

**PathAccess popup:**
- Shows the path being accessed and whether it's read or write
- Three buttons: "Allow Once" | "Allow for Session" | "Deny"
- "Allow for Session" adds path to `path_grants`

**DestructiveAction popup:**
- Shows the action description and the actual command
- Two buttons: "Approve" | "Cancel"
- No "allow for session" — each destructive action needs explicit approval

### 8. Docker fallback behavior

When Docker is not running:
1. File tools: Rust-layer validation still works (no Docker needed)
2. Bash tool: Falls back to host execution with cwd=project_path
3. Show a one-time warning: "Docker is not running. Bash commands will run on your system without full isolation. Install Docker for sandboxed execution."

This means the app works without Docker (degraded security for bash), but with Docker it's fully sandboxed.

## Build Sequence

1. **Types** (`types.rs`): Add PathAccess and DestructiveAction to PermissionKind
2. **Bash** (`bash.rs`): Add `classify_destructive()` function + unit tests
3. **Docker** (`docker.rs`): Add `SandboxContainer` struct (create/exec/destroy)
4. **Tool executor** (`tool_executor.rs`): Add PathGrants, generic `request_permission()`, validate_path for all file tools, destructive gate, Docker bash routing with sandbox lifecycle + unit tests for PathGrants
5. **Frontend** (`PermissionBubble.tsx`): Handle PathAccess and DestructiveAction permission kinds
6. **Store** (`taskStore.ts`): Wire new permission event handling
7. **Cleanup** (`commands.rs` or `agent_loop.rs`): Destroy sandbox container on task end
8. **Verify**: `cargo check && cargo clippy -- -D warnings && cargo test && npx tsc --noEmit`

## Edge Cases

- **Symlink bypass**: `canonicalize()` resolves symlinks. Symlink inside project pointing outside resolves to real path → fails validation. In Docker, symlinks outside /workspace don't exist.
- **Docker image not pulled**: `execute_sandboxed_bash` should pull python:3.11-slim on first use (existing `pull_image_if_needed` handles this).
- **Long-running bash**: Existing 300s timeout in bash.rs applies. Docker container has same timeout via tokio::timeout.
- **User grants `/`**: PathGrants should reject grants to root paths (`/`, `/usr`, `/etc`, `/var`, `/System`). Whitelist: only user-owned directories.
- **Empty project_path**: PathGrants starts with only /tmp. File tools trigger permission on every path. Bash in Docker has empty /workspace.
- **Multiple project paths**: User can grant additional paths via popups. All accumulate in PathGrants.

## Verification

1. **Path enforcement**: `read_file /etc/passwd` → permission popup
2. **Path traversal**: `read_file ../../etc/passwd` → blocked by normalize
3. **Bash in Docker**: `bash "ls /"` → sees container filesystem, not host
4. **Bash destructive**: `bash "rm -rf ."` → destructive confirmation popup
5. **Docker fallback**: Stop Docker → bash runs on host with warning
6. **Symlink bypass**: `bash "ln -s /etc project/etc_link"` → inside Docker, /etc is the container's /etc, not host's

## Failure Modes

| Codepath | Failure | Tested? | Error handling? | User sees? |
|----------|---------|---------|-----------------|------------|
| PathGrants.is_allowed | Symlink inside project → outside | Unit test | canonicalize catches it | Permission popup |
| PathGrants.is_allowed | Path with ../ traversal | Unit test | normalize_path catches it | "Access denied" error |
| PathGrants.grant | User grants "/" | Unit test | blocked list rejects | Error message |
| SandboxContainer.create | Docker not running | Integration | Falls back to host bash | Warning in chat |
| SandboxContainer.create | Image not pulled | Integration | pull_image_if_needed | Slower first bash call |
| SandboxContainer.exec | Command timeout (>300s) | Manual | tokio::timeout | "Command timed out" |
| SandboxContainer.exec | Container died mid-task | Runtime check | Recreate on next exec | Transparent retry |
| classify_destructive | "rm" in filename (false positive) | Unit test | Contains-match is coarse | Extra confirmation (acceptable) |
| request_permission | Channel dropped (agent cancelled) | Existing | Returns error | Agent stops |

No CRITICAL GAPS. All failure modes are either tested, handled, or produce visible errors.

## Rust Unit Tests (per eng review)

```rust
// tool_executor.rs
#[cfg(test)]
mod tests {
    // PathGrants tests:
    // - path_inside_project_allowed
    // - absolute_path_outside_project_blocked
    // - relative_traversal_blocked ("../../etc/passwd")
    // - tilde_expansion_blocked ("~/secret")
    // - temp_dir_allowed
    // - empty_project_path_only_tmp
    // - grant_root_rejected ("/", "/etc", "/usr")
    // - grant_user_dir_accepted
    // - multiple_grants_accumulate
}

// bash.rs
#[cfg(test)]
mod tests {
    // classify_destructive tests:
    // - rm_detected
    // - sudo_detected
    // - kill_detected
    // - ls_not_destructive
    // - npm_install_not_destructive
    // - git_commands_not_destructive
    // - case_insensitive ("RM -RF" vs "rm -rf")
}
```

## NOT in scope

- MCP tool sandboxing (MCP servers are external processes, different trust model)
- Network restrictions for Docker (pip/npm need network)
- Permission timeout (user chose no timeout)
- File overwrite as destructive (too much friction for normal agent workflows)
- Windows/Linux support (macOS first, Docker works cross-platform when needed)

## GSTACK REVIEW REPORT

| Review | Trigger | Why | Runs | Status | Findings |
|--------|---------|-----|------|--------|----------|
| CEO Review | `/plan-ceo-review` | Scope & strategy | 1 | CLEAR | Hold scope, hybrid approach (Rust + Docker) |
| Codex Review | `/codex review` | Independent 2nd opinion | 0 | — | — |
| Eng Review | `/plan-eng-review` | Architecture & tests (required) | 1 | CLEAR | 4 issues, 0 critical gaps |
| Design Review | `/plan-design-review` | UI/UX gaps | 0 | — | — |
| DX Review | `/plan-devex-review` | Developer experience gaps | 0 | — | — |

- **OUTSIDE VOICE (CEO):** Claude adversarial subagent found 7 issues. Key: bash escape hatch led to Docker adoption.
- **ENG REVIEW:** 4 findings: (1) simplified PathGrants to single allowed_paths list, (2) /tmp mount removed (symlink escape), (3) DRY refactor to generic request_permission(), (4) container reuse per task for performance. Plus: unit tests required for security-critical path logic.
- **VERDICT:** CEO + ENG CLEARED. Ready to implement.
