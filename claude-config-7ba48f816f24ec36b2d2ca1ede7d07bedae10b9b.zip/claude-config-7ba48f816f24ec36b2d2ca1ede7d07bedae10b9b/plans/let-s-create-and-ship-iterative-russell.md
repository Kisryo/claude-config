# InFeed — Spec & Implementation Plan

## Context
Solo YouTubers struggle to predict how their thumbnail will look *in context* — against neighbor thumbnails on the home feed, cropped by the duration badge on mobile, or shrunk to sidebar size. They currently publish, watch CTR suffer, and iterate. **InFeed** lets creators upload a thumbnail (plus channel metadata) and preview it inside a high-fidelity recreation of YouTube's actual surfaces before hitting publish.

## One-liner
> See your thumbnail inside YouTube — home feed, sidebar, end-screen, and mobile — before you publish.

## Primary user
Solo YouTuber about to upload a video, doing a pre-publish gut-check on thumbnail quality.

---

## Scope — v1 MVP

### Surfaces (all 4)
1. **Desktop home feed grid** — youtube.com landing page
2. **Watch-page sidebar** — "Up next" right-rail on a watch page
3. **End-screen overlay** — end-of-video suggested card grid
4. **Mobile app feed** — vertical feed (iOS/Android), with toggleable full-device-frame vs bare viewport

Each surface supports **light and dark mode**, toggleable in-preview.

### Upload & inputs
- **Thumbnail image** — user upload, validated to YouTube hard specs:
  - Dimensions: 1280 × 720 px
  - Aspect: 16:9
  - Max size: 2 MB
  - Formats: JPG, PNG, GIF, BMP
- **Channel avatar** — user upload
- **Editable metadata** (user fills in):
  - Title
  - Channel name
  - View count
  - Upload age (e.g. "3 hours ago")
  - Duration (drives the bottom-right badge — critical, it crops the thumbnail)
  - CC flag
  - Watched state (drives red progress bar on some surfaces)

### Multi-variant
- Up to **4 thumbnail variants** per project
- **Side-by-side comparison view** showing all variants outside feed context
- Variants switchable in any surface

### Placement
- **User-draggable** thumbnail placement — drop into any slot in the feed
- Snap-to-slot behavior; each surface defines its drop zones

### Neighbor thumbnails (feed context)
- **Source:** real YouTube thumbnails with creator attribution visible
- **Curated sets by niche** — user picks one at upload time:
  - Gaming
  - Tech / Reviews
  - Vlog / Lifestyle
  - Education / Finance / How-to
- ~15–20 thumbnails per niche per surface

### Decorations rendered on thumbnails
- Duration badge (bottom-right black pill)
- CC / subtitles badge
- Progress bar (red, for "watched" state — some slots faked as watched for realism)

### UX polish
- **Safe-zone overlay** on hover — dashed overlay showing where duration badge overlaps and where mobile title truncates
- **Keyboard shortcuts** — arrows to switch surfaces, 1–4 to switch variants, D for dark/light toggle
- **Light/dark toggle** per-preview
- **Device-frame toggle** on mobile surface

### Auth gate (soft paywall)
- **Anonymous users**: upload + preview in the **home feed** surface only, 1 variant
- **Signed-in users** (Clerk Google OAuth): unlocks all 4 surfaces, up to 4 variants, PNG export, save to gallery, shareable links

### Export & sharing
- **PNG export** of a single surface at a time, with small InFeed watermark
- **Public share link** `/preview/[id]` — unlisted but no password; anyone with the link can view all variants in all surfaces
- **Saved gallery** (history) — unlimited for signed-in users

### Explicitly out-of-scope for v1
- No AI critique, no CTR heuristic score, no LLM feedback
- No title character counter (deferred; safe-zone overlay covers the same need)
- No password-protected share links
- No A/B analytics / click tracking on share links
- No Shorts / Live / Premiere label rendering
- No paid tier

---

## Tech stack

| Layer | Choice | Notes |
|---|---|---|
| Framework | **Next.js 15 (App Router) + TypeScript** | RSC-friendly, first-class Vercel deploy |
| Styling | **Tailwind + shadcn/ui** | Matches common patterns; shadcn for dialogs/toasts only |
| Auth | **Clerk** | Google OAuth, session middleware, anon → auth upgrade |
| DB | **Neon Postgres** | MCP tools available; serverless driver |
| ORM | **Drizzle** | Lightweight, plays nicely with Neon serverless |
| Image storage | **Vercel Blob** | Signed uploads direct from client |
| Hosting | **Vercel** | Deploy via `vercel --prod --yes` in background (per global CLAUDE.md) |
| Image export | **html-to-image** (client-side) | Renders surface DOM to PNG for download |
| Drag/drop | **dnd-kit** | Accessible, supports keyboard drag |

---

## Data model (Drizzle)

```
users          — Clerk userId (external) + created_at
projects       — id, user_id, name, niche, created_at, updated_at
variants       — id, project_id, thumbnail_blob_url, avatar_blob_url, title,
                 channel_name, view_count, upload_age, duration_seconds,
                 cc_enabled, position (1..4)
share_links    — id (slug), project_id, created_at, is_public
```

Anonymous uploads live in client memory only (no `variants` row) until sign-in triggers a migration write.

---

## Routes

| Path | Purpose |
|---|---|
| `/` | App entry — anon can upload, preview home feed |
| `/studio/[projectId]` | Authed workspace — all 4 surfaces, multi-variant, export |
| `/preview/[shareSlug]` | Public read-only preview of a shared project |
| `/api/upload` | Vercel Blob signed-URL issuer |
| `/api/projects/*` | CRUD for projects + variants |
| `/api/share` | Create/revoke share link |

---

## File layout (high-level)

```
app/
  (public)/
    page.tsx                 # anon landing / uploader
    preview/[slug]/page.tsx  # public share view
  (authed)/
    studio/[projectId]/page.tsx
  api/
    upload/route.ts
    projects/[id]/route.ts
    share/route.ts
components/
  surfaces/
    HomeFeed.tsx             # desktop grid
    WatchSidebar.tsx         # up-next rail
    EndScreen.tsx            # overlay grid
    MobileFeed.tsx           # mobile + device-frame wrapper
  upload/
    ThumbnailDropzone.tsx
    MetadataForm.tsx
    VariantSwitcher.tsx
  shared/
    ThumbnailCard.tsx        # the actual thumbnail tile (duration, CC, progress)
    SafeZoneOverlay.tsx
    ThemeToggle.tsx
lib/
  validation/imageSpecs.ts   # 1280x720, 16:9, <2MB, format check
  neighbors/                 # JSON per niche per surface, with attribution
    gaming.ts
    tech.ts
    vlog.ts
    education.ts
  db/schema.ts
  clerk.ts
```

---

## Implementation order

1. **Scaffold** — Next.js 15 + TS + Tailwind + shadcn + Clerk + Drizzle + Neon + Vercel Blob wiring. Deploy an empty page to Vercel to prove the pipeline end-to-end.
2. **Thumbnail recon** — Use the `/browse` skill to visit youtube.com (signed-out), capture DOM structure + computed styles for the home feed grid (thumbnail dimensions, gaps, title line-clamp, metadata line-height, badge positions). Record in `components/surfaces/README.md`.
3. **Neighbor dataset** — Manually curate ~60 real thumbnails (15/niche × 4 niches). Store as static JSON with `{ imageUrl, channelName, channelAvatarUrl, title, views, uploadAge, durationSeconds, creatorLink }`. All attribution preserved.
4. **Home feed surface** — Build `HomeFeed.tsx` pixel-close to YT. Anon flow ends here. Includes light/dark toggle, safe-zone overlay, drag placement.
5. **Upload + validation** — Dropzone, client-side spec validation, Vercel Blob signed upload.
6. **Metadata form** — Title/channel/views/duration/CC/watched inputs wired to a zustand store driving the preview.
7. **Auth gate** — Clerk wired; anonymous session persists in localStorage, migrated to DB on sign-in.
8. **Remaining surfaces** — Watch sidebar, end-screen, mobile (with device frame toggle). Each reuses `ThumbnailCard`.
9. **Multi-variant + compare view** — Up to 4 variants, variant switcher, dedicated compare page.
10. **Share links** — `/preview/[slug]` public route, create/revoke from studio.
11. **PNG export** — html-to-image on the active surface, with InFeed watermark overlay.
12. **Keyboard shortcuts** — Arrows, 1–4, D.
13. **Polish pass** — `/design-review` + `/qa` skills to catch visual drift and UX bugs.
14. **Ship** — `/jmo-ship` or `/ship` for merge, deploy, and PR.

---

## Critical files to reference / reuse
- `lib/validation/imageSpecs.ts` — single source of truth for YT hard specs
- `lib/neighbors/*.ts` — niche data, treated as content not code
- `components/shared/ThumbnailCard.tsx` — renders ALL thumbnails identically (user's + neighbors); decorations live here
- `.claude/CLAUDE.md` user instructions — Vercel deploys in background; use `/browse` not `mcp__claude-in-chrome__*`

---

## Verification (end-to-end)

1. **Upload valid thumbnail** (1280×720 JPG, <2MB) → appears in home feed at drop position, neighbors render around it in selected niche.
2. **Upload invalid thumbnail** (e.g. 1920×1080, 4MB) → clear validation errors before upload completes; no blob write.
3. **Dark/light toggle** → both render without layout shift; duration badge contrast remains readable in both.
4. **Anon flow** → can only access home feed surface; clicking "Watch sidebar" prompts Clerk sign-in; after sign-in, state preserved and other surfaces unlock.
5. **Multi-variant** → upload 4 variants, switch with 1–4 keys, side-by-side compare shows all 4.
6. **Drag placement** → thumbnail can be dragged into any slot on home feed; keyboard drag works (a11y).
7. **Safe-zone overlay** → hovering reveals duration-badge overlap zone and mobile title crop line.
8. **PNG export** → downloads a PNG of the current surface with InFeed watermark bottom-right; dimensions match surface viewport.
9. **Share link** → `/preview/[slug]` renders all 4 surfaces read-only for a signed-out visitor; owner can revoke from studio.
10. **Deploy** → `vercel --prod --yes` run in background per global CLAUDE.md; production URL loads the landing page.

Skills to run during verification: `/qa`, `/design-review`, `/training-wheels-off` (catch any hardcoded shortcuts or mock data left over).

---

## Open risks / things to revisit
- **Legal (neighbor thumbnails)**: user accepted "real thumbnails with attribution" — a takedown could still arrive. Mitigation: concentrate on thumbnails from public figures / large channels where attribution is clearly displayed; have a takedown email ready.
- **YT DOM drift**: if YouTube redesigns, DOM-recreation surfaces will go stale. Mitigation: isolate surface components and pin a "YT reference date" in README so the divergence is visible.
- **Anon → auth state migration**: localStorage-held variants must survive Clerk sign-in redirect. Mitigation: persist to an ephemeral `pending_upload` cookie before redirect; migrate server-side on first authed page load.
