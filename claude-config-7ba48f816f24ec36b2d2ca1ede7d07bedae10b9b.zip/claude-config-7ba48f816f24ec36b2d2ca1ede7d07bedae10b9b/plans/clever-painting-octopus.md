# Plan: AI Email Draft Rewriter Script

## Context

Existing pending_review email drafts follow a verbose 3-paragraph format. The user wants a script that rewrites ~20 drafts at a time to match a punchy 4-line template (specific subject, attention line, why-you line, outcome line, low-friction CTA, signed `- Johnathan`). The Anthropic SDK is already installed, and there are established patterns for preview/apply scripts and backup logic.

## Approach

Create **one new file**: `scripts/ai-rewrite-sales-drafts.ts`

Uses the Anthropic SDK to send all 20 drafts in a single API call, gets back a JSON array of rewrites, previews them in terminal, and applies to DB on `--apply`.

## CLI Interface

```bash
npx tsx scripts/ai-rewrite-sales-drafts.ts                  # preview 5 rewrites
npx tsx scripts/ai-rewrite-sales-drafts.ts --preview=10     # preview 10
npx tsx scripts/ai-rewrite-sales-drafts.ts --apply          # rewrite 20 & save to DB
npx tsx scripts/ai-rewrite-sales-drafts.ts --apply --limit=40  # 2 batches of 20
```

## Implementation Steps

### 1. Data fetch
- Query `emailDrafts` (status=`pending_review`) joined with `prospects` + `companies`
- Filter to sales campaigns only (same as `humanize-sales-drafts.ts:476-508`)
- Select rich context: `firstName`, `jobTitle`, `companyName`, `industry`, `research`, `painPoints`, `recentNews`, `personalizationNotes`, `website`
- Order by `createdAt` ASC, limit to `--limit` (default 20)

### 2. Build Claude prompt
- System instructions with the user's exact template
- Rules: under 80 words, no buzzwords, no em-dashes, casual tone, `- Johnathan` sign-off
- Follow-up handling (sequenceNumber >= 2): "Re:" prefix, shorter body
- All draft contexts as a JSON array in `<drafts>` tags
- Request ONLY a JSON array response: `[{id, subject, bodyText}, ...]`

### 3. Call Anthropic SDK
- `client.messages.create()` with `claude-sonnet-4-20250514` (fast, cheap — this is templated rewriting)
- `max_tokens: 4096` (20 drafts * ~100 tokens each + overhead)
- Pattern from `scripts/run-followup-batch.ts:103-107`

### 4. Parse & validate response
- `JSON.parse()` with regex fallback to extract `[...]` from markdown fences
- Validate each rewrite: `id` matches input, `subject` non-empty, `bodyText` non-empty
- Log warnings for missing/invalid drafts, continue with valid ones

### 5. Preview mode (default)
- Print old subject vs new subject, old body vs new body for each draft
- Shows company name, industry, prospect name for context

### 6. Apply mode (`--apply`)
- Write backup JSON to `scripts/draft-rewrite-backups/ai-rewrite-{timestamp}.json`
- Update all 5 DB columns per draft (matching `humanize-sales-drafts.ts:537-545`):
  - `subject`, `bodyText`, `bodyHtml` (base columns)
  - `editedSubject`, `editedBodyHtml` (edited columns — send route prefers these)
- `editedBodyHtml` stores plain text (convention in this codebase — send route converts to HTML with tracking at send time)

## Key Files

| File | Role |
|------|------|
| `scripts/humanize-sales-drafts.ts` | Structural template: preview/apply, backup, DB update pattern |
| `scripts/run-followup-batch.ts:20,103-107` | Anthropic SDK usage pattern |
| `src/app/api/send/route.ts:141-153` | Send-path column precedence to satisfy |
| `src/db/schema.ts:34-62, 66-106, 108-146` | Table schemas for companies, prospects, emailDrafts |

## Verification

1. Run `npx tsx scripts/ai-rewrite-sales-drafts.ts` — should show 5 before/after previews
2. Inspect output: subjects should be specific (not generic), bodies should be 4-6 sentences, signed `- Johnathan`
3. Run `npx tsx scripts/ai-rewrite-sales-drafts.ts --apply` — should write backup + update DB
4. Check dashboard at `/drafts` — rewritten drafts should display correctly
