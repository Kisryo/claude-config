# TAB-111 — Make Shield Pop Up When Timed Break Expires

## Context

When a user's timed-access grant expires while they are *actively using* the distracting app, the shield does not visually reappear over the running app. Today they only see the shield on next launch. The goal: make the shield surface as close to "instantly" as iOS allows.

**Hard constraint from research (4 parallel web searches, agent reports in conversation):**
iOS's Screen Time shield is a launch-time gate. There is **no supported API** to force the shield overlay onto a foreground app. Apple forum threads (807934, 750623, 766643) and Apple FB14237883 confirm this. Commercial apps (one sec, Opal, ScreenZen, Brick) *do not* truly interrupt running sessions either — they stack mechanisms that cause iOS to re-evaluate foreground state.

**The technique that works (and the industry standard):**
- Mutate `store.shield.applications` from a `DeviceActivityMonitor` extension on `intervalDidEnd` — queues the shield.
- Fire a **local notification at T+0** — the banner slides SpringBoard in front of the running app for a fraction of a second. iOS re-evaluates foreground state on that transition, and the queued shield lands. Without the notification, the shield is queued but invisible until the next background/foreground cycle (which might not happen for a while if the user keeps scrolling).

## Current State (post-rebase, uncommitted)

Already wired up in the merged branch:

- `MojoiOS/Core/ScreenTime/TimedAccessManager.swift`
  - `grantAccess(appToken:minutes:)` calls `scheduleRelock` (in-process timer), `scheduleExpiryWarningNotification` (T-1 warning), and `scheduleDeviceActivityReblock` (extension-based reblock).
  - `scheduleDeviceActivityReblock` writes the serialized token to shared defaults and registers a `DeviceActivitySchedule` whose `intervalDidEnd` fires at expiry.
  - `revokeAccess` and `handleExpiry` cancel the schedule and T-1 warning and clean up shared defaults.

- `MojoDeviceActivity/DeviceActivityMonitorExtension.swift`
  - `intervalDidEnd(for:)` detects the `reblockActivityPrefix` and calls `reapplyShieldForExpiredBreak(slug:)` which inserts the specific `ApplicationToken` back into `store.shield.applications`.

- `ScreenTimeConstants.swift` (both copies)
  - `reblockActivityPrefix`, `reblockTokenKeyPrefix`

**What's missing: the T+0 notification that triggers iOS to surface the queued shield.**

## Change

Add a single T+0 "Time's up" local notification scheduled alongside the existing T-1 warning. Mirror the existing `scheduleExpiryWarningNotification` pattern exactly — same helpers, same cancellation hooks, same appName resolution via `screenTimeManager.tokenNameCache()`.

### Files to modify

**`MojoiOS/Core/ScreenTime/TimedAccessManager.swift`**

1. Add `scheduleExpiryNotification(appToken:expiryDate:)`:
   - Body: `"Time's up — your \(appName) break is over. It's blocked again."`
   - Title: `"Argo"`
   - Trigger: `UNCalendarNotificationTrigger` at `expiryDate` (mirrors the T-1 warning trigger).
   - Skip if `expiryDate <= Date()` (no firing in the past).
   - App-name resolution: extract shared helper (or inline-duplicate) from `scheduleExpiryWarningNotification`.

2. Add `expiredNotificationIdentifier(for:)` — distinct id, e.g. `"timed-access-expired-\(appToken.hashValue)"`.

3. Add `cancelExpiryNotification(appToken:)` mirroring `cancelExpiryWarningNotification`.

4. Call `scheduleExpiryNotification` from `grantAccess` next to the existing two scheduling calls.

5. Call `cancelExpiryNotification` from `revokeAccess` and `handleExpiry` (next to the existing T-1 cancellation).

### Files NOT modified

- `MojoDeviceActivity/DeviceActivityMonitorExtension.swift` — already correct (`intervalDidEnd` reblock path exists).
- `BlockerInterventionView.swift` — no signature change to `grantAccess`.
- `ScreenTimeConstants.swift` — no new constants needed.

## Why this and not the `DeviceActivityEvent` threshold trick

Agent 4's research suggested a `DeviceActivityEvent` with `threshold: 1 minute, includesPastActivity: true` as a secondary trigger. Rejected for this task:
- `includesPastActivity: true` would fire *immediately* during the grant itself (user has prior usage today), breaking the break.
- A second schedule starting *at* expiry adds complexity and a second `intervalDidEnd` that overlaps our current one.
- `intervalDidEnd` on the existing schedule is already the T+0 trigger for the shield-apply; adding a threshold in the same window doesn't help if `intervalDidEnd` itself fails.
- Keep scope tight — the notification-at-T+0 is the proven delta.

## Verification

1. Build: `xcodebuild -scheme MojoiOS -configuration Debug build` (or `mcp__XcodeBuildMCP__build_sim` with saved defaults).
2. Manual device test (simulator is unreliable for Screen Time per project memory):
   - Select Instagram (or any shielded app) in Mojo.
   - Trigger shield → Argo chat → grant a 1-minute break.
   - Immediately enter the unblocked app and stay there.
   - At T=0, confirm:
     - The "Time's up" banner appears.
     - Within ~1s of the banner, the Mojo shield overlay takes over the app.
   - Relaunch Instagram — shield still active (sanity check the reblock held).
3. Edge case: grant for 1 minute, end early via `TimedAccessCountdownPill` — confirm the "Time's up" notification does NOT fire (cancellation wired).
4. Edge case: foreground the Mojo app before expiry — `scheduleRelock` in-process path fires; verify no duplicate notification (same identifier is cancelled in `handleExpiry`).
