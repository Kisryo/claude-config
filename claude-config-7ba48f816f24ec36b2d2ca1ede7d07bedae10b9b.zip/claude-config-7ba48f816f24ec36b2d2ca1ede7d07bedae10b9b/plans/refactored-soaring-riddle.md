# Ship Argue build 8 to TestFlight Beta Review

## Context

Apple rejected **build 6** on 2026-04-13 under Guideline 2.3 (Accurate Metadata), claiming `UIRequiredDeviceCapabilities` blocked iPad install. The real cause was iPad install failure from an iPhone-only app (`TARGETED_DEVICE_FAMILY=1`) that TestFlight won't force-install on iPad. User confirmed Argue stays iPhone-only.

**Evolution during resolution:**
1. Build 6 can't be resubmitted via API — `externalBuildState=BETA_REJECTED` is a sticky state; `asc builds add-groups --submit` and `asc testflight review submit` both reject it. Only ASC UI can re-submit, but by the time we learned this we had already removed build 6 from the Public Beta group, so the simplest path became "upload a new build."
2. **Beta App Review notes already updated on ASC** with an iPhone-only clarification paragraph (done via `asc testflight review edit --id 6761279161 --notes ...` at the start of the session — still in place, no need to redo).
3. **Build 7 was built + uploaded** from branch `testflight/build-7`, but ASC validation rejected it with four Info.plist errors (real messages pulled from Apple's email — not visible via asc API which returns codes only):
   - `ITMS-90349` — `MojoDeviceActivity.appex`: `NSExtensionPointIdentifier=com.apple.deviceactivity.monitor` is no longer valid; modern iOS requires `com.apple.deviceactivity.monitor-extension` suffix.
   - `ITMS-90358` — `MojoDeviceActivityReport.appex`: missing `NSExtensionPrincipalClass`.
   - `ITMS-90360` × 2 — `MojoShieldAction.appex` and `MojoShieldConfig.appex`: missing `CFBundleDisplayName`.
4. **Build 8 code fixes committed** on `testflight/build-7` at HEAD `9c7ca77` (not yet pushed). Archive was kicked off (PID 28850, log at `/tmp/build8-archive.log`) moments before plan mode was re-entered; it may have completed or been superseded — always re-check state on resume.

**Intended outcome:** Upload build 8 (1.0/8) to ASC, get it through processing, add to Public Beta group with Beta Review submission, land `betaReviewState=APPROVED`, and the public TestFlight link at https://testflight.apple.com/join/7EpKtqWA becomes installable on iPhone again.

## Current state (verify before acting)

- **Branch:** `testflight/build-7` (keep the branch name; the product bumped to build 8 mid-flight).
- **HEAD commit:** `9c7ca77 fix(ios): address ITMS Info.plist errors for build 8` — includes plist fixes + `CURRENT_PROJECT_VERSION` 7 → 8 across all 16 build configs.
- **Not yet pushed:** `9c7ca77`. Earlier commits (`e375921`, `0361d8c`, `4ab5d45`) are on origin.
- **Backup branch:** `testflight-strip-monitor` is pushed to origin at commit `d1b3da0` — preserves the pre-refactor snapshot. Leave it alone.
- **ASC beta review notes:** already contain the iPhone-only paragraph. Don't re-edit.
- **ASC build 6 state:** `externalBuildState=BETA_REJECTED`, removed from Public Beta group. Ignore — we're replacing it with build 8, not resurrecting it.
- **Public Beta group ID:** `9c72916d-c7b7-49cb-9c62-a3869851500d`.
- **ASC app ID:** `6761279161`.

### Known toolchain gotcha (must apply)

`xcodebuild -exportArchive` fails with `Copy failed` because `/usr/bin/rsync` (Apple openrsync 2.6.9-compatible) spawns its server half via PATH and lands on Homebrew's rsync 3.4.1, which rejects the `-E` flag (`--extended-attributes`). **Always run exportArchive with a sanitized PATH**: `PATH=/usr/bin:/usr/sbin:/bin:/sbin xcodebuild -exportArchive ...`. Archive and simulator builds are unaffected — only exportArchive needs this.

## Steps

### 1. Verify archive state

Check whether the background archive from before plan-mode re-entry finished.

```bash
kill -0 28850 2>/dev/null && echo "archive still running" || echo "archive done or killed"
grep -E "ARCHIVE SUCCEEDED|ARCHIVE FAILED" /tmp/build8-archive.log | tail -3
ls -la /tmp/build8.xcarchive 2>&1 | head -3
```

- If archive present + log shows `ARCHIVE SUCCEEDED` → skip to step 3.
- Otherwise → step 2.

### 2. Archive (if needed)

```bash
rm -rf /tmp/build8.xcarchive /tmp/build8-ipa
xcodebuild -project Mojo.xcodeproj \
  -scheme MojoiOS \
  -configuration Release \
  -destination 'generic/platform=iOS' \
  -archivePath /tmp/build8.xcarchive \
  archive \
  > /tmp/build8-archive.log 2>&1 &
```

Monitor: `grep -E "ARCHIVE SUCCEEDED|ARCHIVE FAILED|error: " /tmp/build8-archive.log`. Expect `** ARCHIVE SUCCEEDED **` after ~3–5 minutes.

### 3. Export .ipa with sanitized PATH

Export options plist already exists at `/tmp/build7-export-options.plist` (reuse for build 8 — same `app-store-connect` / `teamID=BJLT45779D` / `signingStyle=automatic`).

```bash
mkdir -p /tmp/build8-ipa
PATH=/usr/bin:/usr/sbin:/bin:/sbin xcodebuild -exportArchive \
  -archivePath /tmp/build8.xcarchive \
  -exportPath /tmp/build8-ipa \
  -exportOptionsPlist /tmp/build7-export-options.plist \
  > /tmp/build8-export.log 2>&1
```

Success criterion: `/tmp/build8-ipa/MojoiOS.ipa` exists (~11 MB). If `Copy failed`, double-check PATH sanitization actually took effect.

### 4. Sanity-check the .ipa before upload

This catches ITMS errors locally so we don't waste another round-trip.

```bash
cd /tmp && rm -rf ipa-check && mkdir ipa-check && cd ipa-check && unzip -q /tmp/build8-ipa/MojoiOS.ipa

# Confirm the 4 ITMS fixes
plutil -p Payload/MojoiOS.app/PlugIns/MojoDeviceActivity.appex/Info.plist | grep NSExtensionPointIdentifier
# Expect: com.apple.deviceactivity.monitor-extension

plutil -p Payload/MojoiOS.app/PlugIns/MojoDeviceActivityReport.appex/Info.plist | grep NSExtensionPrincipalClass
# Expect: MojoDeviceActivityReport.MojoDeviceActivityReportExtension

plutil -p Payload/MojoiOS.app/PlugIns/MojoShieldAction.appex/Info.plist | grep CFBundleDisplayName
plutil -p Payload/MojoiOS.app/PlugIns/MojoShieldConfig.appex/Info.plist | grep CFBundleDisplayName
# Expect both present

plutil -p Payload/MojoiOS.app/Info.plist | grep CFBundleVersion
# Expect: CFBundleVersion => "8"

# Confirm distribution signing
codesign -d --entitlements :- Payload/MojoiOS.app 2>&1 | grep -o "get-task-allow.*false" && echo "OK: distribution signed"
```

### 5. Upload to ASC

```bash
asc builds upload --app 6761279161 --ipa /tmp/build8-ipa/MojoiOS.ipa --wait > /tmp/build8-upload.log 2>&1
```

`--wait` polls until the build either appears as VALID in ASC or the upload fails validation. Runs ~5–15 min (upload ≈ 1–2 min, processing ≈ 5–10 min).

**If it fails with new ITMS codes**, read Apple's email (codes alone are not enough — asc API returns codes only). The user has access to the developer email at `2023johnathanmo@gmail.com`.

### 6. Push the branch

Only after upload succeeds.

```bash
git push origin testflight/build-7
```

### 7. Add build 8 to Public Beta + submit for Beta Review

After upload processing finishes, ASC assigns a new build UUID. Resolve it:

```bash
BUILD8_ID=$(asc builds find --app 6761279161 --build-number 8 --pretty 2>/dev/null | python3 -c "import json,sys; print(json.load(sys.stdin)['data'][0]['id'])")
echo "build 8 id: $BUILD8_ID"
```

Then:

```bash
asc builds add-groups \
  --build "$BUILD8_ID" \
  --group 9c72916d-c7b7-49cb-9c62-a3869851500d \
  --submit --confirm
```

This adds the build to the Public Beta group AND submits it for Beta App Review in one call — the path that was blocked for build 6 works fine for a fresh build.

### 8. User action — Resolution Center reply (manual)

No CLI equivalent exists. The user opens https://appstoreconnect.apple.com/apps/6761279161/resolutioncenter and replies with the text from the original plan:

> Hi — thanks for the review. Argue is intentionally iPhone-only: `TARGETED_DEVICE_FAMILY` is set to `1` and the app declares `UIDeviceFamily=[1]` in the built Info.plist. There is no `UIRequiredDeviceCapabilities` key in the Info.plist. The build is designed to install on iPhone only; iPad is not a supported device family for this product. Build 8 re-uploads with identical intent and fixes four unrelated Info.plist warnings Apple surfaced on the previous build. Please re-review on iPhone 17 Pro Max (iOS 26.4) — the core flow (onboarding → FamilyActivityPicker → tap blocked app → Argue with Argo) is iPhone-native.

Remind the user this step is blocking for Apple's reviewer to see our clarification alongside the new build.

### 9. Poll for Beta Review approval

```bash
asc builds beta-app-review-submission view --build "$BUILD8_ID" --pretty
# expect betaReviewState: WAITING_FOR_REVIEW → IN_REVIEW → APPROVED
```

When APPROVED, https://testflight.apple.com/join/7EpKtqWA installs on iPhone again.

## Critical files modified in this branch

- `MojoDeviceActivity/Info.plist` — `NSExtensionPointIdentifier` corrected to `com.apple.deviceactivity.monitor-extension`.
- `MojoDeviceActivityReport/Info.plist` — added `NSExtensionPrincipalClass = $(PRODUCT_MODULE_NAME).MojoDeviceActivityReportExtension`.
- `MojoShieldAction/Info.plist` — added `CFBundleDisplayName = "Argue Shield Action"`.
- `MojoShieldConfig/Info.plist` — added `CFBundleDisplayName = "Argue Shield"`.
- `Mojo.xcodeproj/project.pbxproj` — `CURRENT_PROJECT_VERSION = 8` across all 16 configs.
- `MojoiOS/Info.plist` — `ITSAppUsesNonExemptEncryption=false` (retained from earlier commit).
- `MojoiOS/MojoiOS.entitlements` + `MojoDeviceActivityReport/MojoDeviceActivityReport.entitlements` — stripped unused `com.apple.developer.family-controls.app-and-website-usage` (retained from earlier commit).
- `MojoiOS/Core/Social/SocialService.swift` — cache hydration fix (retained from cherry-pick).
- `firebase/firebase.json`, `firebase/public/{index,privacy}.html`, `firebase/.gitignore` — hosting config (retained from cherry-pick).
- `MojoiOS/Assets.xcassets/AppIcon.appiconset/AppIcon.png` — smaller icon (retained from cherry-pick).

## Do NOT re-do

- Beta App Review notes on ASC — already updated. Re-editing would just append junk.
- Build 6 resubmission — the build is in `BETA_REJECTED` externally and the API won't resubmit it. Build 8 replaces it entirely.
- `UIDeviceFamily=[1]` explicit key in `MojoiOS/Info.plist` — we added it then reverted after it caused validator to reject the upload (conflicts with `isOptedInToDistributeIosAppOnMacAppStore=true` on ASC). Xcode still injects `UIDeviceFamily=[1]` at build time from `TARGETED_DEVICE_FAMILY=1`, which is what the Beta reviewer sees in the .ipa.
- Un-embedding `MojoDeviceActivity.appex` — that was the strip-monitor workaround for the exact ITMS-90349 we've now fixed at the source. Keep the extension embedded.

## Verification

1. Simulator build: `xcodebuild -project Mojo.xcodeproj -scheme MojoiOS -configuration Debug -sdk iphonesimulator build` — sanity check after any further edits.
2. `.ipa` inspection per step 4 above (all 4 ITMS fixes visible, `CFBundleVersion=8`, distribution signing).
3. `asc builds upload --wait` returns success (build appears as VALID).
4. `asc builds beta-app-review-submission view --build "$BUILD8_ID"` reaches `APPROVED`.
5. Install from https://testflight.apple.com/join/7EpKtqWA on iPhone.
