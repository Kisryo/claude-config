# Friends Feature: Fix-Broken + UI Redesign

## Context

The Friends tab in MojoiOS looks finished but is silently broken in three major ways:

1. **Activity feed is permanently empty.** `ActivityFeedService.createEvent()` is never called anywhere in the iOS codebase, and no Cloud Function writes `activityEvents` either. The `ActivityFeedSection` UI is built and rendering — it just has no input.
2. **Challenge live scores never display.** Progress is *written* to `challenges/{id}/progress/{dateKey}` but never *read back*; `ChallengeDetailView` shows hardcoded `creatorScore: 0`, `opponentScore: 0`, `dailyScores: []` placeholders.
3. **Challenge completion never celebrates.** `ChallengeCompletionView` is wired to `FriendsTabView.fullScreenCover(item: $completedChallenge)` but `completedChallenge` is never set anywhere; behavioral challenges always score 0; `ChallengeHistoryView` exists but no nav reaches it.

Beyond the broken bits, the feature has structural problems the user surfaced as "more accurate data (idk where it's coming from)":

- Leaderboard ranks by `grantedMinutes` (minutes Argo granted after blocker negotiation — semantically "wasted minutes after losing the argument"). User wants to rank by **daily screen time** instead, which means we need to start syncing our locally-persisted `DailyScreenTime.totalMinutes` to Firestore.
- Long-term theme: stop being a thin wrapper over Apple's opaque DeviceActivity API; own a server-side mirror of the data we collect. This PR does the minimum (sync today's totals); deeper ownership (hourly bins, server-side history) is flagged as fast-follow.

Performance smells that user called out as "load faster":
- Weekly leaderboard does 1 + (N × 7) Firestore reads per fetch (no batching).
- `FriendProfile.lastSynced` exists but is never checked — no TTL, no stale-while-revalidate.
- Cold launch sets `hasFetchedFriends = true` immediately after cache load, so stale cache appears authoritative.
- Pull-to-refresh fires 4 parallel fetches with no deduplication.

**Outcome of this PR:** Friends tab actually works end-to-end (events flow, scores update, completions celebrate), ranks by a metric that matches user mental model, loads faster on cold start, and gets a focused visual cleanup using existing components (no new design language).

---

## Approach

### 1. Activity event emission — Cloud Functions, not iOS

Move event emission server-side. Existing Cloud Functions (`onChallengeCreated`, `onChallengeAccepted`, `onChallengeCompleted`, `onFriendRequestAccepted`) already trigger on the underlying Firestore writes and have the data they need. Add `db.collection("activityEvents").add({...})` calls inside each.

- Build `visibleTo` server-side by querying `friendships` for the actor's accepted friends + actor themselves.
- **Delete** `ActivityFeedService.createEvent()` (it would become drift bait if left in).
- Tighten `firestore.rules` for `activityEvents`: change `allow create: if request.auth.uid in request.resource.data.visibleTo` → `allow create: if false` (Cloud Functions admin SDK bypasses rules).
- Keep `ActivityFeedService.fetchFeed()` as-is on the iOS side — read-only.

**Files:** `firebase/functions/index.js`, `firebase/firestore.rules`, `MojoiOS/Core/Social/ActivityFeedService.swift`.

### 2. Challenge live progress — snapshot listener scoped to detail view

`ChallengeDetailView` adds a Firestore snapshot listener on `challenges/{id}/progress` for its own lifetime. Attach in `.onAppear`, store `ListenerRegistration` in `@State`, detach in `.onDisappear`. Also subscribe to the parent `challenges/{id}` doc so `winnerId` flips live.

- New `ChallengeService.observeProgress(challengeId:) -> AsyncStream<ChallengeProgressSnapshot>` (or registered listener helper). Reuse the existing `progress/{dateKey}` schema.
- Replace placeholder constants in `ChallengeDetailView` with state populated from the listener.
- Keep the 30s `syncProgress()` foreground tick — it's the *write* path; the listener is the *read* path. They don't conflict.

**Files:** `MojoiOS/UI/Friends/ChallengeDetailView.swift`, `MojoiOS/Core/Social/ChallengeService.swift`.

### 3. Challenge completion celebration — listener-driven

`FriendsTabView` already has `@State completedChallenge: Challenge?` and `.fullScreenCover(item: $completedChallenge)` wired to `ChallengeCompletionView`. The missing piece: code that sets `completedChallenge` when a completion arrives.

- Add `Challenge.completionUIShown: Bool` (SwiftData, local-only, default false).
- `ChallengeService` adds a snapshot listener on the user's challenges where `status == .completed`. When a row arrives whose local `completionUIShown == false`, publish via `@Observable var pendingCompletion: Challenge?`.
- `FriendsTabView.task` observes `challengeService.pendingCompletion` and assigns it to `completedChallenge`. On `onDismiss`, mark `completionUIShown = true` and clear `pendingCompletion`.
- Keep iOS-side `evaluateCompletion()` as fast-path (user opening app sees results immediately even if Cloud Function hasn't fired). Add a guard: skip if `status != .active` to avoid racing the Cloud Function.

**Files:** `MojoiOS/Models/Challenge.swift`, `MojoiOS/Core/Social/ChallengeService.swift`, `MojoiOS/UI/Friends/FriendsTabView.swift`.

### 4. Behavioral challenges — hide for now

`ChallengeService.computeProgress` returns 0 for `.behavioral` because there's no check-in mechanism. Options were: build check-in UI, hide the type, or accept ties. Hide for now.

- Remove `.behavioral` from `CreateChallengeSheet` preset list.
- Existing `.behavioral` challenges (if any in the wild) keep their detail view; just no new ones can be created.

**Files:** `MojoiOS/UI/Friends/CreateChallengeSheet.swift`.

### 5. Leaderboard metric → daily screen time

Switch the metric, **lower is better, ascending sort**.

- `LeaderboardEntry` adds `screenTimeMinutes: Int?` (optional — missing data shows as "—" not 0).
- `LeaderboardService.fetchUserStats` reads `users/{friendId}/dailyStats/{dateKey}.screenTimeMinutes`. If absent, return nil for that field; filter nil entries out of the rank or render them at the bottom with "—" pill.
- Sort: `screenTimeMinutes` ascending. Nil entries pushed to the end.
- Update row UI: subtitle shows screen time (e.g., "2h 14m today") instead of `Xm` granted.

**Files:** `MojoiOS/Core/Social/LeaderboardService.swift`, `MojoiOS/UI/Friends/LeaderboardRowView.swift`, `MojoiOS/UI/Friends/LeaderboardListView.swift`, `MojoiOS/UI/Friends/LeaderboardPodiumView.swift`.

### 6. Screen time push to Firestore — extend `StatsSyncService`

Add `screenTimeMinutes` to the `dailyStats/{dateKey}` doc.

- New `StatsSyncService.syncScreenTime(minutes: Int)` writes `{ "screenTimeMinutes": minutes, "lastUpdated": serverTimestamp() }` with `merge: true`.
- Trigger: hook into the existing `screenTimeTracker.onSnapshotApplied` callback in `DependencyContainer.configureMemoryService` (already wired for the history service). Add a 60-second debounce coalesce inside `StatsSyncService` (DeviceActivity can fire many times per session; we don't need to write each one).
- Privacy toggle: add `UserProfile.shareScreenTimeWithFriends: Bool` (defaults true). Skip the write when off. Surface in `SocialSettingsView` as a single switch.
- Migration: existing `dailyStats` docs simply lack the field. `LeaderboardService` already handles nil — they show "—" until the user's app pushes its first snapshot.

**Files:** `MojoiOS/Core/Social/StatsSyncService.swift`, `MojoiOS/Core/DependencyContainer.swift`, `MojoiOS/Models/UserProfile.swift`, `MojoiOS/UI/Settings/SocialSettingsView.swift`.

### 7. Weekly rollup denormalization

Replace N×7 reads with N reads.

- New collection: `users/{userId}/weeklyStats/{weekKey}` (ISO `yyyy-Www`). Fields: `totalScreenTimeMinutes: Int`, `dayCount: Int`, `lastUpdated: Timestamp`.
- Same trigger as #6: when `syncScreenTime` runs, also update the current week's rollup. Use a Firestore transaction to read-modify-write `totalScreenTimeMinutes` (subtract today's prior value, add new value) and `dayCount`.
- `LeaderboardService.fetchLeaderboard(.week)` becomes 1 + N reads against `weeklyStats`.
- `firestore.rules` mirror `dailyStats` access (self + friends read, self write).

**Files:** `MojoiOS/Core/Social/StatsSyncService.swift`, `MojoiOS/Core/Social/LeaderboardService.swift`, `firebase/firestore.rules`.

### 8. Caching, dedup, and load states

- **TTL on FriendProfile:** 5 minutes (300s). `SocialService.fetchFriends` checks `lastSynced` before kicking off network refresh; serves cache immediately, refreshes in background, swaps when fresh.
- **Request dedup:** each service-level `fetch*` method gets a `private var inFlightTask: Task<Void, Never>?`. New calls await the existing task instead of starting a new one.
- **Cold launch fix:** stop using `hasFetchedFriends = true` from cache load alone. Introduce `enum LoadState { case empty, loadingFromNetwork, freshFromNetwork, staleFromCache }` and make `FriendsTabView` render skeleton on `.empty`, cached data on `.staleFromCache` (no spinner blocking), authoritative on `.freshFromNetwork`. Subtle top-of-section refresh indicator only when `staleFromCache → freshFromNetwork` and data actually differs.
- **Pull-to-refresh:** keep parallel — dedup at service level handles the "user spammed refresh" case for free.

**Files:** `MojoiOS/Core/Social/SocialService.swift`, `LeaderboardService.swift`, `ChallengeService.swift`, `ActivityFeedService.swift`, `MojoiOS/UI/Friends/FriendsTabView.swift`, plus a small new shared `LoadState` enum in `MojoiOS/Core/Social/`.

### 9. UI redesign — focused, no new design language

Constrain to three concrete restructures using existing `MojoCard`, `MojoPillButton`, `MojoTopBar` components and adaptive `Color.Mojo.*` tokens:

- **Hierarchy reorder in `FriendsTabView`:**
  1. Active challenges (top — most actionable when running)
  2. Pending challenges (smaller, when present)
  3. Pending friend requests (when present)
  4. Leaderboard (period toggle, podium, full ranking)
  5. Activity feed (top 5, with "see more" link to a full feed sheet)
  6. Challenge history link (small bottom row)
- **Real empty states** for each section: "Challenge a friend to see scores here" / "Add friends to see ranks" / "Your activity will show here once you finish a challenge or accept a friend." One CTA pill per state.
- **Leaderboard row delta chip:** small "▼ 12m" / "▲ 8m" badge showing change vs yesterday's `screenTimeMinutes` if available. Cheap signal that data is fresh.

Out of scope: new colors, new card variants, new SwiftUI primitives. If a change requires inventing a component beyond an empty-state row or a delta chip, defer.

**Files:** `MojoiOS/UI/Friends/FriendsTabView.swift`, `LeaderboardRowView.swift`, `ActivityFeedSection.swift`, plus small helper files for empty states and the delta chip.

### 10. Privacy and rules

- Add settings switch (covered in #6).
- `firestore.rules` updates: lock `activityEvents` create to false; add `weeklyStats` rules; ensure `screenTimeMinutes` field on `dailyStats` is covered by existing read rule (`self + friends`).

**Files:** `firebase/firestore.rules`.

---

## Files Modified (summary)

**iOS:**
- `MojoiOS/UI/Friends/FriendsTabView.swift` — restructure, completion listener, load state
- `MojoiOS/UI/Friends/ChallengeDetailView.swift` — live snapshot listener
- `MojoiOS/UI/Friends/CreateChallengeSheet.swift` — hide behavioral type
- `MojoiOS/UI/Friends/LeaderboardRowView.swift` / `ListView.swift` / `PodiumView.swift` — new metric + delta chip
- `MojoiOS/UI/Friends/ActivityFeedSection.swift` — empty state polish
- `MojoiOS/UI/Settings/SocialSettingsView.swift` — privacy toggle
- `MojoiOS/Core/Social/ActivityFeedService.swift` — delete `createEvent`
- `MojoiOS/Core/Social/ChallengeService.swift` — observeProgress, completion listener, behavioral guard
- `MojoiOS/Core/Social/LeaderboardService.swift` — switch metric, weekly rollup query
- `MojoiOS/Core/Social/SocialService.swift` — TTL + dedup + load state
- `MojoiOS/Core/Social/StatsSyncService.swift` — `syncScreenTime`, weekly rollup write, debounce
- `MojoiOS/Core/DependencyContainer.swift` — wire screen-time sync hook
- `MojoiOS/Models/Challenge.swift` — `completionUIShown` field
- `MojoiOS/Models/UserProfile.swift` — `shareScreenTimeWithFriends` field

**Backend:**
- `firebase/functions/index.js` — emit `activityEvents` from existing triggers
- `firebase/firestore.rules` — lock `activityEvents` create, add `weeklyStats` rules

---

## Reused existing utilities

- `ScreenTimeHistoryService.dailyTotals(start:end:)` — already returns the today total we'll push.
- `ScreenTimeTracker.onSnapshotApplied` callback — already wired in `DependencyContainer.configureMemoryService`.
- `MojoCard`, `MojoPillButton`, `MojoTopBar`, `Color.Mojo.surfaceCard/.surfaceElevated/.primaryFixed` — entire UI redesign uses these.
- `firestore.rules.areFriends(uid1, uid2)` helper — used for `weeklyStats` access.
- `StatsSyncService.dateKey(for:)` — reuse for `weekKey` derivation.
- Existing Cloud Functions (`onChallengeCreated`, `onChallengeAccepted`, `onChallengeCompleted`, `onFriendRequestCreated`, `onFriendRequestAccepted`, `evaluateChallenges`) — extend, don't add new ones.
- Existing `Challenge.completionUIShown` pattern matches `lastSynced` already used on `FriendProfile`.

---

## Verification

**End-to-end manual test on two physical devices (A and B, both signed in, friends with each other):**

1. **Activity feed flows:** A creates a challenge against B → both A and B see "A challenged B" in their activity feed within ~5s. A accepts a friend request from C → activity feed shows "A and C are now friends."
2. **Live scores:** Open challenge detail on A while B is using their phone. Watch `creatorScore` / `opponentScore` update (may need to grant on B to bump the count).
3. **Completion celebration:** Set a challenge `endDate` to 30 seconds from now via Firestore console. Open the app on A after expiry → `ChallengeCompletionView` presents within seconds without manual refresh.
4. **Behavioral hidden:** Open `CreateChallengeSheet` → preset list shows only `timeTarget` and `appDetox`.
5. **Leaderboard metric:** Confirm rows show `screen time` subtitle, sorted ascending. Friend with no `screenTimeMinutes` field shows "—" at bottom of list.
6. **Screen time push:** Use phone for 10 minutes → check Firestore `users/{uid}/dailyStats/{today}` includes `screenTimeMinutes`. Toggle privacy switch off → trigger another sync → field should not update.
7. **Weekly rollup:** Switch leaderboard period to "week" → confirm in Firestore that `users/{uid}/weeklyStats/{week}` exists and `totalScreenTimeMinutes` matches sum of recent dailyStats.
8. **Caching:** Cold launch with airplane mode → cached friends render instantly without "loading" spinner. Toggle airplane mode off → fresh data swaps in with subtle indicator.
9. **Dedup:** Triple-tap pull-to-refresh → only one network round-trip fires (verify via Firestore usage console or Charles).

**Build verification:**
- `xcodebuild -scheme Mojo -configuration Debug build` clean build
- `xcodebuild -scheme Mojo -configuration Debug test` passes (existing tests only — no new tests written for this PR; flagged as fast-follow)
- `cd firebase && firebase deploy --only functions,firestore:rules` succeeds against the dev project before merge

---

## Out of scope (fast-follow candidates)

- Hourly screen-time bins / true server-side ownership of screen time history
- Behavioral challenge check-in UI
- Activity feed pagination beyond 50
- Real-time Firestore listener for activity feed (manual refresh OK for v1)
- New tests for tool path / streaming / friends services
- ChallengeHistoryView entry point polish (link works but UX is plain)

---

## Risk flags

- **Cloud Function emission + iOS read race:** if the activityEvents write is slow, the user who *triggered* the action might pull-to-refresh before their own event lands. Acceptable; ~1s latency in practice.
- **Snapshot listener leaks:** must verify `.onDisappear` fires reliably through SwiftUI navigation push/pop AND tab switch on iOS 17/18/26. Test on each.
- **iOS-side `evaluateCompletion` race with Cloud Function:** both could try to write `winnerId`. Firestore rules already block client `winnerId` writes; iOS-side eval becomes a no-op for non-creator/non-opponent. Confirmed safe — but add `if status != .active { return }` guard defensively.
- **PR scope is large.** ~13 iOS files + 2 backend files. If this gets unwieldy, split #8 (caching) into a fast-follow PR — it's behind-the-scenes and easy to defer. Everything user-visible (1–7, 9–10) ships together.
