# Plan: Integrate ClaudeChatInput Component

## Context

The current task input in `AgentMain.tsx` (lines 314-471) is a basic textarea with a folder selector and submit button. The goal is to replace it with the richer `ClaudeChatInput` component — which adds file drag-and-drop, pasted content cards, a model selector dropdown, an extended thinking toggle, and polished visual styling.

The component is React (matching the project), but its CSS assumes Tailwind v4 and a different design token namespace. The plan bridges these gaps while preserving the existing Kiln-F design system.

---

## Step 1: Add component's CSS variables to `global.css` (scoped, non-destructive)

**File:** `src/styles/global.css`

Append a new section that maps the component's token names to the project's existing Kiln-F semantic tokens. This avoids any `:root` collisions — the component's Tailwind classes like `bg-bg-200`, `text-text-300` resolve through these aliases.

```css
/* ClaudeChatInput token bridge — maps component tokens → Kiln-F */
:root {
  --bg-0: var(--background);
  --bg-000: var(--background);
  --bg-100: var(--card);
  --bg-200: var(--muted);
  --bg-300: rgba(38, 28, 14, 0.12);       /* slightly stronger than --border for visible edges */
  --text-100: var(--foreground);
  --text-200: var(--secondary-foreground);
  --text-300: var(--muted-foreground);
  --text-400: rgba(136, 136, 136, 1);      /* mid-gray placeholder */
  --text-500: rgba(153, 153, 153, 1);      /* lighter placeholder */
  /* --accent is already defined in the project as a tint; override for solid usage */
  /* We do NOT override --accent. Instead the component will use --primary for solid accent. */
}
```

**Key decision:** The component hardcodes `--accent: #D97757` as a **solid color** for the send button, but the project's `--accent` is a **transparent tint** (`rgba(194, 65, 12, 0.08)`). Rather than clobbering `--accent`, we'll edit the component to use the Tailwind class `bg-primary` / `text-primary` where it currently uses `bg-accent` for solid-color buttons.

Also extend `tailwind.config.ts` colors to include the new token names so utility classes like `bg-bg-200`, `text-text-300` resolve.

**Dark mode:** Add `[data-theme='dark']` overrides for the bridged tokens alongside the existing dark block.

---

## Step 2: Extend `tailwind.config.ts` with component token colors

**File:** `tailwind.config.ts`

Add to `theme.extend.colors`:

```ts
"bg-0": "var(--bg-0)",
"bg-000": "var(--bg-000)",
"bg-100": "var(--bg-100)",
"bg-200": "var(--bg-200)",
"bg-300": "var(--bg-300)",
"text-100": "var(--text-100)",
"text-200": "var(--text-200)",
"text-300": "var(--text-300)",
"text-400": "var(--text-400)",
"text-500": "var(--text-500)",
```

This lets Tailwind classes like `bg-bg-200`, `text-text-300`, `border-bg-300` resolve correctly without any Tailwind v4 `@theme inline` syntax.

Also add `animate-fade-in` keyframe + animation used by the component.

---

## Step 3: Create `ClaudeChatInput.tsx` in `src/components/ui/`

**File:** `src/components/ui/claude-style-chat-input.tsx`

Copy the provided component with these adaptations:

1. **Replace all `bg-accent` / `text-accent` Tailwind classes** used for solid button colors with `bg-primary` / `text-primary` (or `bg-brand-500`). Keep `accent` usage only where it means the transparent tint.
2. **Replace all `dark:` prefixed classes** with manual CSS or remove them (the token bridge handles dark mode automatically since all tokens resolve to CSS vars that are already swapped by `[data-theme='dark']`). For inline `dark:bg-[#xyz]` hardcoded colors, replace with token-based equivalents.
3. **Replace the hardcoded models array** inside the component with the project's `AVAILABLE_MODELS` from `src/stores/settings.ts`, grouped by provider.
4. **Wire the `onSendMessage` prop** to accept the same shape but forward to the Zustand store in the parent.
5. **File attachment functionality**: Keep the drag-and-drop and paste file handling as-is — it's self-contained client-side File API logic. The file data will be passed up via `onSendMessage` for the parent to handle (even if the parent doesn't use it yet).
6. **Remove the `font-serif` / `font-sans` overrides** in inline classes — let inherited Kiln-F fonts apply.
7. **Remove `@import "tailwindcss"` and `@import "tw-animate-css"`** — these are Tailwind v4 directives not needed in v3.

---

## Step 4: Create the demo page (optional, for testing)

**File:** `src/components/ui/claude-chat-input-demo.tsx`

A simplified version of the provided `demo.tsx`, adapted to use the project's design tokens. Replace the external image URL with the app's logo or remove it. This is for standalone visual testing only.

---

## Step 5: Replace the input area in `AgentMain.tsx`

**File:** `src/components/AgentMain.tsx`

Replace lines 314-471 (the `{/* Input area */}` through folder chips) with:

```tsx
<ClaudeChatInput
  onSendMessage={({ message, files, pastedContent, model, isThinkingEnabled }) => {
    const projectPath = selectedPaths.length > 0 ? selectedPaths.join(",") : undefined;
    if (isInConversation) {
      continueTask(message, projectPath);
    } else {
      const firstLine = message.split("\n")[0];
      const title = firstLine.length > 50 ? firstLine.slice(0, 50) + "..." : firstLine;
      startNewTask(title, message, projectPath);
    }
  }}
/>
```

The component manages its own textarea state, file attachments, model selection, and thinking toggle internally. The parent only receives the final send payload.

**Preserve:** The folder selector (`selectedPaths`, `handleAddFolders`, `handleRemovePath`) stays in `AgentMain` for now — it uses Tauri's native dialog API. We can wire it into `ClaudeChatInput` as a follow-up. The existing folder chips below the input remain.

---

## Step 6: Clean up orphaned CSS

**File:** `src/components/AgentMain.css`

After the replacement, these CSS classes become dead code and can be removed:
- `.agent-form`, `.input-container`, `.input-container.focused`
- `.input-toolbar`, `.toolbar-left`
- `.folder-toggle`, `.folder-toggle.active`, `.folder-toggle-label`
- `.new-chat-btn`
- `.submit-btn`, `.send-icon`

Keep `.agent-input-area` (the wrapper) and `.folder-chips` / `.folder-chip` etc.

---

## Files to Modify

| File | Action |
|------|--------|
| `src/styles/global.css` | Add CSS variable bridge + dark mode overrides + fadeIn keyframe |
| `tailwind.config.ts` | Add component token colors + fadeIn animation |
| `src/components/ui/claude-style-chat-input.tsx` | **Create** — adapted component |
| `src/components/ui/claude-chat-input-demo.tsx` | **Create** — optional demo page |
| `src/components/AgentMain.tsx` | Replace input area (lines ~314-471) with `<ClaudeChatInput>` |
| `src/components/AgentMain.css` | Remove orphaned input CSS classes |

## No New Dependencies

- `lucide-react` — already installed
- `tailwindcss-animate` — already installed
- `clsx` + `tailwind-merge` — already installed (via `cn()`)
- No `tw-animate-css` needed (Tailwind v4 package, not compatible)

---

## Verification

1. `npx tsc --noEmit` — TypeScript type check passes
2. `npm run dev` (or `npm run tauri:dev`) — visual inspection:
   - Empty state shows the new chat input with model selector, thinking toggle, send button
   - Type text → send button activates → Enter submits → task starts
   - Drag a file onto the input → file preview card appears
   - Paste a long text → pasted content card appears
   - Model selector dropdown opens and lists available models
   - Dark mode toggle works (if the app has one)
3. `cd src-tauri && cargo check && cargo clippy -- -D warnings` — Rust checks pass (no Rust changes, but verify nothing broke)
