# Turn off email OTP / verification code on signup

## Context

New users signing up at `/signup` are being prompted for a 6-digit email verification code (or a confirmation link) before they can access the app. The user wants this removed so signup lands the user straight on `/home` after submitting the form.

The 6-digit code is **Supabase's "Confirm email" feature**, configured at the project level in the Supabase dashboard. It is NOT TOTP — the codebase already has TOTP disabled (see `TOTP_DISABLED` markers across `lib/supabase/middleware.ts`, `lib/auth/session.ts`, `app/(auth)/login/page.tsx`).

The signup code is already written for the "no email confirmation" world:
- `app/(auth)/signup/page.tsx:87-90` comments explicitly state *"Email confirmation is disabled in Supabase project settings for the MVP — signUp() returns a live session immediately."*
- `app/(auth)/signup/page.tsx:104-105` redirects to `/home` immediately after `signUp()` resolves.

So the code is consistent with email confirmation being OFF — but somewhere along the way the dashboard toggle got flipped (or was never flipped in this Supabase project). **The fix is a dashboard setting change, with no code edits required.**

## Recommended approach

### Step 1 — Supabase Dashboard (the only required change)

1. Open https://supabase.com/dashboard
2. Select the flutterli-mvp project (the one referenced by `NEXT_PUBLIC_SUPABASE_URL` in `.env.local`)
3. Navigate to **Authentication → Providers → Email**
4. Turn **OFF** the **"Confirm email"** toggle
5. Save

After this, `supabase.auth.signUp()` will return an authenticated session synchronously, and the form's existing `router.push("/home")` will carry the user straight into the app.

### Step 2 — Verify no code is reachable by email confirmation links

No code changes needed, but confirm the following files continue to behave correctly:

- `app/(auth)/signup/page.tsx` (signup form) — no change, already assumes no confirmation step
- `app/auth/callback/route.ts` — **leave in place**. It handles `exchangeCodeForSession` for password-reset magic links and any OAuth flow you might add later. The `TOTP_DISABLED` comment on line 5 is still accurate (unrelated to email confirmation).
- The comment at `app/(auth)/signup/page.tsx:87-90` will once again match reality and does not need edits.

### Step 3 — Out of scope (do NOT touch)

- `/setup-totp` page and `TOTP_DISABLED` markers — unrelated to this change; leave alone
- `/login` page TOTP step — already disabled independently; leave alone
- Middleware AAL enforcement in `lib/supabase/middleware.ts` — already disabled; leave alone

## Critical files (reference, no edits)

- `/Users/johnathanmo/flutterli-mvp/app/(auth)/signup/page.tsx` — signup form, lines 91-105
- `/Users/johnathanmo/flutterli-mvp/app/auth/callback/route.ts` — still used for other flows
- `/Users/johnathanmo/flutterli-mvp/.env.local` — identifies which Supabase project to edit in the dashboard

## Verification

1. In an incognito window, go to `/signup`
2. Submit a fresh email + password + display name
3. **Expected:** redirect lands on `/home` immediately, no verification code or "check your email" screen
4. Check the new user's inbox — there should be no "Confirm your email" message from Supabase
5. Log out, then log in at `/login` with the same credentials — should sign in on the first try (no "please confirm your email first" error)

If step 3 still shows a verification screen, double-check you edited the correct Supabase project (match the `NEXT_PUBLIC_SUPABASE_URL` project reference ID to the dashboard URL).
