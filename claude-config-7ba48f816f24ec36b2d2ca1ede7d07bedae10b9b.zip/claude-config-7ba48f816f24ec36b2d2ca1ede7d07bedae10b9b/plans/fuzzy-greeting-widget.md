# Fix: Slow Time-to-First-Token for Local Ollama Models

## Context

The app takes >60 seconds before first thinking token when using qwen3.5:27b via Ollama, while Ollama's own chat app streams instantly. The bottleneck is NOT the model — it's our code path between "user sends message" and "Ollama receives HTTP request."

## Root Causes (in order of impact)

### 1. Tool schemas bloat the prompt — ~5,000+ input tokens for Ollama to prefill

The app sends 11 built-in tool definitions + any MCP tools as `"tools"` in the OpenAI request. Each tool schema is ~200-500 tokens. Ollama converts these to system prompt tokens internally. A 27B model processes input at ~100-300 tok/s, so 5K tokens of tool schemas alone = **17-50 seconds of prefill** before any output.

Ollama's own chat sends ZERO tools. That's why it's instant.

**Fix:** For the first message in a conversation (no tool calls yet), skip sending tools entirely. The model can plan and think without tools. Send tools starting from turn 2 when the model actually needs to call them. Or: send a minimal text description of available tools in the system prompt instead of full JSON schemas (much fewer tokens).

### 2. `Client::new()` on every task — rebuilds TLS context

`agent_loop.rs:101` creates a new `reqwest::Client` per agent invocation. This rebuilds TLS cert stores and connection pools.

**Fix:** Accept `Client` as a parameter from `AppState` (which already exists for the lifetime of the app).

### 3. MCP tool info appended to system prompt AND sent as tool schemas (double-counted)

`commands.rs:1744-1764` iterates all MCP servers and appends tool descriptions to the system prompt. Then `message_builder.rs:67` calls `get_mcp_tools()` which converts them into full JSON tool schemas. The model sees every MCP tool TWICE — once in the system prompt text and once in the tools array. More input tokens = more prefill time.

**Fix:** Remove the system prompt MCP tool info. The tool schemas are enough.

## Changes

### A. Skip tools on first turn for Ollama/local models (`agent_loop.rs`)

In `convert_to_openai_format`, check if this is the first turn (no tool calls in message history). If so, and if the provider is `OpenAICompatible` (local), omit the `tools` field entirely. The model will respond with text only. On subsequent turns (after the first response is parsed and tool calls are needed), include tools.

This alone should cut prefill from ~50s to ~5s for the first message.

**File:** `src-tauri/src/agent/agent_loop.rs` — `convert_to_openai_format` 
- Add a `has_prior_tool_use: bool` parameter (or check if any message in the conversation has tool_use blocks)
- If no prior tool use AND provider is OpenAICompatible, skip the `tools` field

### B. Reuse `reqwest::Client` across tasks

**File:** `src-tauri/src/commands.rs` — Add `Client` to `AppState`
**File:** `src-tauri/src/agent/agent_loop.rs` — Accept `Client` parameter instead of `Client::new()`

### C. Remove MCP tool info from system prompt

**File:** `src-tauri/src/commands.rs:1744-1764` — Remove the MCP info string building and appending to system prompt. The tool schemas already describe MCP tools.

### D. Add timing logs to measure

**File:** `src-tauri/src/commands.rs` — Add `Instant::now()` + `elapsed()` at key points:
- Before/after `get_task_messages`
- Before/after `AgentLoop::new`
- Before/after `build_request`
- Before/after `send_request` (inside agent_loop)

## Files to modify

| File | Change |
|------|--------|
| `src-tauri/src/agent/agent_loop.rs` | Skip tools on first turn for local models; accept `Client` param |
| `src-tauri/src/commands.rs` | Reuse client; remove MCP prompt duplication; add timing logs |

## Verification

```bash
cargo check && cargo clippy -- -D warnings
```

Test: Send a message to qwen3.5:27b. First thinking token should appear in <5 seconds instead of >60 seconds.
