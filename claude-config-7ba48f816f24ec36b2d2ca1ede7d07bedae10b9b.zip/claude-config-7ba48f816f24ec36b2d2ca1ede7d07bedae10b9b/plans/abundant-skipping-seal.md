# Move PlanCard into the chat timeline

## Context

`PlanCard` currently renders at `src/components/AgentMain.tsx:854-856` — **after**
the `timelineItems.map()` block in the chat scroll container. That puts it at the
bottom of the chat content regardless of when the plan was actually emitted,
which breaks chronological flow (user message → plan → tool calls → assistant
reply).

User feedback: render the plan inline as a timeline item — like a tool call —
so it sits in the right chronological slot.

The plan is emitted once per task via the agent's `"plan"` event
(`src/stores/taskStore.ts:556`) and live-updates as steps transition
pending → running → completed. The card must keep live-updating.

## Approach

Make plan a first-class `TimelineItem` variant with a timestamp captured when
the `"plan"` event first arrives. The item's `steps` field reads from
`activeTask.plan` each render, so live step-status updates flow through the
existing store → memo → render path unchanged.

Keep `plan_timestamp` on the **store**, not on the `Task` type — `Task` mirrors
the Rust backend struct in `src/lib/tauri-api.ts` and shouldn't carry UI-only
timing state.

## Changes

### 1. `src/stores/taskStore.ts`

- Add `planTimestamp: number | null` to `TaskState` (alongside `thinkingText`, `currentText`).
- In the `"plan"` event handler (~line 556), set `planTimestamp: Date.now()` alongside the `activeTask.plan = ...` update. Reset to `null` when a new task starts (`startNewTask`) and when switching active tasks.
- Extend `TimelineItem` union (line 79):
  ```ts
  | { type: "plan"; id: string; steps: PlanStep[]; timestamp: number }
  ```
- Extend `buildTimeline(...)` signature to accept `plan: PlanStep[] | null` and `planTimestamp: number | null`. When both are present, push `{ type: "plan", id: "plan", steps: plan, timestamp: planTimestamp }` into `items` before the sort.
- Update the internal `timeline()` selector at line 282 to pass the new args.

### 2. `src/components/AgentMain.tsx`

- Update the `useMemo` at line 467 to pass `activeTask?.plan ?? null` and `planTimestamp` (from the store) into `buildTimeline(...)`. Add both to the dep array.
- In `TimelineItemView` (line 252 `switch (item.type)` at line 259), add:
  ```ts
  case "plan":
    return <PlanCard plan={item.steps} collapsible defaultExpanded={false} />;
  ```
- Delete the standalone render at lines 854-856.

## Verification

```bash
npx tsc --noEmit
cd src-tauri && cargo check && cargo clippy -- -D warnings
```

Then `npm run tauri:dev`:
1. Start a new task that triggers a multi-step plan.
2. Confirm `PlanCard` appears inline right after the user message, before any tool calls, not pinned to the bottom.
3. Watch step statuses flip as the agent executes — card must live-update in place.
4. Scroll up, send more messages; plan card stays at its original slot, not the bottom.
5. Start a second task — prior plan card stays in the old task's scroll history; new one appears inline when the new plan arrives.

## Critical files

- `src/components/PlanCard.tsx` — no changes needed
- `src/stores/taskStore.ts` — type union, builder signature, event handler
- `src/components/AgentMain.tsx` — memo deps, switch branch, remove standalone render
- `src/lib/tauri-api.ts` — `Task` shape, read-only reference (do not modify)
