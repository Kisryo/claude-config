#!/bin/bash
# Burn rate calculator for ccstatusline custom command widget

input=$(cat)

COST=$(echo "$input" | jq -r '.cost.total_cost_usd // 0')
DURATION_MS=$(echo "$input" | jq -r '.cost.total_duration_ms // 0')
BUDGET=${CLAUDE_BUDGET:-100}

if [ "$DURATION_MS" -gt 0 ] 2>/dev/null; then
    HOURS=$(echo "scale=6; $DURATION_MS / 3600000" | bc)
    [ "$(echo "$HOURS > 0" | bc)" -eq 1 ] && BURN_RATE=$(echo "scale=2; $COST / $HOURS" | bc) || BURN_RATE="0.00"
else
    BURN_RATE="0.00"
fi

REMAINING=$(echo "scale=2; $BUDGET - $COST" | bc)

printf "🔥 \$%.2f/hr | 💰 \$%.2f | 💵 \$%.2f left" "$BURN_RATE" "$COST" "$REMAINING"
