---
name: johnathan-writing-style
description: Use when writing, editing, rewriting, or judging text in Johnathan Mo's voice, including bios, applications, grant proposals, project pitches, YouTube scripts, captions, emails, personal essays, or "make this sound like me" requests.
---

# Johnathan Writing Style

Write like Johnathan Mo: practical, self-aware, builder-first, and concrete. The voice should feel like a Columbia CS student who builds fast, thinks in workflows, makes videos, and is allergic to empty hype.

## Pick The Mode

- **Formal builder mode** for applications, grants, serious bios, project pages, investor/funder emails, recruiting, and polished public writing.
- **Creator/script mode** for YouTube scripts, captions, casual posts, personal essays, and reflective storytelling.
- **Hybrid mode** for personal websites and public project pages: clear enough for strangers, human enough to not sound corporate.

## Formal Builder Mode

Use a crisp thesis and concrete workflow details.

Preferred structure:

1. Identify Johnathan and the project.
2. State the short version in plain language.
3. Name the real bottleneck.
4. Explain why the approach is different.
5. Ground it in users, workflows, or personal experience.
6. End with a concrete next milestone or ambition.

Useful phrases:

- "The short version is..."
- "The thread connecting the work is simple..."
- "The bottleneck is not only..."
- "What is unusual about the approach..."
- "These are not glamorous problems..."
- "The next concrete milestone is..."

Keep ambition practical. Pair impressive claims with proof, caveats, or operational detail.

## Creator / Script Mode

Let the writing show the process.

- Start in-scene or with a simple premise.
- Use first person.
- Keep some mess: being early, tired, cooked, uncertain, or learning.
- Move from story to takeaway.
- Use casual transitions sparingly: "honestly," "basically," "the thing is," "at this point," "the goal?"

Do not sanitize the voice into generic productivity advice.

## Style Rules

- Prefer concrete examples over abstract adjectives.
- Preserve first-person agency: "I built," "I realized," "I wanted to see."
- Avoid venture-speak unless grounded in a specific workflow.
- Avoid phrases like "revolutionizing the future" or "unlocking human potential" unless mocked or made specific.
- Use medium paragraphs in formal mode and shorter punchier beats in creator mode.
- A strong Johnathan paragraph often turns on "but": "Those wins were useful, but..." or "That sounds simple, but..."

## Quick Skeletons

Project pitch:

> I am building [project], a [plain-language category] for [specific user]. The short version is that it helps [user] do [workflow] without [current pain]. I got interested in this because [personal observation]. The bottleneck is not [obvious thing], it is [boring operational thing]. The next milestone is [concrete step].

Creator intro:

> I gave myself [constraint] to build [thing]. The goal was simple: [goal]. The reality was less simple.

Personal intro:

> I'm Johnathan Mo, a Columbia CS student building [category of tools]. I like projects that make capable people move faster, especially when they turn messy real-world workflows into something a small team can actually use.

