# Waitlist Modal Refinement Spec

## Overview
Refine the redesigned waitlist modal with two changes: replace the ugly multi-color gradient button with a solid dark button + shimmer effect, and add a social proof avatar stack with colored initials below the button.

## 1. Button: Solid Dark + Hover Shimmer

### Visual
- **Base state**: Solid near-black (#1a1a1a) button, rounded-[14px], same dimensions as current
- **Shimmer**: On hover, a diagonal semi-transparent white light streak sweeps across the button once (left to right, ~0.6s duration)
- **Implementation**: CSS `@keyframes` with a pseudo-element (`::after`) using a linear-gradient (transparent → white/20% → transparent) that translates from -100% to 200% on hover
- **No shimmer at rest** — button is clean and solid until hovered
- **Remove**: The current multi-color gradient and pink glow shadow
- **Keep**: Subtle box-shadow for depth (0 2px 8px rgba(0,0,0,0.15))

### Hover state
- Button background stays #1a1a1a (no color change)
- Shimmer streak sweeps once
- `overflow: hidden` on the button to contain the streak

## 2. Social Proof: Avatar Stack + Count

### Position
- Below the "Join the waitlist" button
- ~16px gap above the avatar row

### Avatar stack
- **4 overlapping circles** with colored initials + a 5th circle showing "+26K"
- Each circle: 36px diameter, 2px white border, overlapping by ~10px (negative margin)
- Initials: single uppercase letter, white text, 14px font-weight 600
- Colors: broader warm palette — amber (#d97706), terracotta (#c2410c), dusty sage (#6b8f71), warm brown (#92400e), muted blue-gray (#64748b)
- The "+26K" circle: slightly darker background (#374151), same size

### Layout
- Flex row, centered, with the 5 circles overlapping
- No additional text below — the avatars + "+26K" chip speak for themselves alongside the existing number chip above

### Data
- Initials and colors are hardcoded (decorative, not real user data)
- Example set: J (amber), M (terracotta), S (sage), A (brown), +26K (gray)

## 3. What stays the same
- Tabby cat perched top-left
- X close button top-right
- "We're still in early alpha" heading (Instrument Serif italic, 32px, centered)
- Subtitle text
- "PEOPLE ON THE WAITLIST" label + 26,847 number chip
- Email input styling
- Card background (#faf9f7), border-radius, shadow
- Backdrop blur

## Implementation notes
- The shimmer animation needs a Tailwind `@keyframes` definition in globals.css or an inline style with CSS animation
- Avatar circles are purely decorative — use `aria-hidden="true"` on the stack
- Keep the component self-contained in WaitlistModal.tsx
