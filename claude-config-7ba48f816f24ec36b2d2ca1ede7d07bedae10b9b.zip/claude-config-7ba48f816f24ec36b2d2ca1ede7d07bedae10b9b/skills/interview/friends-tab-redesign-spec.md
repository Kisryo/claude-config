# Friends Tab Redesign — Spec

**Source request**: "design friends to look more like this" + reference screenshot showing a green hero with mascots, a podium, and a clean rank/avatar/name/time/delta/streak list.

**Status**: Spec only. No code written yet.
**Date**: 2026-05-06
**Owner**: Johnathan Mo
**Author**: drafted via interactive interview

---

## 1. North Star

Take Mojo's existing Friends tab — currently a working but utilitarian leaderboard — and re-frame it as a **character-driven competitive surface** matching the reference: bright green GIF hero on top, prominent stepped podium with a crowned #1, and a clean delta-aware list underneath.

The redesign reuses the existing `FriendsHero.dataset/friends_hero.gif` banner and the existing stepped `LeaderboardPodiumView` geometry — the work is in **what sits between and around them** (segmented filter, glass pending banner, list rows with delta + streak, crown decoration, "you" row highlight) and a tighter visual rhythm aligned with `DESIGN.md`'s Animated Editorial language.

---

## 2. Layout (top → bottom)

```
┌─────────────────────────────────────┐
│   FriendsHeroBanner (existing GIF)  │  ← keeps its from-the-top bleed
│   "Friends" + count + Invite CTA    │     ignoresSafeArea(.top)
└─────────────────────────────────────┘
   [floating glass banner — visible only when there's a pending duel]
   ┌──── GLASS RIBBON ────┐
   │ ⚡ N incoming duels   │  ← tap to expand inline accept/decline
   └──────────────────────┘

  Today  │  This Week                  ← segmented control (no "Leaderboard" label)

   ┌────────────────────────┐
   │      ╲ ╱  CROWN        │
   │      avatar(#1)        │  ← #1 podium avatar gets a small gold
   │   ╱     ⃝     ╲        │     crown + 4 sparkle rays
   │ av(#2)   av(#3)        │
   │ ┌──┐  ┌────┐   ┌──┐    │  ← stepped Figma podium retained
   │ │ 2│  │  1 │   │ 3│    │
   └────────────────────────┘

  4   👤 Zoe       45m   ▲12m   12 🔥   ›
  5   👤 Jordan    38m   ▼5m     7 🔥   ›
  6   👤 You       32m   ▲8m     5 🔥   ›   ← primary-tinted fill
  7   👤 Riley     20m   ▼3m     3 🔥   ›
  8   👤 Lee       12m    —      1 🔥   ›

  Activity                              ← demoted, smaller header
  [activity feed cards here]
```

---

## 3. Data dependencies

### Already exists (no backend work)
- `FriendProfile.profilePhotoData` — used as primary avatar source
- `FriendProfile.argoCustomizationData` — used as fallback avatar
- `FriendProfile.todayGrantedMinutes`, `todayDeniedCount`, `todayStreak`, `weekGrantedMinutes`
- `LeaderboardEntry`: `screenTimeMinutes`, `yesterdayScreenTimeMinutes`, `streak`, `argoCustomization`, `profilePhotoData` — all already pulled by `LeaderboardService`
- `FriendsHero.dataset/friends_hero.gif` + `AnimatedGIFView` + existing `FriendsHeroBanner`
- Existing `LeaderboardPodiumView` (stepped Figma blocks 160/120/90pt)

### New / extended in UI layer only
- `LeaderboardScope` enum: `.today | .week`
- `LeaderboardEntry.weekScreenTimeMinutes: Int?` — needed for the Week segment to show different values. Source: existing `weekGrantedMinutes` on `FriendProfile` plus an equivalent Firestore field on the friend's user doc. **Verify** the friend doc already publishes a weekly aggregate; if not, wire it through `StatsSyncService`.
- No schema migration. No model changes.

---

## 4. Component decisions

### 4.1 Hero
- **Keep** `FriendsHeroBanner` exactly as-is. It already bleeds from the top via `ignoresSafeArea`.
- **No layout reflow**. The banner stays full-width, 252pt tall, with rounded bottom corners.

### 4.2 Pending duels — floating glass banner
- New component: `PendingDuelGlassRibbon`.
- Visible **only when** `pendingChallenges.count > 0`.
- Pinned ~12pt below the GIF's bottom edge, full-width minus 16pt insets.
- Style: `surfaceContainerLowest @ 80% opacity` + `.ultraThinMaterial`, rounded `radiusLG`.
- Content: `⚡ \(count) incoming duel\(s)` + chevron. Tap toggles an inline expansion that surfaces the existing `PendingChallengeCard`s stacked below the ribbon.
- This **replaces** the current "Pending Challenges" section that lives directly above the leaderboard in `FriendsTabView.swift`.

### 4.3 Segmented control
- New component: `LeaderboardScopePicker`.
- Drops the "Leaderboard" section header text entirely (segmented control reads as self-evident).
- Two segments: **Today | This Week**.
- Sits below the GIF, above the podium. Standalone on `Color.Mojo.surface`, no glass overlap.
- Uses `Picker(.segmented)` styled with the existing `MojoCard` chrome — or a custom capsule pair if `Picker` doesn't accept enough styling. Default: **Today**.

### 4.4 Podium
- **Keep** existing `LeaderboardPodiumView` stepped blocks (160/120/90pt).
- **Add** crown decoration on the #1 avatar:
  - Component: `PodiumCrownDecoration`.
  - 28×28pt gold (`Color.Mojo.gold`) crown SF Symbol (`crown.fill`) positioned 4pt above the #1 avatar.
  - 4 small yellow sparkle ticks (`sparkle` symbol or hand-drawn 2pt rays) fanning outward.
  - Subtle rotation animation: ±3° wobble, 2.4s repeating ease.
- Rank badges (current `rankBadge`) stay as gold/silver/bronze circles — **don't** replace with the reference's number-only chips.
- Score chips on the podium continue to read minutes from the **active scope** (Today vs Week).

### 4.5 Leaderboard list
- New row component: `LeaderboardListRow`.
- Layout: `rank │ avatar │ name │ minutes │ delta pill │ streak fire │ chevron`
- **Rank**: Figtree Bold 14pt, monospaced digit, `onSurfaceVariant`. 24pt fixed leading width.
- **Avatar**: `FriendProfileAvatar` (existing) at 40pt — `profilePhotoData` first, Argo customization fallback, gradient initials last fallback.
- **Name**: Figtree SemiBold 16pt, single line, `onSurface`.
  - If `entry.isCurrentUser`: render `"You"` instead of name.
- **Minutes**: Figtree SemiBold 15pt, monospaced, format via existing `LeaderboardRowView.formatDuration(minutes:)`. Render `"—"` when nil.
- **Delta pill**: Conditional. Only renders when both `screenTimeMinutes` and `yesterdayScreenTimeMinutes` are non-nil **and** `scope == .today` (week view doesn't have a meaningful delta until we have last-week data).
  - Up (more minutes today): `▲ \(diff)m`, fill `Color.Mojo.error.opacity(0.12)`, fg `Color.Mojo.error`. Why: more minutes = worse for productivity, so red.
  - Down (fewer minutes today): `▼ \(diff)m`, fill `Color.Mojo.success.opacity(0.12)`, fg `Color.Mojo.success`.
  - Tied: `—`, fill `surfaceContainerHigh`, fg `onSurfaceVariant`.
  - Capsule, 8pt horizontal padding, 4pt vertical padding, monospacedDigit.
- **Streak**: `\(streak) 🔥`. Hide entirely when `streak == 0`. Caption Bold 13pt, `onSurfaceVariant`.
  - Accessibility label: `"\(streak) days under daily goal"`.
  - **Semantic decision**: streak = consecutive days the friend stayed under their daily screen-time goal (mirrors `StreakManager`/`StreakProgress`).
- **Chevron**: 12pt `chevron.right`, `onSurfaceVariant.opacity(0.5)`. Indicates row is tappable.
- **Tap**: navigates to existing `FriendDetailView` (no new screen).
- **You row** highlight: when `entry.isCurrentUser` and not in podium top-3, fill row with `Color.Mojo.primaryFixed.opacity(0.08)` and use Bold 16pt for the "You" label.
- **Empty values**: when `screenTimeMinutes == nil`, render `"—"` and skip the delta pill. **No** ghosted opacity on the row — keep full opacity so layout doesn't shift on data arrival.
- **No row entrance animation** on first load. **No** rank-change reorder animation between scope switches — except the spring reorder noted in §5.

### 4.6 Activity feed
- **Keep** but demote: smaller `Activity` section header (Figtree Bold 18pt, was titleSmall 22pt) below the leaderboard list.
- Existing `ActivityFeedSection` component reused as-is.
- No structural change beyond placement and header weight.

### 4.7 Empty states
- **No friends yet** — keep existing `EmptyFriendsView` flow (signed in but no friends).
- **Friends exist, no times yet** — render the rows with `"—"` minutes and no delta pill (per §4.5). Streak still renders if non-zero. **No** "Waiting for today's numbers" copy.
- **Not signed in** — keep existing `signInPrompt`.

---

## 5. Motion

- **No row entrance animation** on first leaderboard load. Instant render. (Explicit user preference.)
- **Scope switch reorder** (Today ↔ Week): rows animate into new ranks with `.spring(response: 0.55, dampingFraction: 0.78)`. Implementation: keep stable `id: \.id` in the `ForEach`, apply `.animation(spring, value: scope)` on the container. Each row's vertical position transitions; minutes/delta values content-transition.
- **Pending glass ribbon** appears with a `.transition(.scale(0.92).combined(with: .opacity))` and disappears with opacity-only.
- **Crown wobble**: ±3° rotation, 2.4s `easeInOut.repeatForever(autoreverses:)`. Sparkle rays scale 0.9 ↔ 1.05 in sync.
- **Reduce Motion**: every animation disabled when `\.accessibilityReduceMotion` is true. Crown stays static, ribbon appears/disappears without spring, scope switch is instant.

---

## 6. Visual / typography spec

| Element | Font | Color |
|---|---|---|
| Hero "Friends" title | Figtree ExtraBold 32 (existing) | `.white` |
| Hero subtitle | Figtree Medium 15 (existing) | `.white.opacity(0.92)` |
| Pending ribbon label | Figtree Bold 14 | `Color.Mojo.tertiary` |
| Segmented control labels | Figtree Bold 14 | active `.textOnColor` on `LinearGradient.glowCTA`; inactive `onSurfaceVariant` on `surfaceContainerLowest` |
| Podium #1 name | Figtree SemiBold 15 (existing) | `onSurface` |
| Podium score chip | Figtree Bold 13 (existing) | `.white` on `primaryFixed` capsule |
| Crown | SF Symbol `crown.fill` 28pt | `Color.Mojo.gold` |
| Sparkle rays | 2pt strokes | `Color.Mojo.gold.opacity(0.7)` |
| List rank number | Figtree Bold 14, monospacedDigit | `onSurfaceVariant` |
| List name | Figtree SemiBold 16 (Bold for "You") | `onSurface` |
| List minutes | Figtree SemiBold 15, monospacedDigit | `onSurface` |
| List delta pill | Figtree Bold 13, monospacedDigit | per §4.5 |
| List streak | Figtree Bold 13 | `onSurfaceVariant` |
| Activity header | Figtree Bold 18 | `onSurface` |

All radii use `MojoShape` constants. **No 1px borders anywhere** — surface separation is tonal only, per `DESIGN.md`.

---

## 7. Dark mode
- All surfaces use the existing adaptive `Color.Mojo.*` tokens. Cards become dark under the bright green GIF — same pattern as the rest of the app.
- No hero re-tint, no force-light contents. Zero new dark-mode code.

---

## 8. Accessibility
- VoiceOver per row: `"Rank \(n), \(name), \(formattedMinutes), \(delta description), \(streak) days under goal"`.
- Tap targets ≥ 44pt minimum height for list rows, 44pt for the segmented control segments, 44pt for ribbon tap.
- Reduce Motion handled per §5.
- Dynamic Type: rows reflow vertically when text scaling pushes them past one line. Avatar stays fixed at 40pt; everything else scales.

---

## 9. Files to touch

```
MojoiOS/UI/Friends/
├── FriendsTabView.swift             — wire up new components in mainContent, drop "Pending Challenges" section
├── LeaderboardListView.swift        — replace with new LeaderboardListRow, add scope-driven sort, "You" highlight
├── LeaderboardPodiumView.swift      — add PodiumCrownDecoration on #1
├── LeaderboardRowView.swift         — repurpose as the new row component (or rename → LeaderboardListRow.swift)
└── (new) PendingDuelGlassRibbon.swift   — replaces the inline pending section
└── (new) LeaderboardScopePicker.swift   — segmented control component
└── (new) PodiumCrownDecoration.swift    — gold crown + sparkles
```

`MojoiOS/Core/Social/LeaderboardService.swift`
- Add `weekScreenTimeMinutes` to `LeaderboardEntry` if not already present.
- Adjust the sort comparator to honor an active scope: `service.entries(scope: .today | .week)` returns rows sorted by the appropriate minutes field.

No model migrations.

---

## 10. Implementation order

1. **Add `LeaderboardScope` + scope-aware service queries.** Verify week minutes are actually written to Firestore for friends; if not, ship a `StatsSyncService` patch first.
2. **`LeaderboardScopePicker` component** (segmented control). Stand-alone, easy to verify visually.
3. **`PodiumCrownDecoration`** + integrate into `LeaderboardPodiumView`. Verify it renders only on rank 1.
4. **`LeaderboardListRow`** with delta + streak + chevron + "You" highlight. Replace existing `LeaderboardListView` row rendering.
5. **`PendingDuelGlassRibbon`** + remove the old pending section from `FriendsTabView.mainContent`.
6. **Demote `Activity` section header** typography in `FriendsTabView`.
7. **Wire scope-switch spring animation** on the list container.
8. Manual QA pass:
   - Sign-out / sign-in transitions
   - 0/1/2/3+ friends
   - All friends with `screenTimeMinutes == nil`
   - You at rank #1, #2, #3, and #5+
   - Pending duels: 0, 1, 3+
   - Today vs Week scope switch with rank changes
   - Reduce Motion on/off
   - Light + dark mode

---

## 11. Explicit non-goals (v1)

- Not changing `EmptyFriendsView` (the no-friends state).
- Not redesigning `FriendDetailView`.
- Not changing the `AnimatedGIFView` or asset.
- Not adding "All time" scope to the segmented control.
- Not changing the streak semantic (defaulting to "days under daily goal" — matches `StreakManager`).
- Not adding inline-expand on row tap; existing `FriendDetailView` navigation stays.
- Not adding a long-press context menu.
- Not changing `PendingChallengeCard` (already redesigned in the prior session).
- Not redesigning `ChallengeCompletionView`.
- No backend work beyond ensuring `weekScreenTimeMinutes` is wired (which may already be done).

---

## 12. Open / deferred

- **Crown when ranks tie**: if rank #1 and rank #2 have equal minutes, who gets the crown? **Default for v1**: existing podium sort tiebreaker wins (alphabetical or whatever `LeaderboardService` does today). Don't render two crowns.
- **Friend with profilePhotoData but no Argo customization**: should we ever fall back to initials? **Yes** — only if both `profilePhotoData` and `argoCustomizationData` are nil, which is the existing behavior of `FriendProfileAvatar`.
- **Activity feed visibility**: confirmed kept on this surface, demoted. Revisit if user data shows the feed isn't being engaged with after this redesign.
- **Yesterday data freshness**: the delta pill assumes `yesterdayScreenTimeMinutes` is reasonably fresh. If Firestore writes for that field lag for some friends, the pill may be stale or missing. Acceptable for v1; add a "last updated" hint in `FriendDetailView` later if it becomes a complaint.
