
# MultiAppDemo Redesign Spec

## Overview

Redesign the "Who Uses Tabby" video (`multi-app-demo.mp4`) from a basic 10-second dark-themed 3-app carousel into a cinematic 7-second showcase of 5 apps with polished macOS chrome, scale-swap transitions, camera drift, and progressive interaction depth.

---

## Problem

The current MultiAppDemo uses dark, uniform `MacWindow` components with simple fade transitions — visually flat compared to the feature demo videos above it (which use gradient wallpapers, menu bars, frosted glass, and spring animations). The "Who Uses Tabby" section should feel like the climax of the page, not a downgrade.

## Goals

- Match the visual quality of FeatureDemos while feeling elevated and distinct
- Showcase 5 apps not already covered by feature demos (avoid Notes, Mail, Terminal, Slack)
- Build narrative tension through progressively deeper interactions
- Keep it punchy at 7 seconds

---

## Technical Specs

| Property | Value |
|----------|-------|
| Resolution | 1920 x 1080 (Full HD) |
| Frame rate | 30 fps |
| Duration | 210 frames (7 seconds) |
| Composition ID | `MultiAppDemo` |
| Output | `public/videos/multi-app-demo.mp4` |

---

## Real Product UI Reference

The video must accurately depict TabAnywhere's actual ghost text UI, not generic placeholders.

### Ghost Text Pill (from `OverlayWindow.swift`)
- **Appearance**: Frosted glass pill floating **below the caret** (not inline text)
- **Background**: `NSVisualEffectView` popover material — translucent blur
- **Corner radius**: 9pt
- **Padding**: 10pt horizontal, 6pt vertical
- **Shadow**: macOS system shadow
- **Text color**: `NSColor.secondaryLabelColor` (~55% opacity gray) — NOT amber
- **Max width**: 500pt
- **Max lines**: 3
- **Caret gap**: 4pt below cursor

### Tab Badge (appended to ghost text inside pill)
- **Label**: "Tab ↩"
- **Background**: `rgba(127, 127, 127, 0.15)`
- **Text color**: `rgba(127, 127, 127, 0.8)`
- **Font size**: 75% of ghost text size, medium weight
- **Corner radius**: 3pt
- **Padding**: 4pt horizontal, 1.5pt vertical

### Accept Behavior
- **Instant** — no animation, no flash, no highlight
- Ghost pill disappears immediately, text inserts into field
- This is the real product behavior (confirmed from `KeyInterceptor` + `TextInjector`)

### Type-Through
- Typed characters that match ghost text switch from secondary gray to solid `NSColor.labelColor` (black)
- Ghost text shrinks as user advances through matching characters

### Browser Extension Ghost Text (for Chrome/web scenes)
- **Opacity**: 0.4 (constant `GHOST_OPACITY`)
- **Color**: Inherits from field's computed text color
- **Tab badge**: "Tab" text, `rgba(127,127,127,0.15)` bg, 11px, 4px border-radius
- **Positioning**: Fixed overlay at caret position via Shadow DOM

---

## Visual Design

### Wallpaper
Single neutral warm gray gradient throughout all scenes:
```
linear-gradient(160deg, #e8e4e0 0%, #d4cfc8 40%, #c5bfb6 100%)
```
Understated, lets the app windows be the focal point. Grounded — feels like one user's real desktop.

### Camera
Subtle drift zoom over full duration:
- Start: `scale(1.0)`
- End: `scale(1.05)`
- Interpolation: linear over 210 frames
- Transform origin: `center center`

### Menu Bar
Shared `MenuBar` component at top. App name updates at each scene transition with a brief opacity dip (crossfade pattern from HeroDemo).

### Window Style
Uses shared `AppWindow` component (light theme) for all except VS Code (dark). Each window is slightly larger than feature demos to fill 1920x1080 canvas:
- Notion: 880 x 520
- iMessage: 780 x 520
- Google Docs: 880 x 520
- VS Code: 920 x 540
- Pages: 820 x 520

---

## Scene Transitions

**Type**: Quick scale swap (snappy, energetic)

| Phase | Frames | Effect |
|-------|--------|--------|
| Exit | 6 frames | Scale 1.0 → 0.92, opacity 1 → 0 |
| Gap | 3 frames | Neither window fully visible |
| Enter | 6 frames | Spring 0.92 → 1.0 (damping 14, stiffness 200), opacity 0 → 1 |

First scene has no enter animation. Last scene has no exit animation.

---

## Scene-by-Scene Breakdown

### Scene 1: Notion (frames 0–41)

**Window design**:
- Sidebar (200px): Dark charcoal (#191919), workspace name "My Workspace", page list with "Project Kickoff Notes" highlighted
- Content: White background, page title (28px bold), meeting agenda bullet list

**Content**:
- Pre-existing text: `"Meeting agenda for Thursday:\n- Review Q1 roadmap\n- Assign sprint tasks\n- Discuss"`
- Ghost text: `" timeline for the API integration with the payments team"`

**Interaction**: Ghost text pill (frosted glass, below caret) fades in with "Tab ↩" badge. No acceptance — teaches the concept, then cuts away.

**Ghost timing**: Pill appears frame 12, fully visible by frame 22 (10-frame fade). Text in secondary gray at 40% opacity. Pill has 9pt corner radius, blur backdrop, 4pt below caret.

---

### Scene 2: iMessage (frames 36–77)

**Window design**:
- No sidebar, full-width conversation
- Header: Contact "Mom" with gray avatar circle
- 3 message bubbles:
  - Incoming (#E9E9EB): "Are you still coming for dinner Sunday?"
  - Outgoing (#007AFF, white text): "Yes! What should I bring?"
  - Incoming: "Whatever you'd like, maybe dessert?"
- Rounded input bar at bottom

**Content**:
- Typed text (in input bar, typing speed 3 frames/char): `"How about I"`
- Ghost text: `" pick up that chocolate cake from the bakery on 5th"`

**Interaction**: Ghost text pill appears below input bar caret with "Tab ↩" badge. No accept. Casual short completion.

**Ghost timing**: Pill appears ~frame 50, fades in over 10 frames. Secondary gray at 40% opacity. Frosted glass pill, 9pt radius.

---

### Scene 3: Google Docs (frames 78–119)

**Window design**:
- Chrome-style title bar
- Toolbar strip: font selector "Arial", size "11", B/I/U buttons, light gray background (#F9FBFD)
- Document: White page with subtle shadow, serif-style body text, generous padding (40px 60px)

**Content**:
- Pre-existing paragraph: `"The quarterly review highlighted several areas for improvement. The engineering team exceeded their sprint velocity targets, while the design team"`
- Ghost text: `" delivered the new component library ahead of schedule, enabling faster iteration on the dashboard redesign."`

**Interaction**: Ghost text pill appears below caret with "Tab ↩" badge. Tab accept at frame 108 — pill instantly disappears and text inserts into document (no flash, no animation — matches real product behavior).

**Ghost timing**: Pill appears frame 90, fades in over 10 frames. Secondary gray at 40% opacity. Frosted glass pill.

---

### Scene 4: VS Code (frames 120–161)

**Window design** (dark theme):
- Activity bar (48px): Dark (#333333), file/search/git/debug icon placeholders
- File explorer (200px): Dark (#252526), tree with src/, api.ts (active), types.ts, utils/
- Editor: Dark (#1E1E1E), line numbers (#858585), syntax-highlighted TypeScript
- Tab bar: "api.ts" active (blue top border #007ACC), "types.ts" inactive
- Status bar (22px): Blue (#007ACC), "TypeScript", "UTF-8"

**Content** (code):
```typescript
import { Router } from 'express';

const router = Router();

router.get('/users', async (req, res) => {
  const users = await db.query(
```
- Ghost text (next line, indented): `    'SELECT id, name, email FROM users WHERE active = $1', [true]`

**Interaction**: Ghost text pill appears below code line with "Tab ↩" badge. Tab accept at frame 148 — pill instantly disappears, code inserts into editor as syntax-colored text. No flash.

**Syntax colors** (for accepted text): Keywords #569CD6, Strings #CE9178, Types #4EC9B0, Functions #DCDCAA, Comments #6A9955, Punctuation #D4D4D4

**Ghost timing**: Pill appears frame 132, fades in over 10 frames. Secondary gray at 40% opacity.

---

### Scene 5: Pages (frames 162–209)

**Window design**:
- Format bar: font "Helvetica Neue", size "12", B/I buttons, light gray (#F5F5F5)
- Document: White page with subtle shadow, generous margins
- Title: "Chapter 3: The Signal" (26px bold)

**Content**:
- Pre-existing paragraph: `"The radio crackled again, and this time the signal was unmistakable. Commander Torres leaned forward, her fingers hovering over the console. After twelve years of silence, the"`
- Ghost text: `" deep space array had finally detected a response."`

**Interaction**: Ghost text pill with "Tab ↩" badge. Tab accept at frame 192 — pill instantly disappears, text inserts into document. Scene holds to 210.

**Ghost timing**: Pill appears frame 174, fades in over 10 frames. Secondary gray at 40% opacity.

---

## Frame Timeline Summary

```
Frame   Event
------  -----------------------------------------
0       Notion window appears (no enter anim). Camera 1.0x.
12-22   Ghost text pill fades in (frosted glass, secondary gray, 40% opacity)
        "Tab ↩" badge visible inside pill
30-35   Notion exit: scale 1.0 → 0.92, fade out
36-41   iMessage enter: spring 0.92 → 1.0
~44-54  "How about I" types in (3 frames/char)
50-60   Ghost text fades in on input bar
72-77   iMessage exit
78-83   Google Docs enter
90-100  Ghost text fades in (long completion)
108     Tab accept → solid text + blue flash
114-119 Google Docs exit
120-125 VS Code enter
132-142 Ghost code line fades in
148     Tab accept → syntax-colored + blue flash
155-161 VS Code exit
162-167 Pages enter
174-184 Ghost text fades in
192     Tab accept → solid + flash
200-210 Hold. Camera ~1.05x. End.
```

---

## Code Architecture

### New file: `remotion/src/shared.tsx`
Extract shared components from FeatureDemos.tsx:
- Constants: `SYSTEM_FONT`, `MONO_FONT`, `MENU_BAR_H`, `AMBER`, `AMBER_DARK`, gradient constants
- Components: `TrafficLights`, `MenuBar`, `DesktopScene`, `AppWindow`, `BlinkingCursor`, `FrostedPill`

### Update: `remotion/src/FeatureDemos.tsx`
Replace inline shared component definitions with imports from `./shared`. All 6 feature compositions unchanged.

### Rewrite: `remotion/src/MultiAppDemo.tsx`
- Import shared components from `./shared`
- `CameraDrift` wrapper component
- `useSceneTransition()` helper for scale-swap logic
- 5 scene components: `NotionScene`, `IMessageScene`, `GoogleDocsScene`, `VSCodeScene`, `PagesScene`
- `MultiAppDemo` main composition orchestrating scenes

### Update: `remotion/src/Root.tsx`
- Change MultiAppDemo `durationInFrames` from 300 → 210

---

## Verification

1. `npx remotion preview` — preview MultiAppDemo composition
2. Verify all 5 scenes render with correct app chrome
3. Check scale-swap transitions are smooth (no jarring cuts)
4. Confirm ghost text timing and Tab accept sequences per scene
5. Verify camera drift is subtle
6. Confirm all 6 FeatureDemo compositions still work after shared.tsx extraction
7. Render: `npx remotion render MultiAppDemo public/videos/multi-app-demo.mp4`
8. Check final file size (target < 600KB for page load)
