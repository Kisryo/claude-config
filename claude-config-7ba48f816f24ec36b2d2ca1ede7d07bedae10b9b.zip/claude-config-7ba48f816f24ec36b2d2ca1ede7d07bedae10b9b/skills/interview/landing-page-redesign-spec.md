# Landing Page Redesign Spec

## Project

Redesign the landing page (`/`) for the Recruiting Course website (https://recruiting-course.vercel.app). The current page is generic, template-like, text-heavy, and lacks personality. The goal is a modern, creator-brand landing page that converts YouTube visitors into buyers — specifically the Recruiting Guide ($49) as the primary product.

---

## Design Direction

### Overall Vibe
- **Creator-brand aesthetic** (think Ali Abdaal, Sahil Bloom, Dan Koe) — polished, personal, premium but approachable
- **Careerist.com as structural reference** — but more modern, more authentic, personal not corporate
- **Light theme with solid, bright accent colors** — NO gradients anywhere
- **Generous whitespace**, card-based layouts, large expressive typography
- Search [Dribbble course landing pages](https://dribbble.com/tags/course-landing-page) and [career landing pages](https://dribbble.com/tags/career-landing-page) for additional visual inspiration
- Equal priority for desktop and mobile design

### Color Palette
- Research and pick a modern, vibrant palette with solid colors (no gradients)
- Light/white background base
- One strong accent color for CTAs and key elements
- Complementary secondary color for variety
- Reference [design trends for 2026 landing pages](https://www.involve.me/blog/landing-page-design-trends)

### Typography
- Large, expressive headlines (oversized, bold)
- Clean, readable body text
- Use the existing Geist font family but explore weight variations for more visual hierarchy

---

## Page Structure (Top to Bottom)

### 1. Hero Section — Split Layout
- **Left side**: Headline, subtext, primary CTA
- **Right side**: YouTube avatar / personal visual element
- **Headline**: Motivational + conversational mix. Second person, inspiring, with some first-person directness. Example direction: "Your dream offer is closer than you think" energy, mixed with "I got 7 offers last year. Here's how." authenticity
- **Subtext**: Brief, punchy — establish who it's for (interns, entry-level) without being wordy
- **Primary CTA**: Trust-first — link to YouTube channel ("Watch free content" or similar), not a hard purchase push
- **Secondary CTA**: Scroll to learn more, or link to guide
- **Credibility woven in**: Mention "Prev @ Google, Incoming @ SIG" subtly near the name/avatar — not a separate section

### 2. Company Logos Section — "Offers & Interviews"
- Two tiers:
  - **"Offers from"**: Google, Meta, SIG, Glean logos
  - **"Interviewed at"**: OpenAI, Jane Street, Citadel, PDT Partners logos
- Clean logo grid on light background
- Use recognizable company SVG logos (source from [simpleicons.org](https://simpleicons.org/) or similar)
- Brief intro text: something like "This system works. Here's proof." — conversational, not braggy

### 3. What You'll Learn — Visual Preview
- Show an **angled browser-frame mockup** of the dashboard/guide viewer
- Tease what's inside without revealing readable content
- Keep this section visually impactful but brief — the image does the talking
- Optional: 3-4 topic pills/chips below the mockup (e.g., "Resume Strategy", "Cold Outreach", "Interview Prep", "Offer Negotiation") to hint at content scope

### 4. Product Spotlight — Guide First
- **Lead with the Recruiting Guide** ($49) as the hero product
- Prices are **secondary** — lead with the value proposition and features first, price shown but not the biggest element
- Keep it cognitively easy — don't overwhelm with all 6 products at once
- Show 2-3 products max in this section (Guide, Bundle, maybe Templates)
- Link to full `/pricing` page for the complete lineup
- Remove subscriptions from the landing page entirely, or show them as a small mention/link at the bottom

### 5. FAQ Section (condensed)
- Keep the accordion FAQ but reduce to 4-5 most important questions
- Keep it tight — this is a landing page, not a knowledge base

### 6. Final CTA Section
- Motivational closing message
- Primary CTA to YouTube (trust-first funnel)
- Secondary CTA to pricing/guide purchase

---

## Content & Copy Guidelines

### Tone
- **Motivational and energetic** as the primary voice: "Your dream offer is closer than you think"
- **Mixed with conversational directness**: "I got 7 offers in one season. Here's exactly how."
- First person when talking about credentials/results, second person when talking to the visitor
- No corporate-speak. No "comprehensive solution" or "proven methodology" language
- Short sentences. Punchy. Scannable

### Social Proof
- **No testimonials** — pre-launch, no real ones available yet. Remove fake testimonials entirely
- **No placeholder stats** (remove "10K+ subscribers", "500+ students helped" etc.)
- Social proof = Jonathan's personal results (company logos, offer count) woven throughout
- Will add real testimonials post-launch

### Personal Branding
- YouTube avatar displayed (not a full headshot photo)
- Creator handle @jmooooooooo referenced
- Credentials woven in naturally, not in a dedicated "About" section
- Personal, authentic feel — one person sharing what worked, not a faceless company

---

## Technical Notes

### Files to Modify
- `src/app/(marketing)/page.tsx` — Restructure section order
- `src/components/marketing/hero.tsx` — Complete redesign: split layout, new copy, avatar
- `src/components/marketing/social-proof.tsx` — Replace with company logos section (offers/interviews)
- `src/components/marketing/product-cards.tsx` — Simplify to feature guide prominently, fewer cards
- `src/components/marketing/subscription-cards.tsx` — Remove from landing page or minimize
- `src/components/marketing/faq-section.tsx` — Reduce to 4-5 questions
- `src/components/marketing/cta-section.tsx` — Update copy and CTA targets
- `src/app/globals.css` — Update color tokens/theme for new palette
- `public/` — Add company logo SVGs, YouTube avatar image, dashboard mockup image

### New Components to Create
- Company logos grid component (with two-tier layout)
- Visual preview / mockup section component
- Product spotlight component (guide-first, simplified)

### Assets Needed
- Company logo SVGs: Google, Meta, SIG, Glean, OpenAI, Jane Street, Citadel, PDT Partners
- YouTube avatar image (from YouTube channel)
- Dashboard mockup screenshot (can be generated/placeholder for now)

### What to Remove
- Fake testimonials (Alex T., Sarah K., Marcus L.)
- Placeholder stats (10K+ subscribers, 500+ helped, 85% success rate, 100+ companies)
- Subscription cards section from landing page (keep on `/pricing`)
- "Watch on YouTube" as a video embed — keep as a link/button only
- Blue-to-violet gradient on hero text

---

## Success Criteria

1. Page feels like a personal creator brand, not a SaaS template
2. Credibility (Google, SIG, Meta etc.) is visible within first scroll
3. Cognitively easy — visitor understands what this is and who it's for within 5 seconds
4. Primary conversion path: visitor watches YouTube content, builds trust, returns to buy
5. Guide ($49) is the clear hero product
6. No fake social proof — only real, verifiable claims
7. Works beautifully on both mobile and desktop
8. Visual interest through layout, typography, and color — not through stock imagery or illustrations
