# Smart Voice Interruption Spec

## Overview

When Mira is speaking, the user should be able to interrupt her mid-response by speaking. However, in a loud booth environment with ambient chatter, raw interruption causes constant false triggers. This spec defines a **two-stage interrupt filter** — frontend heuristic gating + backend Haiku classification — that rejects noise while allowing genuine user interruptions to cut through.

---

## Architecture

```
User speaks while Mira is talking
         │
         ▼
┌─────────────────────────┐
│   STAGE 1: Frontend     │  (0ms, local)
│   Heuristic Gate        │
│                         │
│  ✗ Grace period active? │──── DROP (silent)
│  ✗ Confidence < 0.80?   │──── DROP (silent)
│  ✓ Passes both checks   │
└──────────┬──────────────┘
           │
           ▼
┌─────────────────────────┐
│   STAGE 2: Backend      │  (~300-800ms, Haiku API)
│   Haiku Classifier      │
│                         │
│  Input: transcript only │
│  Output: binary         │
│    real → INTERRUPT      │
│    noise → REJECT (log)  │
└──────────┬──────────────┘
           │ (if "real")
           ▼
┌─────────────────────────┐
│   Execute Interrupt     │
│                         │
│  Frontend: mira.stop()  │
│  Backend: abort stream  │
│  Send new voice event   │
└─────────────────────────┘
```

---

## Stage 1: Frontend Heuristic Gate

**Location:** `frontend/src/app/mirror-v2/page.tsx` (runs in browser, no network hop)

### Grace Period (Scaled by Response Length)

- **Short responses (1 sentence):** Fully uninterruptible. Mira plays to completion no matter what.
- **Longer responses (2+ sentences):** Interruptible after **2.5 seconds** of Mira speaking.
- Sentence count is tracked by counting `speakQueued()` calls in the current response.
- The 2.5-second timer starts when the first TTS sentence begins playing.

**Behavior during grace period:** Transcripts that arrive while the grace period is active are **dropped entirely** (not queued). The user will naturally repeat themselves when Mira finishes or when the grace window opens.

### Confidence Threshold

- During Mira's speech, only transcripts with Deepgram confidence **>= 0.80** pass through.
- During normal idle listening (Mira not speaking), the existing behavior applies (no threshold).
- Deepgram's `utterance_end_ms` stays at **1500ms** — no changes to STT config.

### Admin-Tunable Parameters

Both thresholds are configurable at runtime via the admin dashboard:

| Parameter | Default | Admin Control |
|-----------|---------|---------------|
| Grace period (seconds) | 2.5 | Slider (0-10s) |
| Confidence threshold | 0.80 | Slider (0.50-1.00) |

These are stored as Socket.io-synced state so the mirror picks them up without page reload.

---

## Stage 2: Backend Haiku Classifier

**Location:** Backend endpoint (called by frontend for transcripts that pass Stage 1)

### Trigger Condition

The Haiku classifier is **only called** for transcripts that already passed the frontend heuristic gate (confidence >= threshold AND past grace period). This minimizes API calls.

### Prompt Design

- **Input:** User transcript text only (no Mira context, no metadata)
- **Output:** Binary classification — `"real"` or `"noise"`
- **Model:** Claude Haiku 4.5 (`claude-haiku-4-5-20251001`) via existing Anthropic API key
- **Max tokens:** ~10 (just needs a one-word answer)
- **Latency budget:** < 500ms target, < 800ms acceptable

### Classification Prompt

```
You are a voice assistant interrupt detector. A user is at a smart mirror with an AI stylist named Mira. Mira is currently speaking. The microphone picked up the following transcript.

Determine if this is REAL user speech directed at the AI assistant, or NOISE (ambient chatter from bystanders, background sounds, or non-directed speech).

Reply with exactly one word: "real" or "noise"

Transcript: "{transcript}"
```

### On "noise" Rejection

- **User-facing:** Nothing. Mira continues speaking. Silent rejection.
- **Logging:** The rejected transcript, classification result, and confidence score are logged for the admin dashboard (visible in a "Rejected Interrupts" log table for tuning purposes).

### On "real" Classification

- Frontend receives confirmation and executes the interrupt sequence (see below).

---

## Interrupt Execution Flow

When a transcript passes both stages:

### Frontend

1. `mira.stop()` — immediately halts TTS playback and avatar speaking state
2. Set `interruptedRef = true` — ignore remaining stale `mira_speech` chunks from the old response
3. Clear sentence buffer, emotion state, and speech display
4. Emit `"interrupt"` Socket.io event to backend (with `user_id`)
5. Emit `"mirror_event"` with the new voice transcript (standard voice event path)

### Backend

1. `interrupt` socket handler sets `session._interrupted = True` (outside event lock, no contention)
2. `_call_claude()` stream loop checks `_interrupted` on each iteration:
   - On `True`: breaks out of stream, appends stub assistant message to history, sends end-of-message to frontend, clears flag, returns
3. The queued `mirror_event` (new voice transcript) acquires the event lock normally and triggers a fresh `_call_claude()` with the new input

### Tool Calls During Interrupt

- **Speech:** Cancelled immediately
- **In-flight tool calls:** Continue running in the background. Results are not discarded. Mira can reference them in her next response if relevant.

---

## Interrupt UX

- **Visual feedback on interrupt:** None. Silent stop. The user's own speech is the feedback.
- **No rate limit:** Users can interrupt as many times as they want per response. The two-stage filter is trusted to handle noise.
- **No wake word:** No special trigger phrase required. Any speech that passes both gates triggers an interrupt.

---

## Deepgram Configuration

- `utterance_end_ms`: **1500ms** (unchanged)
- No changes to Deepgram STT configuration for interrupt mode vs. normal mode
- Confidence score is extracted from Deepgram's transcript response and passed to the frontend gate

---

## Physical Setup

- **Microphone:** Directional/cardioid mic pointed at user position (recommended)
- The spec is designed to work with omnidirectional mics as well (the two-stage filter compensates), but a directional mic significantly reduces ambient noise before it reaches Deepgram

---

## Data Flow Diagram

```
User speaks during Mira's response:

Browser (mirror-v2)                          Backend
───────────────────────────────────────────────────────────
Deepgram STT → final transcript
  │
  ├─ Check grace period:
  │    Is Mira speaking? YES
  │    Sentence count = 1? → DROP (uninterruptible)
  │    Sentence count > 1, speaking < 2.5s? → DROP (grace)
  │    Sentence count > 1, speaking >= 2.5s? → CONTINUE
  │
  ├─ Check confidence:
  │    confidence < 0.80? → DROP
  │    confidence >= 0.80? → CONTINUE
  │
  ├─ POST /api/classify-interrupt ─────────► Haiku classifier
  │    { transcript }                          │
  │                                            ├─ "noise" → log, return { interrupt: false }
  │◄─── { interrupt: false } ──────────────────┘   (Mira keeps talking)
  │
  │                                            ├─ "real" → return { interrupt: true }
  │◄─── { interrupt: true } ───────────────────┘
  │
  ├─ mira.stop() (TTS stops)
  ├─ interruptedRef = true
  ├─ emit("interrupt") ──────────────────────► session._interrupted = True
  ├─ emit("mirror_event", voice) ────────────► handle_event (blocked on lock)
  │
  │                                          _call_claude loop:
  │                                            checks _interrupted → True → break
  │                                            stub assistant msg → history
  │◄──── mira_speech (end-of-message) ──────  releases lock
  │  interruptedRef = false
  │
  │                                          handle_event (new voice):
  │                                            acquires lock → _call_claude
  │◄──── mira_speech (new response) ────────  streams new response
```

---

## Files to Create/Modify

| File | Change |
|------|--------|
| `backend/agent/orchestrator.py` | `_interrupted` flag, `interrupt()` method, stream loop break (ALREADY DONE) |
| `backend/main.py` | `interrupt` socket handler (ALREADY DONE), new `/api/classify-interrupt` REST endpoint |
| `backend/routers/admin.py` | Add endpoints for interrupt config (get/update thresholds) + rejected interrupt log |
| `frontend/src/app/mirror-v2/page.tsx` | `interruptedRef` (ALREADY DONE), grace period logic, confidence gating, Haiku classification call before interrupt |
| `frontend/src/app/admin/page.tsx` | Add interrupt config sliders (grace period, confidence threshold) |
| `frontend/src/lib/api.ts` | Add `classifyInterrupt()` and admin config API functions |

---

## Implementation Phases

### Phase 1 (Already Done)
Basic interrupt plumbing:
- Backend `_interrupted` flag + `interrupt()` method + stream loop break
- Backend `interrupt` socket handler
- Frontend `interruptedRef` + immediate transcript sending + stale chunk filtering

### Phase 2: Frontend Heuristic Gate
- Add grace period tracking (sentence count + speaking duration timer)
- Add Deepgram confidence threshold check
- Drop transcripts that fail either check during Mira's speech
- Wire up admin-synced config for thresholds

### Phase 3: Backend Haiku Classifier
- New `/api/classify-interrupt` endpoint with Haiku prompt
- Frontend calls endpoint for transcripts that pass heuristic gate
- Only fires interrupt if Haiku returns `"real"`
- Log rejected transcripts for admin visibility

### Phase 4: Admin Dashboard Controls
- Grace period slider (0-10s, default 2.5)
- Confidence threshold slider (0.50-1.00, default 0.80)
- Rejected interrupt log table (transcript, confidence, timestamp, classification)
- Socket.io broadcast of config changes to mirror

---

## Edge Cases

| Scenario | Behavior |
|----------|----------|
| User speaks during 1-sentence response | Dropped (uninterruptible) |
| User speaks in first 2.5s of long response | Dropped (grace period) |
| Low-confidence ambient chatter (< 0.80) | Dropped by frontend gate |
| High-confidence ambient chatter (>= 0.80) | Rejected by Haiku classifier, logged |
| User interrupts during tool execution | Speech stops, tools continue in background |
| Mira interrupted mid-word | TTS stops, stub assistant message preserves history |
| Multiple rapid interrupts | All evaluated individually, no rate limit |
| Haiku classifier timeout (> 1s) | Treat as "noise" (fail-closed), log timeout |
| Deepgram returns empty transcript | Dropped (no text to evaluate) |
| User interrupts then goes silent | Interrupt fires, new voice event processed, silence timer restarts |
