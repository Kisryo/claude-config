@~/Developer/browser-harness/SKILL.md

## Communication

When I give a short or ambiguous response (like a number or single word), ask a clarifying question before proceeding. Do not assume intent from minimal input.

## File Operations

When modifying file paths or file write operations, always confirm the resolved absolute path before writing. Double-check path resolution logic against the project's base directory configuration.

## Coding Best Practices

- Always use descriptive variable names
- Always follow best coding practices

## Deployment

- **Always run Vercel deployments in the background** using the Task tool with `run_in_background: true`
- This prevents blocking the workflow while waiting for builds to complete
- Example:
  ```
  Task(subagent_type: "Bash", description: "Deploy to Vercel production",
       prompt: "vercel --prod --yes", run_in_background: true)
  ```

## gstack

- Available skills:
  - `/plan-ceo-review` — CEO-level plan review
  - `/plan-eng-review` — Engineering plan review
  - `/review` — Code review
  - `/ship` — Ship code (commit, push, PR)
  - `/browse` — Headless browser for QA, testing, and web browsing
  - `/qa` — QA testing
  - `/setup-browser-cookies` — Set up browser cookies for authenticated browsing
  - `/retro` — Retrospective