#!/bin/bash
# linear-commit-hook.sh
# Stop hook — updates Linear issue when a Claude Code session ends.
#
# Extracts a Linear issue ID from the branch name, posts a comment
# with session activity, and moves the issue to "In Progress" if needed.

# Must be in a git repo
if ! git rev-parse --is-inside-work-tree &>/dev/null; then
  exit 0
fi

# Extract Linear issue ID from branch name (e.g., jym2117/tab-24-description)
BRANCH=$(git branch --show-current 2>/dev/null)
ISSUE_ID=$(echo "$BRANCH" | grep -oiE '[A-Z]+-[0-9]+' | head -1 | tr '[:lower:]' '[:upper:]')

# If no issue ID found, nothing to do
if [ -z "$ISSUE_ID" ]; then
  exit 0
fi

# Need an API key
if [ -z "$LINEAR_API_KEY" ]; then
  exit 0
fi

LINEAR_API="https://api.linear.app/graphql"

# Gather recent branch activity
RECENT_COMMITS=$(git log main..HEAD --oneline 2>/dev/null | head -10)
CHANGED_FILES=$(git diff main --name-only 2>/dev/null | head -15)

# Nothing to report
if [ -z "$RECENT_COMMITS" ] && [ -z "$CHANGED_FILES" ]; then
  exit 0
fi

# --- Step 1: Look up the issue UUID and current status ---

QUERY=$(cat <<EOF
{
  "query": "query { searchIssues(term: \"$ISSUE_ID\", first: 1) { nodes { id state { id name } } } }"
}
EOF
)

RESPONSE=$(curl -s -X POST "$LINEAR_API" \
  -H "Authorization: $LINEAR_API_KEY" \
  -H "Content-Type: application/json" \
  -d "$QUERY" 2>/dev/null)

# Extract issue UUID and state name using python (available on macOS)
ISSUE_UUID=$(echo "$RESPONSE" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    nodes = data.get('data', {}).get('searchIssues', {}).get('nodes', [])
    print(nodes[0]['id'] if nodes else '')
except: pass
" 2>/dev/null)

STATE_NAME=$(echo "$RESPONSE" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    nodes = data.get('data', {}).get('searchIssues', {}).get('nodes', [])
    print(nodes[0]['state']['name'] if nodes else '')
except: pass
" 2>/dev/null)

if [ -z "$ISSUE_UUID" ]; then
  echo "⚠ Linear: Could not find issue $ISSUE_ID"
  exit 0
fi

# --- Step 2: Post a comment with session summary ---

COMMENT="### Claude Code Session Summary\n\n**Branch:** \`$BRANCH\`\n"

if [ -n "$RECENT_COMMITS" ]; then
  COMMENT="${COMMENT}\n**Commits:**\n"
  while IFS= read -r line; do
    COMMENT="${COMMENT}- \`${line}\`\n"
  done <<< "$RECENT_COMMITS"
fi

if [ -n "$CHANGED_FILES" ]; then
  COMMENT="${COMMENT}\n**Files changed:**\n"
  while IFS= read -r line; do
    COMMENT="${COMMENT}- \`${line}\`\n"
  done <<< "$CHANGED_FILES"
fi

# Escape for JSON
COMMENT_ESCAPED=$(echo -e "$COMMENT" | python3 -c "
import json, sys
print(json.dumps(sys.stdin.read()))
" 2>/dev/null)

MUTATION=$(python3 -c "
import json
body = $COMMENT_ESCAPED
query = 'mutation { commentCreate(input: { issueId: \"$ISSUE_UUID\", body: ' + json.dumps(body) + ' }) { success } }'
print(json.dumps({'query': query}))
" 2>/dev/null)

COMMENT_RESULT=$(curl -s -X POST "$LINEAR_API" \
  -H "Authorization: $LINEAR_API_KEY" \
  -H "Content-Type: application/json" \
  -d "$MUTATION" 2>/dev/null)

COMMENT_OK=$(echo "$COMMENT_RESULT" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    print('true' if data.get('data', {}).get('commentCreate', {}).get('success') else 'false')
except: print('false')
" 2>/dev/null)

if [ "$COMMENT_OK" = "true" ]; then
  echo "✓ Linear: Posted session summary to $ISSUE_ID"
else
  echo "⚠ Linear: Failed to post comment to $ISSUE_ID"
  exit 0
fi

# --- Step 3: Move to "In Progress" if currently in a starting state ---

STATE_LOWER=$(echo "$STATE_NAME" | tr '[:upper:]' '[:lower:]')
case "$STATE_LOWER" in
  todo|backlog|triage|unstarted)
    # Look up the "In Progress" state ID for this issue's team
    STATE_QUERY=$(cat <<EOF
{
  "query": "query { searchIssues(term: \"$ISSUE_ID\", first: 1) { nodes { team { states { nodes { id name } } } } } }"
}
EOF
)

    STATE_RESPONSE=$(curl -s -X POST "$LINEAR_API" \
      -H "Authorization: $LINEAR_API_KEY" \
      -H "Content-Type: application/json" \
      -d "$STATE_QUERY" 2>/dev/null)

    IN_PROGRESS_ID=$(echo "$STATE_RESPONSE" | python3 -c "
import json, sys
try:
    data = json.load(sys.stdin)
    nodes = data.get('data', {}).get('searchIssues', {}).get('nodes', [])
    states = nodes[0]['team']['states']['nodes']
    for s in states:
        if s['name'].lower() == 'in progress':
            print(s['id'])
            break
except: pass
" 2>/dev/null)

    if [ -n "$IN_PROGRESS_ID" ]; then
      STATUS_MUTATION=$(cat <<EOF
{
  "query": "mutation { issueUpdate(id: \"$ISSUE_UUID\", input: { stateId: \"$IN_PROGRESS_ID\" }) { success } }"
}
EOF
)

      curl -s -X POST "$LINEAR_API" \
        -H "Authorization: $LINEAR_API_KEY" \
        -H "Content-Type: application/json" \
        -d "$STATUS_MUTATION" >/dev/null 2>&1

      echo "✓ Linear: Moved $ISSUE_ID from \"$STATE_NAME\" → \"In Progress\""
    fi
    ;;
  *)
    # Already in progress, in review, done, etc. — don't touch status
    ;;
esac
